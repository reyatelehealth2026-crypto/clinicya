<?php
// Simple API test - no dependencies
header('Content-Type: text/plain');
echo "CNY API Test\n\n";

$token = '90xcKekelCqCAjmgkpI1saJF6N55eiNexcI4hdcYM2M';

$ch = curl_init('https://manager.cnypharmacy.com/api/get_product_sku/0001');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Authorization: Bearer ' . $token,
    'Content-Type: application/json',
    'Accept: application/json'
));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

echo "HTTP Code: $code\n";
echo "cURL Error: " . ($err ?: 'none') . "\n";
echo "Response Size: " . strlen($res) . " bytes\n\n";
echo "Response:\n";
echo substr($res, 0, 3000);
