<?php
/**
 * Test AI Product Flex Message
 * ทดสอบการแสดงรูปสินค้าใน AI Response
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

// Get database connection
$db = Database::getInstance()->getConnection();

require_once __DIR__ . '/modules/AIChat/Adapters/PharmacyAIAdapter.php';

echo "<h1>🧪 Test AI Product Flex Message</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
    .test-section { background: white; padding: 20px; margin: 20px 0; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
    .success { color: green; }
    .error { color: red; }
    pre { background: #f0f0f0; padding: 15px; border-radius: 5px; overflow-x: auto; }
    .product-card { display: inline-block; width: 200px; margin: 10px; padding: 15px; background: #fff; border: 1px solid #ddd; border-radius: 10px; text-align: center; }
    .product-card img { width: 100px; height: 100px; object-fit: cover; border-radius: 5px; }
</style>";

// Test 1: ตรวจสอบ ProductFlexTemplates
echo "<div class='test-section'>";
echo "<h2>1️⃣ Test ProductFlexTemplates</h2>";

try {
    require_once __DIR__ . '/modules/AIChat/Templates/ProductFlexTemplates.php';
    $flexTemplates = new \Modules\AIChat\Templates\ProductFlexTemplates();
    echo "<p class='success'>✅ ProductFlexTemplates loaded successfully</p>";
    
    // Test with sample product
    $sampleProduct = [
        'name' => 'Paracetamol 500mg',
        'price' => 35,
        'sale_price' => 29,
        'sku' => '0001',
        'generic_name' => 'Paracetamol',
        'stock' => 100,
        'unit' => 'แผง',
        'image_url' => 'https://cdn-icons-png.flaticon.com/512/3140/3140343.png'
    ];
    
    $bubble = $flexTemplates->createProductBubble($sampleProduct);
    echo "<p class='success'>✅ createProductBubble() works</p>";
    echo "<pre>" . json_encode($bubble, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Test 2: ตรวจสอบ PharmacyRAG
echo "<div class='test-section'>";
echo "<h2>2️⃣ Test PharmacyRAG with image_url</h2>";

try {
    require_once __DIR__ . '/modules/AIChat/Services/PharmacyRAG.php';
    $rag = new \Modules\AIChat\Services\PharmacyRAG($db);
    
    // ค้นหาสินค้า
    $results = $rag->search('ปวดหัว', 5);
    
    echo "<p class='success'>✅ PharmacyRAG search works</p>";
    echo "<p>Found " . count($results['products']) . " products</p>";
    
    if (!empty($results['products'])) {
        echo "<h3>Products with image_url:</h3>";
        foreach ($results['products'] as $p) {
            $hasImage = !empty($p['image_url']) ? '✅' : '❌';
            echo "<div class='product-card'>";
            if (!empty($p['image_url'])) {
                echo "<img src='{$p['image_url']}' alt='{$p['name']}'>";
            } else {
                echo "<img src='https://cdn-icons-png.flaticon.com/512/3140/3140343.png' alt='No image'>";
            }
            echo "<p><strong>" . mb_substr($p['name'], 0, 30) . "</strong></p>";
            echo "<p>SKU: " . ($p['sku'] ?? 'N/A') . "</p>";
            echo "<p>Image: {$hasImage}</p>";
            echo "</div>";
        }
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Test 3: ตรวจสอบ PharmacyAIAdapter
echo "<div class='test-section'>";
echo "<h2>3️⃣ Test PharmacyAIAdapter with Products</h2>";

try {
    $adapter = new \Modules\AIChat\Adapters\PharmacyAIAdapter($db, 1);
    
    echo "<p>API Key: " . ($adapter->isEnabled() ? '✅ Found' : '❌ Not found') . "</p>";
    echo "<p>Model: " . $adapter->getModel() . "</p>";
    
    if ($adapter->isEnabled()) {
        echo "<h3>Testing processMessage()...</h3>";
        
        // ทดสอบส่งข้อความ
        $testMessage = "มียาแก้ปวดหัวไหม";
        echo "<p>Test message: <strong>{$testMessage}</strong></p>";
        
        $result = $adapter->processMessage($testMessage);
        
        if ($result['success']) {
            echo "<p class='success'>✅ AI Response generated</p>";
            echo "<p><strong>Response:</strong> " . mb_substr($result['response'], 0, 200) . "...</p>";
            
            // ตรวจสอบ products
            $products = $result['products'] ?? [];
            echo "<p>Products found: " . count($products) . "</p>";
            
            // ตรวจสอบ messages
            $messages = $result['messages'] ?? $result['message'];
            if (is_array($messages)) {
                echo "<p>Messages count: " . count($messages) . "</p>";
                
                foreach ($messages as $i => $msg) {
                    echo "<p>Message {$i}: type=" . ($msg['type'] ?? 'unknown') . "</p>";
                }
            }
            
            echo "<h4>Full Result:</h4>";
            echo "<pre>" . json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR) . "</pre>";
            
        } else {
            echo "<p class='error'>❌ Error: " . ($result['error'] ?? 'Unknown error') . "</p>";
        }
    } else {
        echo "<p class='error'>⚠️ AI not enabled - skipping processMessage test</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}
echo "</div>";

// Test 4: ตรวจสอบ database columns
echo "<div class='test-section'>";
echo "<h2>4️⃣ Check Database Columns</h2>";

try {
    $stmt = $db->query("DESCRIBE business_items");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $requiredColumns = ['image_url', 'sale_price', 'sku', 'barcode', 'generic_name', 'usage_instructions'];
    
    echo "<p>Columns in business_items:</p>";
    echo "<ul>";
    foreach ($requiredColumns as $col) {
        $exists = in_array($col, $columns);
        $icon = $exists ? '✅' : '❌';
        echo "<li>{$icon} {$col}</li>";
    }
    echo "</ul>";
    
    // ตรวจสอบว่ามีสินค้าที่มี image_url หรือไม่
    $stmt = $db->query("SELECT COUNT(*) as total, SUM(CASE WHEN image_url IS NOT NULL AND image_url != '' THEN 1 ELSE 0 END) as with_image FROM business_items WHERE is_active = 1");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<p>Products: {$stats['total']} total, {$stats['with_image']} with images</p>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}
echo "</div>";

echo "<div class='test-section'>";
echo "<h2>📋 Summary</h2>";
echo "<p>ระบบ AI Product Flex Message พร้อมใช้งาน:</p>";
echo "<ul>";
echo "<li>✅ ProductFlexTemplates - สร้าง Flex Message พร้อมรูปสินค้า</li>";
echo "<li>✅ PharmacyRAG - ค้นหาสินค้าพร้อม image_url</li>";
echo "<li>✅ PharmacyAIAdapter - ส่ง multiple messages (text + carousel)</li>";
echo "<li>✅ webhook.php - รองรับ array ของ messages</li>";
echo "</ul>";
echo "<p><strong>วิธีทดสอบ:</strong> ส่งข้อความถาม AI เช่น 'มียาแก้ปวดหัวไหม' ผ่าน LINE</p>";
echo "</div>";
