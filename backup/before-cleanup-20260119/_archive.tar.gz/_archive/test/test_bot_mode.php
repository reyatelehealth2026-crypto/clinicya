<?php
/**
 * Test Bot Mode - ทดสอบการเปลี่ยนโหมดบอท
 */
require_once 'config/config.php';
require_once 'config/database.php';

// Force no cache
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

echo "<h2>🔧 Test Bot Mode</h2>";
echo "<pre>";

try {
    $db = Database::getInstance()->getConnection();
    
    // 1. ตรวจสอบว่ามี column bot_mode หรือไม่
    echo "1. Checking bot_mode column...\n";
    $stmt = $db->query("SHOW COLUMNS FROM line_accounts LIKE 'bot_mode'");
    $col = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($col) {
        echo "   ✅ Column exists: " . json_encode($col) . "\n\n";
    } else {
        echo "   ❌ Column NOT found! Adding...\n";
        $db->exec("ALTER TABLE line_accounts ADD COLUMN bot_mode ENUM('shop', 'general', 'auto_reply_only') DEFAULT 'shop' AFTER is_default");
        echo "   ✅ Column added!\n\n";
    }
    
    // 2. แสดงข้อมูล accounts ทั้งหมด
    echo "2. Current LINE Accounts:\n";
    echo str_repeat("-", 80) . "\n";
    
    $stmt = $db->query("SELECT id, name, bot_mode, is_active, is_default FROM line_accounts");
    $accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($accounts)) {
        echo "   No accounts found.\n";
    } else {
        foreach ($accounts as $acc) {
            echo sprintf("   ID: %d | Name: %s | Mode: %s | Active: %s | Default: %s\n",
                $acc['id'],
                $acc['name'],
                $acc['bot_mode'] ?? 'NULL',
                $acc['is_active'] ? 'Yes' : 'No',
                $acc['is_default'] ? 'Yes' : 'No'
            );
        }
    }
    echo str_repeat("-", 80) . "\n\n";
    
    // 3. ทดสอบการอัพเดท
    if (!empty($_GET['test_update']) && !empty($_GET['id']) && !empty($_GET['mode'])) {
        $id = (int)$_GET['id'];
        $mode = $_GET['mode'];
        
        echo "3. Testing UPDATE...\n";
        echo "   ID: $id, Mode: $mode\n";
        
        $stmt = $db->prepare("UPDATE line_accounts SET bot_mode = ? WHERE id = ?");
        $result = $stmt->execute([$mode, $id]);
        
        echo "   Result: " . ($result ? "✅ Success" : "❌ Failed") . "\n";
        echo "   Rows affected: " . $stmt->rowCount() . "\n\n";
        
        // ตรวจสอบผลลัพธ์
        $stmt = $db->prepare("SELECT id, name, bot_mode FROM line_accounts WHERE id = ?");
        $stmt->execute([$id]);
        $updated = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "   After update: " . json_encode($updated) . "\n";
    }
    
    echo "\n✅ Test completed!\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}

echo "</pre>";

// แสดงลิงก์ทดสอบ
if (!empty($accounts)) {
    echo "<h3>🧪 Test Links:</h3>";
    echo "<ul>";
    foreach ($accounts as $acc) {
        echo "<li>";
        echo "<strong>{$acc['name']}</strong> (Current: {$acc['bot_mode']}): ";
        echo "<a href='?test_update=1&id={$acc['id']}&mode=shop'>Set Shop</a> | ";
        echo "<a href='?test_update=1&id={$acc['id']}&mode=general'>Set General</a> | ";
        echo "<a href='?test_update=1&id={$acc['id']}&mode=auto_reply_only'>Set Auto Reply</a>";
        echo "</li>";
    }
    echo "</ul>";
}

echo "<p><a href='line-accounts.php'>← กลับหน้าจัดการบัญชี LINE</a></p>";
?>
