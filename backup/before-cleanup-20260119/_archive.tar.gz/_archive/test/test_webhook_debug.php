<?php
/**
 * Webhook Debug Test
 * ทดสอบ flow การตอบกลับข้อความ
 */

require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "=== WEBHOOK DEBUG TEST ===\n\n";

// 1. ตรวจสอบตารางที่จำเป็น
echo "📋 1. Required Tables Check:\n";
$tables = [
    'shop_settings' => 'Shop Settings',
    'business_settings' => 'Business Settings (V2.5)',
    'product_categories' => 'Product Categories',
    'item_categories' => 'Item Categories (V2.5)',
    'products' => 'Products',
    'business_items' => 'Business Items (V2.5)',
    'auto_replies' => 'Auto Replies',
    'ai_settings' => 'AI Settings',
];

foreach ($tables as $table => $desc) {
    try {
        $db->query("SELECT 1 FROM {$table} LIMIT 1");
        echo "  ✅ {$table} - EXISTS\n";
    } catch (Exception $e) {
        echo "  ❌ {$table} - NOT FOUND ({$desc})\n";
    }
}

// 2. ตรวจสอบ Shop Settings
echo "\n📋 2. Shop Settings:\n";
try {
    $stmt = $db->query("SELECT * FROM shop_settings LIMIT 1");
    $settings = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($settings) {
        echo "  ✅ Shop Name: " . ($settings['shop_name'] ?? 'N/A') . "\n";
        echo "  ✅ Is Open: " . ($settings['is_open'] ? 'Yes' : 'No') . "\n";
    } else {
        echo "  ⚠️ No settings found\n";
    }
} catch (Exception $e) {
    echo "  ❌ Error: " . $e->getMessage() . "\n";
}

// 3. ตรวจสอบ Categories
echo "\n📋 3. Categories:\n";
try {
    $stmt = $db->query("SELECT id, name, is_active FROM product_categories ORDER BY sort_order");
    $cats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($cats)) {
        echo "  ⚠️ No categories found\n";
    } else {
        foreach ($cats as $cat) {
            $status = $cat['is_active'] ? '✅' : '❌';
            echo "  {$status} [{$cat['id']}] {$cat['name']}\n";
        }
    }
} catch (Exception $e) {
    echo "  ❌ Error: " . $e->getMessage() . "\n";
}

// 4. ตรวจสอบ Products
echo "\n📋 4. Products:\n";
try {
    $stmt = $db->query("SELECT id, name, price, stock, is_active, category_id FROM products ORDER BY id DESC LIMIT 10");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($products)) {
        echo "  ⚠️ No products found - THIS IS WHY SHOP DOESN'T RESPOND!\n";
    } else {
        foreach ($products as $p) {
            $status = $p['is_active'] ? '✅' : '❌';
            echo "  {$status} [{$p['id']}] {$p['name']} - ฿{$p['price']} (stock: {$p['stock']})\n";
        }
    }
} catch (Exception $e) {
    echo "  ❌ Error: " . $e->getMessage() . "\n";
}

// 5. ตรวจสอบ Auto Replies
echo "\n📋 5. Auto Replies:\n";
try {
    $stmt = $db->query("SELECT id, keyword, match_type, reply_type, is_active FROM auto_replies ORDER BY priority DESC");
    $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($replies)) {
        echo "  ⚠️ No auto replies configured\n";
    } else {
        foreach ($replies as $r) {
            $status = $r['is_active'] ? '✅' : '❌';
            echo "  {$status} [{$r['id']}] '{$r['keyword']}' ({$r['match_type']}) -> {$r['reply_type']}\n";
        }
    }
} catch (Exception $e) {
    echo "  ❌ Error: " . $e->getMessage() . "\n";
}

// 6. ตรวจสอบ AI Settings
echo "\n📋 6. AI Chatbot:\n";
try {
    $stmt = $db->query("SELECT is_enabled, model FROM ai_settings WHERE id = 1");
    $ai = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($ai) {
        $status = $ai['is_enabled'] ? '✅ Enabled' : '❌ Disabled';
        echo "  {$status} - Model: " . ($ai['model'] ?? 'N/A') . "\n";
    } else {
        echo "  ⚠️ No AI settings found\n";
    }
} catch (Exception $e) {
    echo "  ❌ Error: " . $e->getMessage() . "\n";
}

// 7. ทดสอบ BusinessBot
echo "\n📋 7. BusinessBot Test:\n";
try {
    require_once 'classes/LineAPI.php';
    require_once 'classes/BusinessBot.php';
    
    // Mock LineAPI
    $line = new LineAPI();
    $bot = new BusinessBot($db, $line, null);
    
    echo "  ✅ BusinessBot loaded successfully\n";
    
    // Test getItem
    $stmt = $db->query("SELECT id FROM products WHERE is_active = 1 LIMIT 1");
    $productId = $stmt->fetchColumn();
    if ($productId) {
        $item = $bot->getItem($productId);
        if ($item) {
            echo "  ✅ getItem({$productId}) works - {$item['name']}\n";
        } else {
            echo "  ⚠️ getItem({$productId}) returned null\n";
        }
    } else {
        echo "  ⚠️ No active products to test\n";
    }
    
} catch (Exception $e) {
    echo "  ❌ Error: " . $e->getMessage() . "\n";
}

// 8. สรุปปัญหา
echo "\n" . str_repeat("=", 50) . "\n";
echo "📊 SUMMARY & RECOMMENDATIONS:\n";
echo str_repeat("=", 50) . "\n";

$issues = [];

// Check products
try {
    $stmt = $db->query("SELECT COUNT(*) FROM products WHERE is_active = 1");
    $activeProducts = $stmt->fetchColumn();
    if ($activeProducts == 0) {
        $issues[] = "❌ ไม่มีสินค้าที่ active - บอทจะไม่แสดงสินค้า";
    }
} catch (Exception $e) {}

// Check categories
try {
    $stmt = $db->query("SELECT COUNT(*) FROM product_categories WHERE is_active = 1");
    $activeCats = $stmt->fetchColumn();
    if ($activeCats == 0) {
        $issues[] = "❌ ไม่มีหมวดหมู่ที่ active - บอทจะไม่แสดงหมวดหมู่";
    }
} catch (Exception $e) {}

// Check auto replies
try {
    $stmt = $db->query("SELECT COUNT(*) FROM auto_replies WHERE is_active = 1");
    $activeReplies = $stmt->fetchColumn();
    if ($activeReplies == 0) {
        $issues[] = "⚠️ ไม่มี auto reply ที่ active";
    }
} catch (Exception $e) {}

if (empty($issues)) {
    echo "✅ ไม่พบปัญหาหลัก - ระบบควรทำงานได้\n";
} else {
    foreach ($issues as $issue) {
        echo "{$issue}\n";
    }
}

echo "\n💡 QUICK FIX:\n";
echo "1. เพิ่มสินค้าใน shop/products.php\n";
echo "2. ตรวจสอบว่าหมวดหมู่ is_active = 1\n";
echo "3. ตรวจสอบว่าสินค้า is_active = 1 และ stock > 0\n";
echo "\n";
