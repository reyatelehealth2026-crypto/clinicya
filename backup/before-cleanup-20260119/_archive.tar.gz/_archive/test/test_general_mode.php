<?php
/**
 * Test General Mode - ทดสอบว่าโหมด general ตอบเฉพาะ Auto Reply
 */
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'classes/LineAPI.php';
require_once 'classes/BusinessBot.php';

// Include checkAutoReply function from webhook
function checkAutoReplyTest($db, $text, $lineAccountId = null) {
    if ($lineAccountId) {
        $stmt = $db->prepare("SELECT * FROM auto_replies WHERE is_active = 1 AND (line_account_id = ? OR line_account_id IS NULL) ORDER BY line_account_id DESC, priority DESC");
        $stmt->execute([$lineAccountId]);
    } else {
        $stmt = $db->prepare("SELECT * FROM auto_replies WHERE is_active = 1 ORDER BY priority DESC");
        $stmt->execute();
    }
    $rules = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($rules as $rule) {
        $keyword = $rule['keyword'];
        $matchType = $rule['match_type'] ?? 'contains';
        $matched = false;
        
        switch ($matchType) {
            case 'exact':
                $matched = (mb_strtolower($text) === mb_strtolower($keyword));
                break;
            case 'starts_with':
                $matched = (mb_stripos($text, $keyword) === 0);
                break;
            case 'contains':
            default:
                $matched = (mb_stripos($text, $keyword) !== false);
                break;
        }
        
        if ($matched) {
            return $rule;
        }
    }
    return null;
}

$db = Database::getInstance()->getConnection();
$lineAccountId = $_GET['account_id'] ?? 1;

echo "<h1>🧪 Test General Mode (with Auto Reply)</h1>";
echo "<style>body{font-family:sans-serif;padding:20px}
.box{background:#fff;border:1px solid #E5E7EB;border-radius:12px;padding:20px;margin:15px 0}
.success{color:#059669;background:#D1FAE5;padding:10px;border-radius:8px;margin:5px 0}
.error{color:#DC2626;background:#FEE2E2;padding:10px;border-radius:8px;margin:5px 0}
.info{color:#2563EB;background:#DBEAFE;padding:10px;border-radius:8px;margin:5px 0}
pre{background:#F3F4F6;padding:15px;border-radius:8px;overflow-x:auto}</style>";

// 1. Get LINE Account
echo "<div class='box'><h2>1. LINE Account Info</h2>";
$stmt = $db->prepare("SELECT id, name, bot_mode, channel_access_token, channel_secret FROM line_accounts WHERE id = ?");
$stmt->execute([$lineAccountId]);
$account = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$account) {
    echo "<p class='error'>❌ ไม่พบ LINE Account ID: $lineAccountId</p>";
    exit;
}

echo "<p>ID: <strong>{$account['id']}</strong></p>";
echo "<p>Name: <strong>{$account['name']}</strong></p>";
echo "<p>Bot Mode: <strong style='font-size:20px;color:" . ($account['bot_mode'] === 'general' ? '#DC2626' : '#059669') . "'>{$account['bot_mode']}</strong></p>";
echo "</div>";

// 2. Test BusinessBot
echo "<div class='box'><h2>2. Test BusinessBot</h2>";
$line = new LineAPI($account['channel_access_token'], $account['channel_secret']);
$bot = new BusinessBot($db, $line, $lineAccountId);

echo "<p>BusinessBot->getBotMode() = <strong>{$bot->getBotMode()}</strong></p>";

// Test messages
$testMessages = ['เมนู', 'menu', 'shop', 'สินค้า', 'สวัสดี', 'ทดสอบ', 'hello'];
echo "<h3>Test processMessage():</h3>";
echo "<table border='1' cellpadding='10' style='border-collapse:collapse;width:100%'>";
echo "<tr style='background:#F3F4F6'><th>Message</th><th>Result</th><th>Expected (general)</th><th>Status</th></tr>";

foreach ($testMessages as $msg) {
    // Mock replyToken
    $result = $bot->processMessage('test_user', 1, $msg, 'mock_reply_token_' . time());
    $resultText = $result === null ? 'null (no reply)' : ($result === true ? 'true (replied)' : 'false');
    $expected = 'null (no reply)';
    $status = ($result === null) ? '✅ PASS' : '❌ FAIL';
    $statusColor = ($result === null) ? '#059669' : '#DC2626';
    
    echo "<tr>";
    echo "<td>{$msg}</td>";
    echo "<td>{$resultText}</td>";
    echo "<td>{$expected}</td>";
    echo "<td style='color:{$statusColor};font-weight:bold'>{$status}</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

// 3. Test webhook bot_mode check
echo "<div class='box'><h2>3. Test Webhook Bot Mode Check</h2>";
$botMode = 'shop';
try {
    $stmt = $db->prepare("SELECT bot_mode FROM line_accounts WHERE id = ?");
    $stmt->execute([$lineAccountId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($result && !empty($result['bot_mode'])) {
        $botMode = $result['bot_mode'];
    }
} catch (Exception $e) {
    echo "<p class='error'>Error: " . $e->getMessage() . "</p>";
}

echo "<p>Bot Mode from DB: <strong>{$botMode}</strong></p>";

if ($botMode === 'general') {
    echo "<p class='success'>✅ โหมด general - webhook จะ return ทันทีโดยไม่ตอบกลับ</p>";
} else {
    echo "<p class='info'>ℹ️ โหมด {$botMode} - webhook จะประมวลผลตามปกติ</p>";
}
echo "</div>";

// 4. Test Auto Reply Rules
echo "<div class='box'><h2>4. Auto Reply Rules</h2>";
$stmt = $db->prepare("SELECT * FROM auto_replies WHERE is_active = 1 AND (line_account_id = ? OR line_account_id IS NULL) ORDER BY line_account_id DESC, priority DESC LIMIT 10");
$stmt->execute([$lineAccountId]);
$rules = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($rules)) {
    echo "<p class='info'>ℹ️ ไม่มี Auto Reply rules ที่ active</p>";
} else {
    echo "<p>พบ " . count($rules) . " rules:</p>";
    echo "<table border='1' cellpadding='8' style='border-collapse:collapse;width:100%'>";
    echo "<tr style='background:#F3F4F6'><th>ID</th><th>Keyword</th><th>Match Type</th><th>Reply Type</th><th>Reply Content</th></tr>";
    foreach ($rules as $rule) {
        $content = mb_substr($rule['reply_content'] ?? '', 0, 50);
        echo "<tr>";
        echo "<td>{$rule['id']}</td>";
        echo "<td><strong>{$rule['keyword']}</strong></td>";
        echo "<td>{$rule['match_type']}</td>";
        echo "<td>{$rule['reply_type']}</td>";
        echo "<td>{$content}...</td>";
        echo "</tr>";
    }
    echo "</table>";
}
echo "</div>";

// 5. Test Auto Reply Matching
echo "<div class='box'><h2>5. Test Auto Reply Matching (General Mode)</h2>";
$testAutoReply = ['สวัสดี', 'hello', 'ราคา', 'price', 'ทดสอบ', 'test'];
echo "<p class='info'>ℹ️ ในโหมด General: ถ้า match Auto Reply จะตอบ, ถ้าไม่ match จะไม่ตอบ</p>";
echo "<table border='1' cellpadding='10' style='border-collapse:collapse;width:100%'>";
echo "<tr style='background:#F3F4F6'><th>Message</th><th>Auto Reply Match</th><th>Expected Behavior</th></tr>";

foreach ($testAutoReply as $msg) {
    $match = checkAutoReplyTest($db, $msg, $lineAccountId);
    $matchText = $match ? "✅ Match: {$match['keyword']}" : "❌ No match";
    $behavior = $match ? "🤖 จะตอบกลับ" : "🔇 ไม่ตอบ (รอแอดมิน)";
    $bgColor = $match ? '#D1FAE5' : '#FEE2E2';
    
    echo "<tr style='background:{$bgColor}'>";
    echo "<td>{$msg}</td>";
    echo "<td>{$matchText}</td>";
    echo "<td>{$behavior}</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

// 6. Summary
echo "<div class='box'><h2>6. Summary</h2>";
if ($account['bot_mode'] === 'general' && $bot->getBotMode() === 'general') {
    echo "<div class='success' style='font-size:18px;text-align:center'>✅ โหมด General ทำงานถูกต้อง</div>";
    echo "<div class='info' style='margin-top:10px'>";
    echo "<strong>พฤติกรรมในโหมด General:</strong><br>";
    echo "• ❌ ไม่ตอบ commands (menu, shop, etc.)<br>";
    echo "• ✅ ตอบ Auto Reply rules ที่ match<br>";
    echo "• ❌ ไม่ตอบ AI Chatbot<br>";
    echo "• ❌ ไม่ตอบ Default reply<br>";
    echo "• ✅ บันทึกข้อมูลทุกข้อความ<br>";
    echo "</div>";
} else {
    echo "<div class='error' style='font-size:18px;text-align:center'>❌ โหมดไม่ตรงกัน หรือไม่ใช่ general</div>";
}
echo "</div>";

// Quick actions
echo "<div class='box'><h2>🔧 Quick Actions</h2>";
echo "<form method='POST' action='debug_bot_mode.php?account_id={$lineAccountId}'>";
echo "<input type='hidden' name='account_id' value='{$lineAccountId}'>";
echo "<button type='submit' name='new_mode' value='general' style='padding:10px 20px;background:#DC2626;color:white;border:none;border-radius:8px;margin:5px;cursor:pointer'>Set to General</button>";
echo "<button type='submit' name='new_mode' value='shop' style='padding:10px 20px;background:#059669;color:white;border:none;border-radius:8px;margin:5px;cursor:pointer'>Set to Shop</button>";
echo "</form>";
echo "<p><a href='debug_bot_mode.php?account_id={$lineAccountId}'>→ Go to Debug Bot Mode</a></p>";
echo "</div>";
