<?php
// Simple test file - no dependencies
echo "<h1>Server Test OK</h1>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>Server: " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
echo "<p>Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<p>Script: " . $_SERVER['SCRIPT_FILENAME'] . "</p>";
echo "<p>Time: " . date('Y-m-d H:i:s') . "</p>";

// Test if config exists
echo "<h2>File Check:</h2>";
echo "<p>config/config.php: " . (file_exists('config/config.php') ? 'EXISTS' : 'NOT FOUND') . "</p>";
echo "<p>config/database.php: " . (file_exists('config/database.php') ? 'EXISTS' : 'NOT FOUND') . "</p>";
echo "<p>install/index.php: " . (file_exists('install/index.php') ? 'EXISTS' : 'NOT FOUND') . "</p>";
