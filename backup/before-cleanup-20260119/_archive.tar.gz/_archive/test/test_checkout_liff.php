<?php
/**
 * Test LIFF Checkout ID
 */
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>Test LIFF Checkout ID</h2>";

try {
    $stmt = $db->query("SELECT id, name, liff_id, liff_checkout_id FROM line_accounts ORDER BY is_default DESC LIMIT 1");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<p><strong>Account:</strong> {$row['name']} (ID: {$row['id']})</p>";
    echo "<p><strong>liff_id:</strong> " . ($row['liff_id'] ?: 'null') . "</p>";
    echo "<p><strong>liff_checkout_id:</strong> " . ($row['liff_checkout_id'] ?: 'null') . "</p>";
    
    $correctLiffId = $row['liff_checkout_id'] ?: $row['liff_id'] ?: '';
    echo "<p><strong>Should use:</strong> {$correctLiffId}</p>";
    
    if ($row['liff_checkout_id']) {
        echo "<p style='color:green;'>✅ liff_checkout_id is set correctly!</p>";
    } else {
        echo "<p style='color:red;'>❌ liff_checkout_id is empty - will fallback to liff_id</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red;'>Error: " . $e->getMessage() . "</p>";
}
