<?php
/**
 * Test Add to Cart
 * ทดสอบเพิ่มสินค้าลงตะกร้า
 */
header('Content-Type: text/html; charset=utf-8');
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

$lineUserId = $_GET['line_user_id'] ?? 'U95415c96eab157bdb8ee550b3280be85';
$productId = $_GET['product_id'] ?? 1;
$quantity = $_GET['qty'] ?? 1;

echo "<h1>🛒 Test Add to Cart</h1>";

// 1. Get user
echo "<h2>1. หา User</h2>";
$stmt = $db->prepare("SELECT id, line_account_id, display_name FROM users WHERE line_user_id = ?");
$stmt->execute([$lineUserId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    echo "<p style='color:green'>✅ พบ User ID: {$user['id']}</p>";
    $userId = $user['id'];
} else {
    echo "<p style='color:red'>❌ ไม่พบ User</p>";
    exit;
}

// 2. Get product
echo "<h2>2. หา Product</h2>";
$stmt = $db->prepare("SELECT id, name, price, is_active, stock FROM products WHERE id = ?");
$stmt->execute([$productId]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if ($product) {
    echo "<p style='color:green'>✅ พบ Product: {$product['name']}</p>";
    echo "<p>Active: " . ($product['is_active'] ? 'Yes' : 'No') . "</p>";
    echo "<p>Stock: {$product['stock']}</p>";
} else {
    echo "<p style='color:red'>❌ ไม่พบ Product ID: {$productId}</p>";
    
    // Show available products
    echo "<h3>Products ที่มี:</h3>";
    $stmt = $db->query("SELECT id, name, is_active FROM products WHERE is_active = 1 LIMIT 10");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<ul>";
    foreach ($products as $p) {
        echo "<li><a href='?line_user_id={$lineUserId}&product_id={$p['id']}'>{$p['id']}: {$p['name']}</a></li>";
    }
    echo "</ul>";
    exit;
}

// 3. Check cart_items table structure
echo "<h2>3. โครงสร้าง cart_items</h2>";
try {
    $stmt = $db->query("DESCRIBE cart_items");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Key</th></tr>";
    foreach ($columns as $col) {
        echo "<tr><td>{$col['Field']}</td><td>{$col['Type']}</td><td>{$col['Key']}</td></tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
}

// 4. Try to add to cart
echo "<h2>4. ทดสอบเพิ่มลงตะกร้า</h2>";
try {
    // Method 1: ON DUPLICATE KEY UPDATE
    $stmt = $db->prepare("
        INSERT INTO cart_items (user_id, product_id, quantity) 
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
    ");
    $result = $stmt->execute([$userId, $productId, $quantity]);
    
    if ($result) {
        echo "<p style='color:green'>✅ เพิ่มสำเร็จ!</p>";
        echo "<p>Rows affected: " . $stmt->rowCount() . "</p>";
    } else {
        echo "<p style='color:red'>❌ เพิ่มไม่สำเร็จ</p>";
        print_r($stmt->errorInfo());
    }
} catch (Exception $e) {
    echo "<p style='color:orange'>⚠️ Method 1 failed: " . $e->getMessage() . "</p>";
    
    // Try fallback
    echo "<p>ลอง fallback method...</p>";
    try {
        $stmt = $db->prepare("SELECT id, quantity FROM cart_items WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$userId, $productId]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existing) {
            $newQty = $existing['quantity'] + $quantity;
            $stmt = $db->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
            $stmt->execute([$newQty, $existing['id']]);
            echo "<p style='color:green'>✅ Update สำเร็จ!</p>";
        } else {
            $stmt = $db->prepare("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)");
            $stmt->execute([$userId, $productId, $quantity]);
            echo "<p style='color:green'>✅ Insert สำเร็จ!</p>";
        }
    } catch (Exception $e2) {
        echo "<p style='color:red'>❌ Fallback failed: " . $e2->getMessage() . "</p>";
    }
}

// 5. Verify cart
echo "<h2>5. ตรวจสอบตะกร้า</h2>";
$stmt = $db->prepare("SELECT * FROM cart_items WHERE user_id = ?");
$stmt->execute([$userId]);
$cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<p>จำนวน items: " . count($cartItems) . "</p>";
if ($cartItems) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Product ID</th><th>Quantity</th></tr>";
    foreach ($cartItems as $item) {
        echo "<tr><td>{$item['id']}</td><td>{$item['product_id']}</td><td>{$item['quantity']}</td></tr>";
    }
    echo "</table>";
}

// 6. Test API
echo "<h2>6. ทดสอบผ่าน API</h2>";
$apiUrl = BASE_URL . "/api/checkout.php";
echo "<p>POST to: {$apiUrl}</p>";

$postData = [
    'action' => 'add_to_cart',
    'line_user_id' => $lineUserId,
    'product_id' => $productId,
    'quantity' => $quantity
];
echo "<pre>Data: " . json_encode($postData, JSON_PRETTY_PRINT) . "</pre>";

$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode($postData)
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<p>HTTP Code: {$httpCode}</p>";
echo "<pre>Response: " . htmlspecialchars($response) . "</pre>";

echo "<hr>";
echo "<p><a href='test_add_cart.php?line_user_id={$lineUserId}&product_id={$productId}'>🔄 ทดสอบอีกครั้ง</a></p>";
echo "<p><a href='debug_cart.php?line_user_id={$lineUserId}'>📋 ดูตะกร้า</a></p>";
