<?php
/**
 * Test Session in AJAX context
 * ทดสอบว่า session ถูกอ่านถูกต้องใน AJAX request หรือไม่
 */

// Start session FIRST
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

// Check if this is AJAX
$isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';

$response = [
    'is_ajax' => $isAjax,
    'session_status' => session_status(),
    'session_id' => session_id(),
    'has_admin_user' => isset($_SESSION['admin_user']),
    'admin_user' => $_SESSION['admin_user'] ?? null,
    'all_session_keys' => array_keys($_SESSION),
];

// Calculate what name would be used
$adminUser = $_SESSION['admin_user'] ?? null;
$adminName = 'Admin';
if (is_array($adminUser)) {
    if (!empty($adminUser['username'])) {
        $adminName = $adminUser['username'];
    } elseif (!empty($adminUser['display_name'])) {
        $adminName = $adminUser['display_name'];
    }
}
$response['calculated_admin_name'] = $adminName;
$response['sent_by_value'] = 'admin:' . $adminName;

echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
