<?php
/**
 * Test Notes API
 */
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

// Create table if not exists
$db->exec("CREATE TABLE IF NOT EXISTS `user_notes` (
    `id` int(11) NOT NULL AUTO_INCREMENT, 
    `user_id` int(11) NOT NULL, 
    `note` text, 
    `created_by` int(11), 
    `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP, 
    PRIMARY KEY (`id`), 
    KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

echo "<h2>Test Notes API</h2>";

// Test insert
if (isset($_POST['test_insert'])) {
    $userId = $_POST['user_id'];
    $note = $_POST['note'];
    
    try {
        $stmt = $db->prepare("INSERT INTO user_notes (user_id, note, created_at) VALUES (?, ?, NOW())");
        $stmt->execute([$userId, $note]);
        $noteId = $db->lastInsertId();
        echo "<p style='color:green'>✅ บันทึกสำเร็จ! ID: $noteId</p>";
    } catch (Exception $e) {
        echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
    }
}

// Debug info
echo "<h3>🔍 Debug Info:</h3>";

// Show user ID 13
echo "<h4>User ID 13:</h4>";
$stmt = $db->prepare("SELECT id, display_name, line_user_id FROM users WHERE id = ?");
$stmt->execute([13]);
$user13 = $stmt->fetch(PDO::FETCH_ASSOC);
echo "<pre>" . print_r($user13, true) . "</pre>";

// Show ALL notes in database
echo "<h4>โน๊ตทั้งหมดในฐานข้อมูล:</h4>";
$allNotes = $db->query("SELECT * FROM user_notes ORDER BY id DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
echo "<pre>" . print_r($allNotes, true) . "</pre>";

// Show notes for user 13 specifically
echo "<h4>โน๊ตของ User ID 13:</h4>";
$stmt = $db->prepare("SELECT * FROM user_notes WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([13]);
$notes13 = $stmt->fetchAll(PDO::FETCH_ASSOC);
if (empty($notes13)) {
    echo "<p style='color:orange'>⚠️ ไม่พบโน๊ตสำหรับ user_id = 13</p>";
} else {
    echo "<pre>" . print_r($notes13, true) . "</pre>";
}

// Show existing notes
echo "<h3>โน๊ตทั้งหมด (with user name):</h3>";
$stmt = $db->query("SELECT n.*, u.display_name FROM user_notes n LEFT JOIN users u ON n.user_id = u.id ORDER BY n.created_at DESC LIMIT 20");
$notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($notes)) {
    echo "<p>ยังไม่มีโน๊ต</p>";
} else {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>User ID</th><th>User Name</th><th>Note</th><th>Created</th></tr>";
    foreach ($notes as $n) {
        echo "<tr>";
        echo "<td>{$n['id']}</td>";
        echo "<td>{$n['user_id']}</td>";
        echo "<td>" . htmlspecialchars($n['display_name'] ?? '-') . "</td>";
        echo "<td>" . htmlspecialchars($n['note']) . "</td>";
        echo "<td>{$n['created_at']}</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Get users for dropdown
$users = $db->query("SELECT id, display_name FROM users ORDER BY display_name LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
?>

<h3>ทดสอบเพิ่มโน๊ต:</h3>
<form method="POST">
    <label>เลือกลูกค้า:</label><br>
    <select name="user_id" required>
        <?php foreach ($users as $u): ?>
        <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['display_name']) ?> (ID: <?= $u['id'] ?>)</option>
        <?php endforeach; ?>
    </select><br><br>
    
    <label>โน๊ต:</label><br>
    <textarea name="note" rows="3" cols="50" required></textarea><br><br>
    
    <button type="submit" name="test_insert">บันทึกโน๊ต</button>
</form>

<h3>ทดสอบ AJAX:</h3>
<button onclick="testAjax()">ทดสอบ AJAX บันทึกโน๊ต</button>
<div id="result"></div>

<script>
async function testAjax() {
    const userId = document.querySelector('select[name=user_id]').value;
    const note = 'ทดสอบ AJAX ' + new Date().toLocaleString();
    
    console.log('Testing AJAX with userId:', userId, 'note:', note);
    
    const formData = new FormData();
    formData.append('action', 'save_note');
    formData.append('user_id', userId);
    formData.append('note', note);
    
    try {
        const res = await fetch('messages.php', {
            method: 'POST',
            body: formData,
            headers: {'X-Requested-With': 'XMLHttpRequest'}
        });
        
        const text = await res.text();
        console.log('Response:', text);
        document.getElementById('result').innerHTML = '<pre>' + text + '</pre>';
        
        if (res.ok) {
            alert('สำเร็จ! ดู console และ result');
        }
    } catch (err) {
        console.error('Error:', err);
        document.getElementById('result').innerHTML = 'Error: ' + err.message;
    }
}
</script>
