<?php
ini_set('memory_limit', '512M');
header('Content-Type: text/plain; charset=utf-8');

echo "Testing CNY API (single SKU)...\n\n";

$url = 'https://manager.cnypharmacy.com/api/get_product_sku/0001';
$token = '90xcKekelCqCAjmgkpI1saJF6N55eiNexcI4hdcYM2M';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Authorization: Bearer ' . $token,
    'Accept: application/json'
));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "cURL Error: " . ($error ? $error : 'none') . "\n";
echo "Response Size: " . strlen($response) . " bytes\n\n";

// Try decode JSON first
$data = json_decode($response, true);

if ($data !== null) {
    echo "✅ Valid JSON response!\n\n";
    echo "Product Info:\n";
    echo "- SKU: " . ($data['sku'] ?? 'N/A') . "\n";
    echo "- Name: " . ($data['name_en'] ?? 'N/A') . "\n";
    echo "- Spec: " . ($data['spec_name'] ?? 'N/A') . "\n";
    echo "- Barcode: " . ($data['barcode'] ?? 'N/A') . "\n";
    
    if (isset($data['product_price']) && is_array($data['product_price'])) {
        echo "- Prices: " . count($data['product_price']) . " tiers\n";
    }
    
    echo "\n✅ API is working correctly!";
} else {
    echo "❌ JSON decode failed: " . json_last_error_msg() . "\n\n";
    echo "Response (first 500 chars):\n";
    echo substr($response, 0, 500);
}
