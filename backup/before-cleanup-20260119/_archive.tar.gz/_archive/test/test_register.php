<?php
/**
 * Test Register API
 */
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>Test Register API</h2>";

// Get a test user
$lineUserId = $_GET['line_user_id'] ?? '';
$lineAccountId = $_GET['account'] ?? 1;

if (empty($lineUserId)) {
    // Show form to select user
    echo "<h3>Select a user to test:</h3>";
    $stmt = $db->query("SELECT id, line_user_id, display_name, first_name, is_registered, member_id FROM users ORDER BY id DESC LIMIT 20");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Display Name</th><th>First Name</th><th>is_registered</th><th>member_id</th><th>Action</th></tr>";
    foreach ($users as $u) {
        $lineId = htmlspecialchars($u['line_user_id']);
        $regStatus = $u['is_registered'] ? '✅' : '❌';
        echo "<tr>";
        echo "<td>{$u['id']}</td>";
        echo "<td>{$u['display_name']}</td>";
        echo "<td>{$u['first_name']}</td>";
        echo "<td>{$regStatus}</td>";
        echo "<td>{$u['member_id']}</td>";
        echo "<td><a href='?line_user_id={$lineId}&account={$lineAccountId}'>Test Register</a></td>";
        echo "</tr>";
    }
    echo "</table>";
    exit;
}

// Test register
echo "<h3>Testing register for: $lineUserId</h3>";

// Check current status
$stmt = $db->prepare("SELECT * FROM users WHERE line_user_id = ?");
$stmt->execute([$lineUserId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

echo "<h4>Before Register:</h4>";
echo "<pre>";
echo "ID: " . ($user['id'] ?? 'N/A') . "\n";
echo "is_registered: " . ($user['is_registered'] ?? 'N/A') . "\n";
echo "member_id: " . ($user['member_id'] ?? 'N/A') . "\n";
echo "first_name: " . ($user['first_name'] ?? 'N/A') . "\n";
echo "</pre>";

// Simulate register
if (isset($_GET['do_register'])) {
    echo "<h4>Calling Register API...</h4>";
    
    $data = [
        'action' => 'register',
        'line_user_id' => $lineUserId,
        'line_account_id' => $lineAccountId,
        'first_name' => 'Test',
        'last_name' => 'User',
        'birthday' => '1990-01-01',
        'gender' => 'male'
    ];
    
    // Call API
    $ch = curl_init(BASE_URL . '/api/member.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "<p>HTTP Code: $httpCode</p>";
    echo "<p>Response:</p><pre>" . htmlspecialchars($response) . "</pre>";
    
    // Check after
    $stmt = $db->prepare("SELECT * FROM users WHERE line_user_id = ?");
    $stmt->execute([$lineUserId]);
    $userAfter = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h4>After Register:</h4>";
    echo "<pre>";
    echo "ID: " . ($userAfter['id'] ?? 'N/A') . "\n";
    echo "is_registered: " . ($userAfter['is_registered'] ?? 'N/A') . "\n";
    echo "member_id: " . ($userAfter['member_id'] ?? 'N/A') . "\n";
    echo "first_name: " . ($userAfter['first_name'] ?? 'N/A') . "\n";
    echo "</pre>";
    
    if ($userAfter['is_registered']) {
        echo "<p style='color:green'>✅ Registration successful!</p>";
    } else {
        echo "<p style='color:red'>❌ Registration failed - is_registered still 0</p>";
    }
} else {
    echo "<p><a href='?line_user_id=$lineUserId&account=$lineAccountId&do_register=1' style='padding:10px 20px; background:green; color:white; text-decoration:none; border-radius:5px;'>Click to Test Register</a></p>";
}

// Also check error log
echo "<h4>Recent Error Log:</h4>";
$errorLog = @file_get_contents('error_log');
if ($errorLog) {
    $lines = array_slice(explode("\n", $errorLog), -20);
    echo "<pre style='background:#f0f0f0; padding:10px; max-height:300px; overflow:auto;'>";
    foreach ($lines as $line) {
        if (strpos($line, 'Register') !== false) {
            echo "<strong style='color:blue'>" . htmlspecialchars($line) . "</strong>\n";
        } else {
            echo htmlspecialchars($line) . "\n";
        }
    }
    echo "</pre>";
}
