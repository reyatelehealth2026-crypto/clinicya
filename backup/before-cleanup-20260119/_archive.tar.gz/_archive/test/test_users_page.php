<?php
/**
 * Test Users Page - เหมือน users.php แต่แสดง error
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();
$pageTitle = 'Customers';

// ไม่ใช้ header.php เพื่อ test
require_once 'includes/auth_check.php';

// Get filter parameters
$tagFilter = isset($_GET['tag']) ? (int)$_GET['tag'] : null;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

// Build query
$whereConditions = ["1=1"];
$params = [];

if ($tagFilter) {
    $whereConditions[] = "EXISTS (SELECT 1 FROM user_tag_assignments uta WHERE uta.user_id = u.id AND uta.tag_id = ?)";
    $params[] = $tagFilter;
}

if ($search) {
    $whereConditions[] = "(u.display_name LIKE ? OR u.line_user_id LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$whereClause = implode(' AND ', $whereConditions);

// Get total count
$countSql = "SELECT COUNT(*) FROM users u WHERE {$whereClause}";
$stmt = $db->prepare($countSql);
$stmt->execute($params);
$totalUsers = $stmt->fetchColumn();
$totalPages = ceil($totalUsers / $perPage);

// Get users
$hasExtraCols = false;
try {
    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'real_name'");
    $hasExtraCols = $stmt->rowCount() > 0;
} catch (Exception $e) {}

$extraCols = $hasExtraCols ? ", u.real_name, u.phone, u.email, u.birthday" : ", NULL as real_name, NULL as phone, NULL as email, NULL as birthday";

$sql = "SELECT u.*{$extraCols},
        (SELECT GROUP_CONCAT(t.name SEPARATOR ', ') FROM user_tags t 
         JOIN user_tag_assignments uta ON t.id = uta.tag_id 
         WHERE uta.user_id = u.id) as tags,
        (SELECT COUNT(*) FROM messages m WHERE m.user_id = u.id) as message_count,
        (SELECT MAX(created_at) FROM messages m WHERE m.user_id = u.id) as last_message_at
        FROM users u 
        WHERE {$whereClause}
        ORDER BY u.created_at DESC
        LIMIT {$perPage} OFFSET {$offset}";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all tags
$allTags = [];
$currentBotId = $_SESSION['current_bot_id'] ?? null;
try {
    $stmt = $db->prepare("SELECT * FROM user_tags WHERE line_account_id = ? OR line_account_id IS NULL ORDER BY name");
    $stmt->execute([$currentBotId]);
    $allTags = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Users Page</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-6xl mx-auto">
        <h1 class="text-2xl font-bold mb-4">👥 Customers (Test Page)</h1>
        <p class="text-gray-600 mb-6">ทั้งหมด <?= number_format($totalUsers) ?> คน</p>
        
        <!-- Users Table -->
        <div class="bg-white rounded-xl shadow overflow-hidden">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ผู้ใช้</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">LINE Account</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tags</th>
                        <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">สถานะ</th>
                        <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Created</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <?php foreach ($users as $user): ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4">
                            <div class="flex items-center">
                                <img src="<?= $user['picture_url'] ?: 'https://via.placeholder.com/40' ?>" class="w-10 h-10 rounded-full object-cover mr-3">
                                <div>
                                    <p class="font-medium"><?= htmlspecialchars($user['display_name'] ?: 'Unknown') ?></p>
                                    <p class="text-xs text-gray-500"><?= substr($user['line_user_id'], 0, 15) ?>...</p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <span class="text-sm"><?= $user['line_account_id'] ?? 'NULL' ?></span>
                        </td>
                        <td class="px-6 py-4">
                            <?php if ($user['tags']): ?>
                                <?php foreach (explode(', ', $user['tags']) as $tagName): ?>
                                <span class="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs"><?= htmlspecialchars($tagName) ?></span>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <span class="text-gray-400 text-xs">-</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <?php if ($user['is_blocked']): ?>
                            <span class="px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs">Blocked</span>
                            <?php else: ?>
                            <span class="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">Active</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-center text-sm text-gray-500">
                            <?= date('d/m/Y H:i', strtotime($user['created_at'])) ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                            <i class="fas fa-users text-4xl text-gray-300 mb-3"></i>
                            <p>ไม่พบผู้ใช้</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="mt-4 text-center">
            <a href="users.php" class="text-blue-500 hover:underline">กลับไปหน้า users.php จริง</a>
        </div>
    </div>
</body>
</html>
