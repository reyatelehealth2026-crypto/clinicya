<?php
/**
 * Test Gemini API
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

$apiKey = $_GET['key'] ?? '';

echo "<h1>Test Gemini API</h1>";

if (!$apiKey) {
    echo "<form method='get'>";
    echo "<p>Gemini API Key: <input type='text' name='key' size='50' placeholder='AIza...'></p>";
    echo "<button type='submit'>Test</button>";
    echo "</form>";
    echo "<p><a href='https://aistudio.google.com/app/apikey' target='_blank'>Get API Key here</a></p>";
    exit;
}

echo "<p>Testing API Key: " . substr($apiKey, 0, 10) . "...</p>";

$models = [
    'gemini-2.0-flash',
    'gemini-2.5-flash',
    'gemini-flash-latest',
    'gemini-2.0-flash-lite'
];

foreach ($models as $model) {
    echo "<h3>Testing: $model</h3>";
    
    $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $apiKey;
    
    $data = [
        'contents' => [
            ['parts' => [['text' => 'Say hello in Thai']]]
        ]
    ];
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    echo "<p>HTTP Code: <b>$httpCode</b></p>";
    
    if ($curlError) {
        echo "<p style='color:red'>cURL Error: $curlError</p>";
        continue;
    }
    
    $result = json_decode($response, true);
    
    if ($httpCode === 200) {
        $text = $result['candidates'][0]['content']['parts'][0]['text'] ?? 'No text';
        echo "<p style='color:green'>✅ Success: $text</p>";
        break;
    } else {
        $error = $result['error']['message'] ?? $response;
        echo "<p style='color:red'>❌ Error: $error</p>";
    }
}

echo "<hr><h3>Available Models:</h3>";

// List available models
$listUrl = "https://generativelanguage.googleapis.com/v1beta/models?key=" . $apiKey;
$ch = curl_init($listUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false
]);
$listResponse = curl_exec($ch);
curl_close($ch);

$models = json_decode($listResponse, true);
if (isset($models['models'])) {
    echo "<ul>";
    foreach ($models['models'] as $m) {
        $name = $m['name'] ?? '';
        $methods = implode(', ', $m['supportedGenerationMethods'] ?? []);
        if (strpos($methods, 'generateContent') !== false) {
            echo "<li><b>" . htmlspecialchars($name) . "</b> - $methods</li>";
        }
    }
    echo "</ul>";
} else {
    echo "<p style='color:red'>Cannot list models: " . htmlspecialchars($listResponse) . "</p>";
}

echo "<hr><h3>Raw Response:</h3>";
echo "<pre>" . htmlspecialchars(json_encode($result ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) . "</pre>";
