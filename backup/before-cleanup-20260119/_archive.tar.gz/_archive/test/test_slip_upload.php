<?php
/**
 * Test Slip Upload
 * ทดสอบอัพโหลดสลิปโดยตรง
 */
header('Content-Type: text/html; charset=utf-8');
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h1>🧾 Test Slip Upload</h1>";

// Get latest order
$stmt = $db->query("SELECT id, order_number, user_id FROM transactions ORDER BY id DESC LIMIT 1");
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    echo "<p style='color:red'>ไม่มี order ในระบบ</p>";
    exit;
}

echo "<p>Order ID: {$order['id']}</p>";
echo "<p>Order Number: {$order['order_number']}</p>";

// Handle upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['slip'])) {
    echo "<h2>Processing Upload...</h2>";
    
    $file = $_FILES['slip'];
    echo "<p>File name: {$file['name']}</p>";
    echo "<p>File type: {$file['type']}</p>";
    echo "<p>File size: {$file['size']}</p>";
    echo "<p>File error: {$file['error']}</p>";
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        // Create upload directory
        $uploadDir = __DIR__ . '/uploads/slips/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
            echo "<p style='color:green'>✅ Created upload directory</p>";
        }
        
        // Generate filename
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION) ?: 'jpg';
        $filename = 'slip_' . $order['order_number'] . '_' . time() . '.' . $ext;
        $filepath = $uploadDir . $filename;
        
        echo "<p>Target path: {$filepath}</p>";
        
        // Move file
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            echo "<p style='color:green'>✅ File moved successfully!</p>";
            
            $imageUrl = BASE_URL . '/uploads/slips/' . $filename;
            echo "<p>Image URL: <a href='{$imageUrl}' target='_blank'>{$imageUrl}</a></p>";
            
            // Try to insert into payment_slips
            echo "<h3>Inserting into payment_slips...</h3>";
            
            try {
                $stmt = $db->prepare("INSERT INTO payment_slips (order_id, transaction_id, user_id, image_url, status) VALUES (?, ?, ?, ?, 'pending')");
                $stmt->execute([$order['id'], $order['id'], $order['user_id'], $imageUrl]);
                $slipId = $db->lastInsertId();
                echo "<p style='color:green'>✅ INSERT สำเร็จ! Slip ID: {$slipId}</p>";
            } catch (Exception $e) {
                echo "<p style='color:red'>❌ INSERT Error: " . $e->getMessage() . "</p>";
                
                // Try without user_id
                echo "<p>Trying without user_id...</p>";
                try {
                    $stmt = $db->prepare("INSERT INTO payment_slips (order_id, transaction_id, image_url, status) VALUES (?, ?, ?, 'pending')");
                    $stmt->execute([$order['id'], $order['id'], $imageUrl]);
                    $slipId = $db->lastInsertId();
                    echo "<p style='color:green'>✅ INSERT สำเร็จ (without user_id)! Slip ID: {$slipId}</p>";
                } catch (Exception $e2) {
                    echo "<p style='color:red'>❌ INSERT Error (retry): " . $e2->getMessage() . "</p>";
                }
            }
            
            // Verify
            echo "<h3>Verifying...</h3>";
            $stmt = $db->query("SELECT * FROM payment_slips ORDER BY id DESC LIMIT 1");
            $slip = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($slip) {
                echo "<p style='color:green'>✅ พบสลิปในระบบ!</p>";
                echo "<pre>" . print_r($slip, true) . "</pre>";
            } else {
                echo "<p style='color:red'>❌ ไม่พบสลิปในระบบ</p>";
            }
            
        } else {
            echo "<p style='color:red'>❌ Failed to move file</p>";
            echo "<p>Check directory permissions!</p>";
        }
    } else {
        echo "<p style='color:red'>❌ Upload error: {$file['error']}</p>";
    }
}
?>

<h2>Upload Test Form</h2>
<form method="POST" enctype="multipart/form-data">
    <p>
        <label>เลือกรูปสลิป:</label><br>
        <input type="file" name="slip" accept="image/*" required>
    </p>
    <p>
        <button type="submit" style="padding: 10px 20px; background: #11B0A6; color: white; border: none; border-radius: 5px; cursor: pointer;">
            📤 Upload Slip
        </button>
    </p>
</form>

<hr>
<p><a href="debug_payment_slips.php?order_id=<?= $order['id'] ?>">🔍 Debug Payment Slips</a></p>
