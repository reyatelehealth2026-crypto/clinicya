<?php
/**
 * Test inserting payment slip directly
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>Test Payment Slip Insert</h2>";

// Get latest transaction
$stmt = $db->query("SELECT * FROM transactions ORDER BY id DESC LIMIT 1");
$txn = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$txn) {
    die("No transactions found");
}

echo "<p>Latest transaction: ID={$txn['id']}, #{$txn['order_number']}</p>";

// Check payment_slips table structure
echo "<h3>1. payment_slips columns</h3>";
$stmt = $db->query("DESCRIBE payment_slips");
$cols = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<ul>";
foreach ($cols as $c) {
    echo "<li>{$c['Field']} - {$c['Type']} - Null:{$c['Null']} - Default:{$c['Default']}</li>";
}
echo "</ul>";

// Try to insert
echo "<h3>2. Test Insert</h3>";
if (isset($_GET['insert'])) {
    $testUrl = 'https://example.com/test_slip_' . time() . '.jpg';
    
    echo "<p>Trying to insert: transaction_id={$txn['id']}, user_id={$txn['user_id']}, image_url={$testUrl}</p>";
    
    try {
        $stmt = $db->prepare("INSERT INTO payment_slips (transaction_id, user_id, image_url, status) VALUES (?, ?, ?, 'pending')");
        $stmt->execute([$txn['id'], $txn['user_id'], $testUrl]);
        $insertId = $db->lastInsertId();
        echo "<p style='color:green'>✅ SUCCESS! Inserted with ID: {$insertId}</p>";
        
        // Verify
        $stmt = $db->prepare("SELECT * FROM payment_slips WHERE id = ?");
        $stmt->execute([$insertId]);
        $slip = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<pre>" . print_r($slip, true) . "</pre>";
        
        // Delete test record
        $db->exec("DELETE FROM payment_slips WHERE id = {$insertId}");
        echo "<p>Test record deleted</p>";
        
    } catch (Exception $e) {
        echo "<p style='color:red'>❌ ERROR: " . $e->getMessage() . "</p>";
        
        // Try without user_id
        echo "<p>Trying without user_id...</p>";
        try {
            $stmt = $db->prepare("INSERT INTO payment_slips (transaction_id, image_url, status) VALUES (?, ?, 'pending')");
            $stmt->execute([$txn['id'], $testUrl]);
            echo "<p style='color:green'>✅ SUCCESS without user_id!</p>";
            $db->exec("DELETE FROM payment_slips WHERE image_url = '{$testUrl}'");
        } catch (Exception $e2) {
            echo "<p style='color:red'>❌ ERROR: " . $e2->getMessage() . "</p>";
        }
    }
} else {
    echo "<p><a href='?insert=1'>Click to test insert</a></p>";
}

// Show existing slips
echo "<h3>3. Existing slips for this transaction</h3>";
$stmt = $db->prepare("SELECT * FROM payment_slips WHERE transaction_id = ?");
$stmt->execute([$txn['id']]);
$slips = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($slips)) {
    echo "<p style='color:orange'>⚠️ No slips found for transaction #{$txn['id']}</p>";
} else {
    echo "<pre>" . print_r($slips, true) . "</pre>";
}

// Check uploads/slips directory
echo "<h3>4. Recent slip files</h3>";
$slipDir = __DIR__ . '/uploads/slips/';
if (is_dir($slipDir)) {
    $files = array_diff(scandir($slipDir), ['.', '..']);
    rsort($files);
    $files = array_slice($files, 0, 5);
    echo "<ul>";
    foreach ($files as $f) {
        // Check if this file is in database
        $stmt = $db->prepare("SELECT id, transaction_id FROM payment_slips WHERE image_url LIKE ?");
        $stmt->execute(['%' . $f]);
        $dbSlip = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $status = $dbSlip ? "✅ In DB (slip_id={$dbSlip['id']}, txn_id={$dbSlip['transaction_id']})" : "❌ NOT in DB";
        echo "<li>{$f} - {$status}</li>";
    }
    echo "</ul>";
} else {
    echo "<p>uploads/slips/ directory not found</p>";
}
