<?php
/**
 * Shop System Test Suite
 * ทดสอบระบบร้านค้าทั้งหมด
 * 
 * รันด้วย: php test_shop.php
 */

require_once 'config/config.php';
require_once 'config/database.php';

// Colors for CLI output
define('GREEN', "\033[32m");
define('RED', "\033[31m");
define('YELLOW', "\033[33m");
define('BLUE', "\033[34m");
define('RESET', "\033[0m");

class ShopTester
{
    private $db;
    private $passed = 0;
    private $failed = 0;
    private $warnings = 0;
    private $results = [];

    public function __construct()
    {
        try {
            $this->db = Database::getInstance()->getConnection();
            $this->log("✅ Database connected", 'success');
        } catch (Exception $e) {
            $this->log("❌ Database connection failed: " . $e->getMessage(), 'error');
            exit(1);
        }
    }

    private function log($message, $type = 'info')
    {
        $prefix = '';
        switch ($type) {
            case 'success':
                $prefix = GREEN;
                break;
            case 'error':
                $prefix = RED;
                break;
            case 'warning':
                $prefix = YELLOW;
                break;
            case 'info':
                $prefix = BLUE;
                break;
        }
        echo $prefix . $message . RESET . "\n";
    }

    private function assert($condition, $testName, $details = '')
    {
        if ($condition) {
            $this->passed++;
            $this->results[] = ['test' => $testName, 'status' => 'PASS'];
            $this->log("  ✓ {$testName}", 'success');
            return true;
        } else {
            $this->failed++;
            $this->results[] = ['test' => $testName, 'status' => 'FAIL', 'details' => $details];
            $this->log("  ✗ {$testName}" . ($details ? " - {$details}" : ''), 'error');
            return false;
        }
    }

    private function warn($testName, $message)
    {
        $this->warnings++;
        $this->results[] = ['test' => $testName, 'status' => 'WARN', 'details' => $message];
        $this->log("  ⚠ {$testName} - {$message}", 'warning');
    }

    /**
     * ตรวจสอบว่าตารางมีอยู่หรือไม่
     */
    private function tableExists($table)
    {
        try {
            $this->db->query("SELECT 1 FROM {$table} LIMIT 1");
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * ตรวจสอบว่าตารางมี column หรือไม่
     */
    private function columnExists($table, $column)
    {
        try {
            $stmt = $this->db->query("SHOW COLUMNS FROM {$table} LIKE '{$column}'");
            return $stmt->rowCount() > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Test 1: ตรวจสอบตารางที่จำเป็น
     */
    public function testRequiredTables()
    {
        $this->log("\n📋 Test 1: Required Tables", 'info');
        
        $requiredTables = [
            'shop_settings' => 'ตั้งค่าร้านค้า',
            'product_categories' => 'หมวดหมู่สินค้า',
            'products' => 'สินค้า',
            'cart_items' => 'ตะกร้าสินค้า',
            'orders' => 'คำสั่งซื้อ',
            'order_items' => 'รายการในคำสั่งซื้อ',
        ];

        $optionalTables = [
            'payment_slips' => 'สลิปการชำระเงิน',
            'user_states' => 'สถานะผู้ใช้',
            'coupons' => 'คูปอง',
            'coupon_usage' => 'การใช้คูปอง',
        ];

        foreach ($requiredTables as $table => $desc) {
            $this->assert($this->tableExists($table), "Table '{$table}' exists ({$desc})");
        }

        foreach ($optionalTables as $table => $desc) {
            if ($this->tableExists($table)) {
                $this->log("  ✓ Optional table '{$table}' exists ({$desc})", 'success');
            } else {
                $this->warn("Optional table '{$table}'", "Not found - {$desc}");
            }
        }
    }

    /**
     * Test 2: ตรวจสอบโครงสร้างตาราง shop_settings
     */
    public function testShopSettingsStructure()
    {
        $this->log("\n📋 Test 2: Shop Settings Structure", 'info');

        if (!$this->tableExists('shop_settings')) {
            $this->log("  ⏭ Skipped - table not exists", 'warning');
            return;
        }

        $requiredColumns = [
            'id', 'shop_name', 'welcome_message', 'shipping_fee', 
            'free_shipping_min', 'bank_accounts', 'promptpay_number', 
            'contact_phone', 'is_open'
        ];

        foreach ($requiredColumns as $col) {
            $this->assert($this->columnExists('shop_settings', $col), "Column 'shop_settings.{$col}' exists");
        }

        // Check for multi-bot support
        if ($this->columnExists('shop_settings', 'line_account_id')) {
            $this->log("  ✓ Multi-bot support enabled (line_account_id)", 'success');
        } else {
            $this->warn("Multi-bot support", "Column 'line_account_id' not found");
        }
    }

    /**
     * Test 3: ตรวจสอบโครงสร้างตาราง products
     */
    public function testProductsStructure()
    {
        $this->log("\n📋 Test 3: Products Structure", 'info');

        if (!$this->tableExists('products')) {
            $this->log("  ⏭ Skipped - table not exists", 'warning');
            return;
        }

        $requiredColumns = [
            'id', 'name', 'description', 'price', 'sale_price', 
            'stock', 'image_url', 'is_active', 'category_id'
        ];

        foreach ($requiredColumns as $col) {
            $this->assert($this->columnExists('products', $col), "Column 'products.{$col}' exists");
        }

        // V2.5 columns
        $v25Columns = ['item_type', 'delivery_method', 'sku'];
        foreach ($v25Columns as $col) {
            if ($this->columnExists('products', $col)) {
                $this->log("  ✓ V2.5 column 'products.{$col}' exists", 'success');
            }
        }
    }

    /**
     * Test 4: ตรวจสอบโครงสร้างตาราง orders
     */
    public function testOrdersStructure()
    {
        $this->log("\n📋 Test 4: Orders Structure", 'info');

        if (!$this->tableExists('orders')) {
            $this->log("  ⏭ Skipped - table not exists", 'warning');
            return;
        }

        $requiredColumns = [
            'id', 'order_number', 'user_id', 'status', 'payment_status',
            'grand_total', 'shipping_fee', 'created_at'
        ];

        foreach ($requiredColumns as $col) {
            $this->assert($this->columnExists('orders', $col), "Column 'orders.{$col}' exists");
        }
    }

    /**
     * Test 5: ตรวจสอบข้อมูลเริ่มต้น
     */
    public function testDefaultData()
    {
        $this->log("\n📋 Test 5: Default Data", 'info');

        // Shop settings
        if ($this->tableExists('shop_settings')) {
            $stmt = $this->db->query("SELECT COUNT(*) as c FROM shop_settings");
            $count = $stmt->fetch()['c'];
            $this->assert($count > 0, "Shop settings has default data", "Found {$count} records");
        }

        // Categories
        if ($this->tableExists('product_categories')) {
            $stmt = $this->db->query("SELECT COUNT(*) as c FROM product_categories");
            $count = $stmt->fetch()['c'];
            if ($count > 0) {
                $this->log("  ✓ Categories: {$count} records", 'success');
            } else {
                $this->warn("Categories", "No categories found");
            }
        }

        // Products
        if ($this->tableExists('products')) {
            $stmt = $this->db->query("SELECT COUNT(*) as c FROM products");
            $count = $stmt->fetch()['c'];
            $this->log("  ℹ Products: {$count} records", 'info');
        }
    }

    /**
     * Test 6: ทดสอบ CRUD Operations
     */
    public function testCRUDOperations()
    {
        $this->log("\n📋 Test 6: CRUD Operations", 'info');

        if (!$this->tableExists('products') || !$this->tableExists('product_categories')) {
            $this->log("  ⏭ Skipped - required tables not exist", 'warning');
            return;
        }

        try {
            // Create test category
            $testCatName = 'TEST_CAT_' . time();
            $stmt = $this->db->prepare("INSERT INTO product_categories (name, is_active) VALUES (?, 1)");
            $stmt->execute([$testCatName]);
            $catId = $this->db->lastInsertId();
            $this->assert($catId > 0, "Create category", "ID: {$catId}");

            // Create test product
            $testProdName = 'TEST_PROD_' . time();
            $stmt = $this->db->prepare("INSERT INTO products (category_id, name, price, stock, is_active) VALUES (?, ?, 100, 10, 1)");
            $stmt->execute([$catId, $testProdName]);
            $prodId = $this->db->lastInsertId();
            $this->assert($prodId > 0, "Create product", "ID: {$prodId}");

            // Read
            $stmt = $this->db->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$prodId]);
            $product = $stmt->fetch();
            $this->assert($product && $product['name'] === $testProdName, "Read product");

            // Update
            $stmt = $this->db->prepare("UPDATE products SET price = 200 WHERE id = ?");
            $stmt->execute([$prodId]);
            $stmt = $this->db->prepare("SELECT price FROM products WHERE id = ?");
            $stmt->execute([$prodId]);
            $newPrice = $stmt->fetchColumn();
            $this->assert($newPrice == 200, "Update product price");

            // Delete
            $stmt = $this->db->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$prodId]);
            $stmt = $this->db->prepare("DELETE FROM product_categories WHERE id = ?");
            $stmt->execute([$catId]);
            $this->assert(true, "Delete test data");

        } catch (Exception $e) {
            $this->assert(false, "CRUD Operations", $e->getMessage());
        }
    }

    /**
     * Test 7: ทดสอบ Cart Operations
     */
    public function testCartOperations()
    {
        $this->log("\n📋 Test 7: Cart Operations", 'info');

        if (!$this->tableExists('cart_items') || !$this->tableExists('products')) {
            $this->log("  ⏭ Skipped - required tables not exist", 'warning');
            return;
        }

        try {
            // Create test product
            $stmt = $this->db->prepare("INSERT INTO products (name, price, stock, is_active) VALUES ('CART_TEST', 100, 10, 1)");
            $stmt->execute();
            $prodId = $this->db->lastInsertId();

            // Add to cart (user_id = 99999 for test)
            $testUserId = 99999;
            $stmt = $this->db->prepare("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, 2)");
            $stmt->execute([$testUserId, $prodId]);
            $this->assert(true, "Add to cart");

            // Update quantity (ON DUPLICATE KEY)
            $stmt = $this->db->prepare("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE quantity = quantity + 1");
            $stmt->execute([$testUserId, $prodId]);
            
            $stmt = $this->db->prepare("SELECT quantity FROM cart_items WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$testUserId, $prodId]);
            $qty = $stmt->fetchColumn();
            $this->assert($qty == 3, "Update cart quantity", "Expected 3, got {$qty}");

            // Clear cart
            $stmt = $this->db->prepare("DELETE FROM cart_items WHERE user_id = ?");
            $stmt->execute([$testUserId]);
            $this->assert(true, "Clear cart");

            // Cleanup
            $stmt = $this->db->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$prodId]);

        } catch (Exception $e) {
            $this->assert(false, "Cart Operations", $e->getMessage());
        }
    }

    /**
     * Test 8: ทดสอบ Order Flow
     */
    public function testOrderFlow()
    {
        $this->log("\n📋 Test 8: Order Flow", 'info');

        if (!$this->tableExists('orders') || !$this->tableExists('order_items')) {
            $this->log("  ⏭ Skipped - required tables not exist", 'warning');
            return;
        }

        try {
            $testUserId = 99999;
            $orderNumber = 'TEST' . date('ymdHis');

            // Create order
            $stmt = $this->db->prepare("INSERT INTO orders (order_number, user_id, grand_total, status, payment_status) VALUES (?, ?, 500, 'pending', 'pending')");
            $stmt->execute([$orderNumber, $testUserId]);
            $orderId = $this->db->lastInsertId();
            $this->assert($orderId > 0, "Create order", "Order #{$orderNumber}");

            // Add order items (check column name - some use 'price', some use 'product_price')
            $priceCol = $this->columnExists('order_items', 'product_price') ? 'product_price' : 'price';
            $stmt = $this->db->prepare("INSERT INTO order_items (order_id, product_name, {$priceCol}, quantity, subtotal) VALUES (?, 'Test Product', 100, 5, 500)");
            $stmt->execute([$orderId]);
            $this->assert(true, "Add order items");

            // Update status
            $stmt = $this->db->prepare("UPDATE orders SET status = 'confirmed' WHERE id = ?");
            $stmt->execute([$orderId]);
            
            $stmt = $this->db->prepare("SELECT status FROM orders WHERE id = ?");
            $stmt->execute([$orderId]);
            $status = $stmt->fetchColumn();
            $this->assert($status === 'confirmed', "Update order status");

            // Update payment status
            $stmt = $this->db->prepare("UPDATE orders SET payment_status = 'paid', status = 'paid' WHERE id = ?");
            $stmt->execute([$orderId]);
            $this->assert(true, "Update payment status");

            // Cleanup
            $stmt = $this->db->prepare("DELETE FROM order_items WHERE order_id = ?");
            $stmt->execute([$orderId]);
            $stmt = $this->db->prepare("DELETE FROM orders WHERE id = ?");
            $stmt->execute([$orderId]);
            $this->assert(true, "Cleanup test order");

        } catch (Exception $e) {
            $this->assert(false, "Order Flow", $e->getMessage());
        }
    }

    /**
     * Test 9: ทดสอบ ShopBot Class
     */
    public function testShopBotClass()
    {
        $this->log("\n📋 Test 9: ShopBot Class", 'info');

        $shopBotFile = __DIR__ . '/classes/ShopBot.php';
        
        $this->assert(file_exists($shopBotFile), "ShopBot.php exists");

        if (!file_exists($shopBotFile)) {
            return;
        }

        require_once $shopBotFile;
        $this->assert(class_exists('ShopBot'), "ShopBot class defined");

        if (!class_exists('ShopBot')) {
            return;
        }

        // Check required methods
        $requiredMethods = [
            'handleCommand',
            'showMainMenu',
            'showCart',
            'addToCart',
            'removeFromCart',
            'checkout',
            'showOrders',
            'showOrderDetail',
        ];

        foreach ($requiredMethods as $method) {
            $this->assert(method_exists('ShopBot', $method), "Method ShopBot::{$method}() exists");
        }
    }

    /**
     * Test 10: ทดสอบ Shop Pages
     */
    public function testShopPages()
    {
        $this->log("\n📋 Test 10: Shop Pages", 'info');

        $pages = [
            'shop/products.php' => 'Products management',
            'shop/categories.php' => 'Categories management',
            'shop/orders.php' => 'Orders management',
            'shop/order-detail.php' => 'Order detail',
            'shop/settings.php' => 'Shop settings',
        ];

        foreach ($pages as $file => $desc) {
            $this->assert(file_exists(__DIR__ . '/' . $file), "Page '{$file}' exists ({$desc})");
        }
    }

    /**
     * Test 11: ทดสอบ Foreign Keys และ Relationships
     */
    public function testRelationships()
    {
        $this->log("\n📋 Test 11: Relationships", 'info');

        if (!$this->tableExists('products') || !$this->tableExists('product_categories')) {
            $this->log("  ⏭ Skipped - required tables not exist", 'warning');
            return;
        }

        try {
            // Test products -> categories relationship
            $stmt = $this->db->query("
                SELECT p.id, p.name, c.name as category_name 
                FROM products p 
                LEFT JOIN product_categories c ON p.category_id = c.id 
                LIMIT 1
            ");
            $this->assert(true, "Products -> Categories JOIN works");

            // Test orders -> order_items relationship
            if ($this->tableExists('orders') && $this->tableExists('order_items')) {
                $stmt = $this->db->query("
                    SELECT o.id, o.order_number, COUNT(oi.id) as item_count 
                    FROM orders o 
                    LEFT JOIN order_items oi ON o.id = oi.order_id 
                    GROUP BY o.id 
                    LIMIT 1
                ");
                $this->assert(true, "Orders -> Order Items JOIN works");
            }

        } catch (Exception $e) {
            $this->assert(false, "Relationships", $e->getMessage());
        }
    }

    /**
     * Test 12: ทดสอบ Data Integrity
     */
    public function testDataIntegrity()
    {
        $this->log("\n📋 Test 12: Data Integrity", 'info');

        try {
            // Check for orphan order items
            if ($this->tableExists('orders') && $this->tableExists('order_items')) {
                $stmt = $this->db->query("
                    SELECT COUNT(*) as c FROM order_items oi 
                    LEFT JOIN orders o ON oi.order_id = o.id 
                    WHERE o.id IS NULL
                ");
                $orphans = $stmt->fetch()['c'];
                if ($orphans == 0) {
                    $this->log("  ✓ No orphan order items", 'success');
                } else {
                    $this->warn("Orphan order items", "{$orphans} items without orders");
                }
            }

            // Check for products with invalid category
            if ($this->tableExists('products') && $this->tableExists('product_categories')) {
                $stmt = $this->db->query("
                    SELECT COUNT(*) as c FROM products p 
                    LEFT JOIN product_categories c ON p.category_id = c.id 
                    WHERE p.category_id IS NOT NULL AND c.id IS NULL
                ");
                $invalid = $stmt->fetch()['c'];
                if ($invalid == 0) {
                    $this->log("  ✓ All products have valid categories", 'success');
                } else {
                    $this->warn("Invalid categories", "{$invalid} products with invalid category_id");
                }
            }

            // Check for negative stock
            if ($this->tableExists('products')) {
                $stmt = $this->db->query("SELECT COUNT(*) as c FROM products WHERE stock < 0");
                $negative = $stmt->fetch()['c'];
                if ($negative == 0) {
                    $this->log("  ✓ No negative stock values", 'success');
                } else {
                    $this->warn("Negative stock", "{$negative} products with negative stock");
                }
            }

            // Check for invalid prices
            if ($this->tableExists('products')) {
                $stmt = $this->db->query("SELECT COUNT(*) as c FROM products WHERE price < 0 OR (sale_price IS NOT NULL AND sale_price < 0)");
                $invalid = $stmt->fetch()['c'];
                if ($invalid == 0) {
                    $this->log("  ✓ No invalid prices", 'success');
                } else {
                    $this->warn("Invalid prices", "{$invalid} products with negative prices");
                }
            }

        } catch (Exception $e) {
            $this->assert(false, "Data Integrity", $e->getMessage());
        }
    }

    /**
     * Test 13: ทดสอบ Payment Slips
     */
    public function testPaymentSlips()
    {
        $this->log("\n📋 Test 13: Payment Slips", 'info');

        if (!$this->tableExists('payment_slips')) {
            $this->warn("Payment slips table", "Not found - run migration_shop_complete.sql");
            return;
        }

        $requiredColumns = ['id', 'order_id', 'user_id', 'slip_image', 'status', 'created_at'];
        foreach ($requiredColumns as $col) {
            $this->assert($this->columnExists('payment_slips', $col), "Column 'payment_slips.{$col}' exists");
        }
    }

    /**
     * Test 14: ทดสอบ Coupons
     */
    public function testCoupons()
    {
        $this->log("\n📋 Test 14: Coupons", 'info');

        if (!$this->tableExists('coupons')) {
            $this->warn("Coupons table", "Not found - optional feature");
            return;
        }

        $requiredColumns = ['id', 'code', 'discount_type', 'discount_value', 'is_active'];
        foreach ($requiredColumns as $col) {
            $this->assert($this->columnExists('coupons', $col), "Column 'coupons.{$col}' exists");
        }
    }

    /**
     * Test 15: Performance Check
     */
    public function testPerformance()
    {
        $this->log("\n📋 Test 15: Performance Check", 'info');

        try {
            // Check indexes on products
            if ($this->tableExists('products')) {
                $stmt = $this->db->query("SHOW INDEX FROM products");
                $indexes = $stmt->fetchAll();
                $indexNames = array_column($indexes, 'Key_name');
                
                if (in_array('idx_category', $indexNames) || in_array('category_id', $indexNames)) {
                    $this->log("  ✓ Index on products.category_id exists", 'success');
                } else {
                    $this->warn("Missing index", "products.category_id should be indexed");
                }
            }

            // Check indexes on orders
            if ($this->tableExists('orders')) {
                $stmt = $this->db->query("SHOW INDEX FROM orders");
                $indexes = $stmt->fetchAll();
                $indexNames = array_column($indexes, 'Key_name');
                
                if (in_array('idx_user', $indexNames) || in_array('user_id', $indexNames)) {
                    $this->log("  ✓ Index on orders.user_id exists", 'success');
                }
                
                if (in_array('idx_status', $indexNames) || in_array('status', $indexNames)) {
                    $this->log("  ✓ Index on orders.status exists", 'success');
                }
            }

        } catch (Exception $e) {
            $this->warn("Performance check", $e->getMessage());
        }
    }

    /**
     * รันทุก test
     */
    public function runAll()
    {
        $this->log("\n" . str_repeat("=", 60), 'info');
        $this->log("🛒 SHOP SYSTEM TEST SUITE", 'info');
        $this->log(str_repeat("=", 60), 'info');
        $this->log("Started at: " . date('Y-m-d H:i:s'), 'info');

        $startTime = microtime(true);

        $this->testRequiredTables();
        $this->testShopSettingsStructure();
        $this->testProductsStructure();
        $this->testOrdersStructure();
        $this->testDefaultData();
        $this->testCRUDOperations();
        $this->testCartOperations();
        $this->testOrderFlow();
        $this->testShopBotClass();
        $this->testShopPages();
        $this->testRelationships();
        $this->testDataIntegrity();
        $this->testPaymentSlips();
        $this->testCoupons();
        $this->testPerformance();

        $endTime = microtime(true);
        $duration = round($endTime - $startTime, 2);

        $this->printSummary($duration);
    }

    /**
     * แสดงสรุปผล
     */
    private function printSummary($duration)
    {
        $total = $this->passed + $this->failed;
        $passRate = $total > 0 ? round(($this->passed / $total) * 100, 1) : 0;

        $this->log("\n" . str_repeat("=", 60), 'info');
        $this->log("📊 TEST SUMMARY", 'info');
        $this->log(str_repeat("=", 60), 'info');
        
        $this->log("✅ Passed:   {$this->passed}", 'success');
        $this->log("❌ Failed:   {$this->failed}", $this->failed > 0 ? 'error' : 'info');
        $this->log("⚠️  Warnings: {$this->warnings}", $this->warnings > 0 ? 'warning' : 'info');
        $this->log("📈 Pass Rate: {$passRate}%", $passRate >= 80 ? 'success' : ($passRate >= 50 ? 'warning' : 'error'));
        $this->log("⏱️  Duration: {$duration}s", 'info');

        if ($this->failed > 0) {
            $this->log("\n❌ FAILED TESTS:", 'error');
            foreach ($this->results as $r) {
                if ($r['status'] === 'FAIL') {
                    $this->log("  - {$r['test']}" . (isset($r['details']) ? ": {$r['details']}" : ''), 'error');
                }
            }
        }

        if ($this->warnings > 0) {
            $this->log("\n⚠️  WARNINGS:", 'warning');
            foreach ($this->results as $r) {
                if ($r['status'] === 'WARN') {
                    $this->log("  - {$r['test']}: {$r['details']}", 'warning');
                }
            }
        }

        $this->log("\n" . str_repeat("=", 60), 'info');
        
        if ($this->failed === 0) {
            $this->log("🎉 ALL TESTS PASSED!", 'success');
        } else {
            $this->log("💡 Fix the failed tests and run again", 'warning');
        }
        
        $this->log(str_repeat("=", 60) . "\n", 'info');
    }
}

// Run tests
$tester = new ShopTester();
$tester->runAll();
