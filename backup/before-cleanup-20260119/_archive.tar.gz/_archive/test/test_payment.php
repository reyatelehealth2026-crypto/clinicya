<?php
/**
 * Test Payment/Checkout System
 * ทดสอบระบบชำระเงินและ checkout flow
 */
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h1>🧪 Test Payment/Checkout System</h1>";
echo "<style>
body { font-family: sans-serif; padding: 20px; max-width: 1200px; margin: 0 auto; }
.ok { color: green; }
.error { color: red; }
.warn { color: orange; }
.info { color: blue; }
pre { background: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background: #f5f5f5; }
.section { background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin: 15px 0; }
</style>";

// 1. Check required tables
echo "<div class='section'>";
echo "<h2>1. ตรวจสอบตารางที่จำเป็น</h2>";

$requiredTables = [
    'orders' => 'คำสั่งซื้อ',
    'order_items' => 'รายการสินค้าในคำสั่งซื้อ',
    'payment_slips' => 'สลิปการชำระเงิน',
    'user_states' => 'สถานะผู้ใช้ (checkout flow)',
    'cart_items' => 'ตะกร้าสินค้า',
    'products' => 'สินค้า',
    'shop_settings' => 'ตั้งค่าร้านค้า'
];

$missingTables = [];
foreach ($requiredTables as $table => $desc) {
    try {
        $db->query("SELECT 1 FROM {$table} LIMIT 1");
        echo "<p class='ok'>✅ {$table} - {$desc}</p>";
    } catch (Exception $e) {
        echo "<p class='error'>❌ {$table} - {$desc} (ไม่พบ)</p>";
        $missingTables[] = $table;
    }
}

if (!empty($missingTables)) {
    echo "<p class='warn'>⚠️ กรุณารัน migration: <code>database/migration_shop_complete.sql</code></p>";
}
echo "</div>";

// 2. Check payment_slips columns
echo "<div class='section'>";
echo "<h2>2. ตรวจสอบ columns ใน payment_slips</h2>";

try {
    $stmt = $db->query("DESCRIBE payment_slips");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table>";
    echo "<tr><th>Column</th><th>Type</th><th>Null</th><th>Default</th></tr>";
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>{$col['Field']}</td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check for required columns
    $columnNames = array_column($columns, 'Field');
    $requiredCols = ['id', 'order_id', 'image_url', 'status', 'created_at'];
    $optionalCols = ['transaction_id', 'user_id', 'amount', 'admin_note'];
    
    foreach ($requiredCols as $col) {
        if (in_array($col, $columnNames)) {
            echo "<p class='ok'>✅ Column '{$col}' exists</p>";
        } else {
            // Check for slip_image (old name)
            if ($col === 'image_url' && in_array('slip_image', $columnNames)) {
                echo "<p class='warn'>⚠️ Column 'slip_image' found (old name) - รัน migration_fix_payment_slips.sql เพื่อเปลี่ยนชื่อ</p>";
            } else {
                echo "<p class='error'>❌ Column '{$col}' missing</p>";
            }
        }
    }
    
    foreach ($optionalCols as $col) {
        if (in_array($col, $columnNames)) {
            echo "<p class='info'>ℹ️ Optional column '{$col}' exists</p>";
        }
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ ไม่สามารถตรวจสอบ payment_slips: " . $e->getMessage() . "</p>";
}
echo "</div>";

// 3. Check user_states columns
echo "<div class='section'>";
echo "<h2>3. ตรวจสอบ columns ใน user_states</h2>";

try {
    $stmt = $db->query("DESCRIBE user_states");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table>";
    echo "<tr><th>Column</th><th>Type</th><th>Null</th><th>Default</th></tr>";
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>{$col['Field']}</td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    $columnNames = array_column($columns, 'Field');
    $requiredCols = ['user_id', 'state', 'state_data'];
    
    foreach ($requiredCols as $col) {
        if (in_array($col, $columnNames)) {
            echo "<p class='ok'>✅ Column '{$col}' exists</p>";
        } else {
            echo "<p class='error'>❌ Column '{$col}' missing</p>";
        }
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ ไม่สามารถตรวจสอบ user_states: " . $e->getMessage() . "</p>";
}
echo "</div>";

// 4. Check uploads/slips directory
echo "<div class='section'>";
echo "<h2>4. ตรวจสอบโฟลเดอร์ uploads/slips</h2>";

$slipsDir = __DIR__ . '/uploads/slips';
if (is_dir($slipsDir)) {
    echo "<p class='ok'>✅ โฟลเดอร์ uploads/slips มีอยู่</p>";
    if (is_writable($slipsDir)) {
        echo "<p class='ok'>✅ โฟลเดอร์ uploads/slips สามารถเขียนได้</p>";
    } else {
        echo "<p class='error'>❌ โฟลเดอร์ uploads/slips ไม่สามารถเขียนได้ (permission denied)</p>";
    }
    
    // Count existing slips
    $files = glob($slipsDir . '/*.jpg');
    echo "<p class='info'>ℹ️ มีไฟล์สลิป " . count($files) . " ไฟล์</p>";
} else {
    echo "<p class='warn'>⚠️ โฟลเดอร์ uploads/slips ไม่มี - จะถูกสร้างอัตโนมัติเมื่อมีการอัพโหลดสลิป</p>";
}
echo "</div>";

// 5. Check recent orders
echo "<div class='section'>";
echo "<h2>5. คำสั่งซื้อล่าสุด</h2>";

try {
    $stmt = $db->query("SELECT o.*, u.display_name 
                        FROM orders o 
                        LEFT JOIN users u ON o.user_id = u.id 
                        ORDER BY o.created_at DESC LIMIT 5");
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($orders)) {
        echo "<p class='info'>ℹ️ ยังไม่มีคำสั่งซื้อ</p>";
    } else {
        echo "<table>";
        echo "<tr><th>Order#</th><th>ลูกค้า</th><th>ยอด</th><th>สถานะ</th><th>การชำระ</th><th>วันที่</th></tr>";
        foreach ($orders as $order) {
            echo "<tr>";
            echo "<td>{$order['order_number']}</td>";
            echo "<td>" . htmlspecialchars($order['display_name'] ?? 'N/A') . "</td>";
            echo "<td>฿" . number_format($order['grand_total'], 2) . "</td>";
            echo "<td>{$order['status']}</td>";
            echo "<td>{$order['payment_status']}</td>";
            echo "<td>" . date('d/m/Y H:i', strtotime($order['created_at'])) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ ไม่สามารถดึงข้อมูลคำสั่งซื้อ: " . $e->getMessage() . "</p>";
}
echo "</div>";

// 6. Check recent payment slips
echo "<div class='section'>";
echo "<h2>6. สลิปการชำระเงินล่าสุด</h2>";

try {
    // Check which column exists
    $stmt = $db->query("SHOW COLUMNS FROM payment_slips LIKE 'image_url'");
    $hasImageUrl = $stmt->rowCount() > 0;
    
    $stmt = $db->query("SHOW COLUMNS FROM payment_slips LIKE 'slip_image'");
    $hasSlipImage = $stmt->rowCount() > 0;
    
    $imageCol = $hasImageUrl ? 'image_url' : ($hasSlipImage ? 'slip_image' : null);
    
    if (!$imageCol) {
        echo "<p class='error'>❌ ไม่พบ column สำหรับ URL รูปสลิป</p>";
    } else {
        $stmt = $db->query("SELECT ps.*, o.order_number 
                            FROM payment_slips ps 
                            LEFT JOIN orders o ON ps.order_id = o.id 
                            ORDER BY ps.created_at DESC LIMIT 5");
        $slips = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($slips)) {
            echo "<p class='info'>ℹ️ ยังไม่มีสลิปการชำระเงิน</p>";
        } else {
            echo "<table>";
            echo "<tr><th>ID</th><th>Order#</th><th>รูป</th><th>สถานะ</th><th>วันที่</th></tr>";
            foreach ($slips as $slip) {
                $imgUrl = $slip[$imageCol] ?? $slip['image_url'] ?? $slip['slip_image'] ?? '';
                echo "<tr>";
                echo "<td>{$slip['id']}</td>";
                echo "<td>{$slip['order_number']}</td>";
                echo "<td><a href='{$imgUrl}' target='_blank'>ดูรูป</a></td>";
                echo "<td>{$slip['status']}</td>";
                echo "<td>" . date('d/m/Y H:i', strtotime($slip['created_at'])) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ ไม่สามารถดึงข้อมูลสลิป: " . $e->getMessage() . "</p>";
}
echo "</div>";

// 7. Check current user states
echo "<div class='section'>";
echo "<h2>7. User States ปัจจุบัน (checkout flow)</h2>";

try {
    $stmt = $db->query("SELECT us.*, u.display_name 
                        FROM user_states us 
                        LEFT JOIN users u ON us.user_id = u.id 
                        ORDER BY us.user_id DESC LIMIT 10");
    $states = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($states)) {
        echo "<p class='info'>ℹ️ ไม่มี user states ที่ active</p>";
    } else {
        echo "<table>";
        echo "<tr><th>User</th><th>State</th><th>Data</th><th>Expires</th></tr>";
        foreach ($states as $state) {
            $expired = isset($state['expires_at']) && strtotime($state['expires_at']) < time();
            $class = $expired ? 'error' : '';
            echo "<tr class='{$class}'>";
            echo "<td>" . htmlspecialchars($state['display_name'] ?? "User #{$state['user_id']}") . "</td>";
            echo "<td>{$state['state']}</td>";
            echo "<td><pre>" . htmlspecialchars($state['state_data'] ?? '{}') . "</pre></td>";
            echo "<td>" . ($state['expires_at'] ?? 'N/A') . ($expired ? ' (หมดอายุ)' : '') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ ไม่สามารถดึงข้อมูล user states: " . $e->getMessage() . "</p>";
}
echo "</div>";

// 8. Checkout Flow Summary
echo "<div class='section'>";
echo "<h2>8. สรุป Checkout Flow</h2>";
echo "<pre>
📋 Checkout Flow:

1. ลูกค้าพิมพ์ 'checkout' หรือ 'สั่งซื้อ'
   → BusinessBot::startCheckout()
   
2. ถ้าเป็นสินค้า Physical:
   → ขอที่อยู่จัดส่ง (state: checkout_address)
   → ลูกค้าส่งที่อยู่
   → แสดงสรุปคำสั่งซื้อ
   
3. สร้าง Order:
   → BusinessBot::quickCheckout() หรือ createTransaction()
   → บันทึกลง orders/transactions table
   → ตั้ง state: awaiting_slip
   
4. ลูกค้าส่งรูปสลิป:
   → webhook.php รับ image message
   → ตรวจสอบ user state = awaiting_slip
   → handlePaymentSlipForOrder()
   → บันทึกรูปลง uploads/slips/
   → บันทึกลง payment_slips table
   → แจ้ง Telegram
   → clear user state
   
5. Admin อนุมัติสลิป:
   → shop/order-detail.php
   → อัพเดท payment_status = paid
   → แจ้งลูกค้าผ่าน LINE
</pre>";
echo "</div>";

// 9. Quick Actions
echo "<div class='section'>";
echo "<h2>9. Quick Actions</h2>";
echo "<p><a href='shop/orders.php'>📋 ดูคำสั่งซื้อทั้งหมด</a></p>";
echo "<p><a href='shop/settings.php'>⚙️ ตั้งค่าร้านค้า</a></p>";
echo "<p><a href='test_checkout.php'>🧪 ทดสอบ Checkout Flow</a></p>";
echo "</div>";

echo "<p style='margin-top: 20px;'><a href='index.php'>← กลับหน้าหลัก</a></p>";
?>
