<?php
/**
 * Test MIMS Pharmacist AI
 * 
 * หน้าทดสอบ AI เภสัชกรออนไลน์ที่ใช้ข้อมูลจาก MIMS Pharmacy Thailand 2023
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/modules/AIChat/Autoloader.php';
loadAIChatModule();

use Modules\AIChat\Adapters\MIMSPharmacistAI;
use Modules\AIChat\Services\MIMSKnowledgeBase;

// Database connection
try {
    $db = Database::getInstance()->getConnection();
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

$lineAccountId = 1;
$userId = 1;

// Initialize
$ai = new MIMSPharmacistAI($db, $lineAccountId);
$ai->setUserId($userId);
$kb = new MIMSKnowledgeBase();

// Handle form submission
$result = null;
$searchResult = null;
$testMessage = $_POST['message'] ?? '';
$searchSymptom = $_POST['symptom'] ?? '';

if (!empty($testMessage)) {
    $result = $ai->processMessage($testMessage);
}

if (!empty($searchSymptom)) {
    $searchResult = $kb->searchBySymptom($searchSymptom);
}

?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test MIMS Pharmacist AI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .chat-container {
            max-height: 500px;
            overflow-y: auto;
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
        }
        .ai-message {
            background: #e3f2fd;
            border-radius: 15px;
            padding: 15px;
            margin-bottom: 10px;
            white-space: pre-wrap;
        }
        .user-message {
            background: #c8e6c9;
            border-radius: 15px;
            padding: 15px;
            margin-bottom: 10px;
            text-align: right;
        }
        .mims-card {
            border-left: 4px solid #2196f3;
        }
        .red-flag {
            background: #ffebee;
            border-left: 4px solid #f44336;
        }
        .treatment-table th {
            background: #e3f2fd;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <h1 class="mb-4">💊 MIMS Pharmacist AI - Test Console</h1>
        
        <div class="row">
            <!-- Chat Test -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">🤖 ทดสอบ AI Chat</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">ข้อความทดสอบ:</label>
                                <textarea name="message" class="form-control" rows="3" placeholder="เช่น: ลูกชาย 5 ขวบ ท้องเสียมาตั้งแต่เช้า"><?= htmlspecialchars($testMessage) ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">ส่งข้อความ</button>
                        </form>
                        
                        <?php if ($result): ?>
                        <hr>
                        <h6>ผลลัพธ์:</h6>
                        
                        <?php if ($result['success']): ?>
                        <div class="chat-container">
                            <div class="user-message">
                                <strong>คุณ:</strong><br>
                                <?= htmlspecialchars($testMessage) ?>
                            </div>
                            <div class="ai-message">
                                <strong>💊 MIMS Pharmacist AI:</strong><br>
                                <?= nl2br(htmlspecialchars($result['response'])) ?>
                            </div>
                        </div>
                        
                        <?php if (!empty($result['mims_matches'])): ?>
                        <div class="mt-3">
                            <h6>📚 MIMS Matches:</h6>
                            <ul class="list-group">
                                <?php foreach ($result['mims_matches'] as $match): ?>
                                <li class="list-group-item">
                                    <strong><?= htmlspecialchars($match['name_th']) ?></strong>
                                    (<?= htmlspecialchars($match['name_en']) ?>)
                                    <span class="badge bg-info"><?= htmlspecialchars($match['category']) ?></span>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($result['products'])): ?>
                        <div class="mt-3">
                            <h6>🛒 สินค้าที่เกี่ยวข้อง:</h6>
                            <ul class="list-group">
                                <?php foreach (array_slice($result['products'], 0, 5) as $product): ?>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span><?= htmlspecialchars($product['name']) ?></span>
                                    <span class="badge bg-success"><?= number_format($product['price']) ?> บาท</span>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        
                        <?php else: ?>
                        <div class="alert alert-danger">
                            <strong>Error:</strong> <?= htmlspecialchars($result['error'] ?? 'Unknown error') ?>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- MIMS Search -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">📚 ค้นหา MIMS Knowledge Base</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">ค้นหาอาการ:</label>
                                <input type="text" name="symptom" class="form-control" placeholder="เช่น: ปวดหัว, ท้องเสีย, สิว" value="<?= htmlspecialchars($searchSymptom) ?>">
                            </div>
                            <button type="submit" class="btn btn-info">ค้นหา</button>
                        </form>
                        
                        <?php if ($searchResult): ?>
                        <hr>
                        <h6>พบ <?= count($searchResult) ?> รายการ:</h6>
                        
                        <?php foreach ($searchResult as $disease): ?>
                        <div class="card mims-card mb-3">
                            <div class="card-body">
                                <h6 class="card-title">
                                    <?= htmlspecialchars($disease['name_th']) ?>
                                    <small class="text-muted">(<?= htmlspecialchars($disease['name_en']) ?>)</small>
                                </h6>
                                <span class="badge bg-secondary mb-2"><?= htmlspecialchars($disease['category']) ?></span>
                                
                                <?php if (!empty($disease['assessment_questions'])): ?>
                                <p class="mb-1"><strong>คำถามประเมิน:</strong></p>
                                <ul class="small">
                                    <?php foreach (array_slice($disease['assessment_questions'], 0, 2) as $q): ?>
                                    <li><?= htmlspecialchars($q) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php endif; ?>
                                
                                <?php if (!empty($disease['referral_criteria'])): ?>
                                <p class="mb-1"><strong>⚠️ ส่งต่อแพทย์เมื่อ:</strong></p>
                                <ul class="small text-danger">
                                    <?php foreach (array_slice($disease['referral_criteria'], 0, 2) as $c): ?>
                                    <li><?= htmlspecialchars($c) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Test Buttons -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">⚡ Quick Test Cases</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-2">
                        <form method="POST">
                            <input type="hidden" name="message" value="ลูกชาย 5 ขวบ ท้องเสียมาตั้งแต่เช้า ถ่ายเหลว 3 รอบแล้ว">
                            <button type="submit" class="btn btn-outline-primary w-100">👶 เด็กท้องเสีย</button>
                        </form>
                    </div>
                    <div class="col-md-3 mb-2">
                        <form method="POST">
                            <input type="hidden" name="message" value="ปวดหัวมาก 2 วันแล้ว กินยาพาราไม่หาย">
                            <button type="submit" class="btn btn-outline-primary w-100">🤕 ปวดหัว</button>
                        </form>
                    </div>
                    <div class="col-md-3 mb-2">
                        <form method="POST">
                            <input type="hidden" name="message" value="มีผื่นคันขึ้นตามตัว เป็นมา 3 วัน">
                            <button type="submit" class="btn btn-outline-primary w-100">🔴 ผื่นคัน</button>
                        </form>
                    </div>
                    <div class="col-md-3 mb-2">
                        <form method="POST">
                            <input type="hidden" name="message" value="แสบร้อนกลางอก หลังกินข้าว">
                            <button type="submit" class="btn btn-outline-primary w-100">🔥 กรดไหลย้อน</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 mb-2">
                        <form method="POST">
                            <input type="hidden" name="message" value="เจ็บหน้าอกมาก หายใจลำบาก เหงื่อออก">
                            <button type="submit" class="btn btn-outline-danger w-100">🚨 Red Flag Test</button>
                        </form>
                    </div>
                    <div class="col-md-3 mb-2">
                        <form method="POST">
                            <input type="hidden" name="message" value="ตั้งครรภ์ 3 เดือน ปวดหัวมาก ขอยาแก้ปวด">
                            <button type="submit" class="btn btn-outline-warning w-100">🤰 หญิงตั้งครรภ์</button>
                        </form>
                    </div>
                    <div class="col-md-3 mb-2">
                        <form method="POST">
                            <input type="hidden" name="message" value="เป็นสิวอักเสบมาก มีหัวหนองเยอะ">
                            <button type="submit" class="btn btn-outline-primary w-100">😣 สิวอักเสบ</button>
                        </form>
                    </div>
                    <div class="col-md-3 mb-2">
                        <form method="POST">
                            <input type="hidden" name="message" value="นอนไม่หลับมา 2 สัปดาห์ เครียดมาก">
                            <button type="submit" class="btn btn-outline-primary w-100">😴 นอนไม่หลับ</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- MIMS Categories -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">📖 MIMS Knowledge Base Categories</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php 
                    $categories = $kb->getCategories();
                    foreach ($categories as $cat): 
                        $diseases = $kb->getCategory($cat);
                    ?>
                    <div class="col-md-4 mb-3">
                        <div class="card h-100">
                            <div class="card-header bg-light">
                                <strong><?= htmlspecialchars(ucfirst($cat)) ?></strong>
                                <span class="badge bg-primary float-end"><?= count($diseases) ?></span>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled mb-0 small">
                                    <?php foreach ($diseases as $key => $disease): ?>
                                    <li>• <?= htmlspecialchars($disease['name_th']) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- API Info -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="mb-0">🔌 API Endpoints</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Method</th>
                            <th>Endpoint</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><span class="badge bg-success">POST</span></td>
                            <td><code>/api/mims-pharmacist.php?action=chat</code></td>
                            <td>ส่งข้อความถาม AI (body: {"message": "..."})</td>
                        </tr>
                        <tr>
                            <td><span class="badge bg-primary">GET</span></td>
                            <td><code>/api/mims-pharmacist.php?action=search&symptom=xxx</code></td>
                            <td>ค้นหาข้อมูลโรคจาก MIMS</td>
                        </tr>
                        <tr>
                            <td><span class="badge bg-primary">GET</span></td>
                            <td><code>/api/mims-pharmacist.php?action=red-flags&symptoms=xxx</code></td>
                            <td>ตรวจสอบ Red Flags</td>
                        </tr>
                        <tr>
                            <td><span class="badge bg-primary">GET</span></td>
                            <td><code>/api/mims-pharmacist.php?action=categories</code></td>
                            <td>ดูหมวดหมู่ทั้งหมด</td>
                        </tr>
                        <tr>
                            <td><span class="badge bg-primary">GET</span></td>
                            <td><code>/api/mims-pharmacist.php?action=corticosteroid&body_area=xxx</code></td>
                            <td>แนะนำยาทาสเตียรอยด์ตามบริเวณ</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
