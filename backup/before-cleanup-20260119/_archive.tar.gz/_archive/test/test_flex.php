<?php
/**
 * Flex Message Validation Test
 * ตรวจสอบว่า Flex Message ถูกต้องตาม LINE API spec หรือไม่
 */

require_once 'config/config.php';
require_once 'classes/FlexTemplates.php';

echo "=== FLEX MESSAGE VALIDATION TEST ===\n\n";

$passed = 0;
$failed = 0;
$errors = [];

/**
 * Validate Flex Message structure
 */
function validateFlex($flex, $name) {
    $issues = [];
    
    if (!is_array($flex)) {
        return ["Not an array"];
    }
    
    // Check type
    if (!isset($flex['type'])) {
        $issues[] = "Missing 'type' field";
    }
    
    $type = $flex['type'] ?? '';
    
    if ($type === 'bubble') {
        $issues = array_merge($issues, validateBubble($flex, $name));
    } elseif ($type === 'carousel') {
        if (!isset($flex['contents']) || !is_array($flex['contents'])) {
            $issues[] = "Carousel missing 'contents' array";
        } else {
            foreach ($flex['contents'] as $i => $bubble) {
                $bubbleIssues = validateBubble($bubble, "{$name}[{$i}]");
                $issues = array_merge($issues, $bubbleIssues);
            }
        }
    }
    
    return $issues;
}

function validateBubble($bubble, $name) {
    $issues = [];
    
    if (!isset($bubble['type']) || $bubble['type'] !== 'bubble') {
        $issues[] = "{$name}: Not a bubble type";
        return $issues;
    }
    
    // Check hero (optional but must be valid if present)
    if (isset($bubble['hero'])) {
        if ($bubble['hero'] === null) {
            $issues[] = "{$name}: hero is null (should be removed if not used)";
        } elseif (isset($bubble['hero']['type']) && $bubble['hero']['type'] === 'image') {
            if (empty($bubble['hero']['url'])) {
                $issues[] = "{$name}: hero image missing url";
            }
        }
    }
    
    // Check body (required for most bubbles)
    if (isset($bubble['body'])) {
        $bodyIssues = validateBox($bubble['body'], "{$name}.body");
        $issues = array_merge($issues, $bodyIssues);
    }
    
    // Check footer
    if (isset($bubble['footer'])) {
        $footerIssues = validateBox($bubble['footer'], "{$name}.footer");
        $issues = array_merge($issues, $footerIssues);
    }
    
    return $issues;
}

function validateBox($box, $path) {
    $issues = [];
    
    if (!is_array($box)) {
        $issues[] = "{$path}: Not an array";
        return $issues;
    }
    
    if (!isset($box['type']) || $box['type'] !== 'box') {
        $issues[] = "{$path}: Not a box type";
        return $issues;
    }
    
    if (!isset($box['layout'])) {
        $issues[] = "{$path}: Missing layout";
    }
    
    if (!isset($box['contents']) || !is_array($box['contents'])) {
        $issues[] = "{$path}: Missing or invalid contents";
        return $issues;
    }
    
    foreach ($box['contents'] as $i => $content) {
        if (!is_array($content)) {
            $issues[] = "{$path}.contents[{$i}]: Not an array";
            continue;
        }
        
        if (!isset($content['type'])) {
            $issues[] = "{$path}.contents[{$i}]: Missing type";
            continue;
        }
        
        // Validate nested boxes
        if ($content['type'] === 'box') {
            $nestedIssues = validateBox($content, "{$path}.contents[{$i}]");
            $issues = array_merge($issues, $nestedIssues);
        }
        
        // Validate text
        if ($content['type'] === 'text') {
            if (!isset($content['text'])) {
                $issues[] = "{$path}.contents[{$i}]: text component missing 'text' field";
            }
        }
        
        // Validate button
        if ($content['type'] === 'button') {
            if (!isset($content['action'])) {
                $issues[] = "{$path}.contents[{$i}]: button missing 'action'";
            } elseif (!isset($content['action']['type'])) {
                $issues[] = "{$path}.contents[{$i}]: button action missing 'type'";
            } elseif (!isset($content['action']['label'])) {
                $issues[] = "{$path}.contents[{$i}]: button action missing 'label'";
            }
        }
        
        // Validate image
        if ($content['type'] === 'image') {
            if (!isset($content['url']) || empty($content['url'])) {
                $issues[] = "{$path}.contents[{$i}]: image missing 'url'";
            }
        }
    }
    
    return $issues;
}

function testFlex($name, $flex) {
    global $passed, $failed, $errors;
    
    $issues = validateFlex($flex, $name);
    
    if (empty($issues)) {
        echo "  ✅ {$name}\n";
        $passed++;
        return true;
    } else {
        echo "  ❌ {$name}\n";
        foreach ($issues as $issue) {
            echo "     - {$issue}\n";
        }
        $failed++;
        $errors[$name] = $issues;
        return false;
    }
}

// =====================================================
// Test FlexTemplates methods
// =====================================================

echo "📋 1. Testing FlexTemplates::welcome()\n";
try {
    $flex = FlexTemplates::welcome('TestUser', 'https://example.com/pic.jpg', 'Test Shop');
    testFlex('welcome', $flex);
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 2. Testing FlexTemplates::mainMenu()\n";
try {
    $flex = FlexTemplates::mainMenu('Test Shop');
    testFlex('mainMenu', $flex);
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 3. Testing FlexTemplates::notification()\n";
try {
    $flex = FlexTemplates::notification('Test Title', 'Test Message', '🔔', '#06C755', [
        ['label' => 'Button 1', 'text' => 'test1'],
        ['label' => 'Button 2', 'text' => 'test2']
    ]);
    testFlex('notification', $flex);
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 4. Testing FlexTemplates::slipReceived()\n";
try {
    $flex = FlexTemplates::slipReceived('ORD123456', 1500);
    testFlex('slipReceived', $flex);
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 5. Testing FlexTemplates::success()\n";
try {
    $flex = FlexTemplates::success('Success!', 'Operation completed', [['label' => 'OK', 'text' => 'ok']]);
    testFlex('success', $flex);
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 6. Testing FlexTemplates::error()\n";
try {
    $flex = FlexTemplates::error('Error!', 'Something went wrong', 'Try again');
    testFlex('error', $flex);
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 7. Testing FlexTemplates::info()\n";
try {
    $flex = FlexTemplates::info('Info', 'Information message', [['label' => 'OK', 'text' => 'ok']]);
    testFlex('info', $flex);
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 8. Testing FlexTemplates::cartSummary()\n";
try {
    $items = [
        ['name' => 'Product 1', 'quantity' => 2, 'subtotal' => 200],
        ['name' => 'Product 2', 'quantity' => 1, 'subtotal' => 150],
    ];
    $flex = FlexTemplates::cartSummary($items, 350, 2);
    testFlex('cartSummary', $flex);
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 9. Testing FlexTemplates::productCard()\n";
try {
    $product = [
        'id' => 1,
        'name' => 'Test Product',
        'price' => 299,
        'sale_price' => null,
        'stock' => 10,
        'image_url' => 'https://via.placeholder.com/400'
    ];
    $flex = FlexTemplates::productCard($product);
    testFlex('productCard', $flex);
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 10. Testing FlexTemplates::productCard() without image\n";
try {
    $product = [
        'id' => 2,
        'name' => 'Test Product No Image',
        'price' => 199,
        'sale_price' => 149,
        'stock' => 5,
        'image_url' => null
    ];
    $flex = FlexTemplates::productCard($product);
    testFlex('productCard_no_image', $flex);
    
    // Check if hero is null (this is a problem!)
    if (isset($flex['hero']) && $flex['hero'] === null) {
        echo "     ⚠️ WARNING: hero is null - should be unset!\n";
    }
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

echo "\n📋 11. Testing FlexTemplates::toMessage()\n";
try {
    $bubble = FlexTemplates::success('Test', 'Message');
    $message = FlexTemplates::toMessage($bubble, 'Alt Text', 'shop', 'main');
    
    if (!isset($message['type']) || $message['type'] !== 'flex') {
        echo "  ❌ toMessage: type is not 'flex'\n";
        $failed++;
    } elseif (!isset($message['contents'])) {
        echo "  ❌ toMessage: missing 'contents'\n";
        $failed++;
    } elseif (!isset($message['altText'])) {
        echo "  ❌ toMessage: missing 'altText'\n";
        $failed++;
    } else {
        echo "  ✅ toMessage\n";
        $passed++;
    }
} catch (Exception $e) {
    echo "  ❌ Exception: " . $e->getMessage() . "\n";
    $failed++;
}

// =====================================================
// Summary
// =====================================================

echo "\n" . str_repeat("=", 50) . "\n";
echo "📊 SUMMARY\n";
echo str_repeat("=", 50) . "\n";
echo "✅ Passed: {$passed}\n";
echo "❌ Failed: {$failed}\n";

if ($failed > 0) {
    echo "\n⚠️ ISSUES FOUND - These may cause LINE API to reject messages!\n";
    foreach ($errors as $name => $issues) {
        echo "\n{$name}:\n";
        foreach ($issues as $issue) {
            echo "  - {$issue}\n";
        }
    }
}

echo "\n";
