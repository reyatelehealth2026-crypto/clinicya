<?php
/**
 * Test AI Function Calling
 * ทดสอบว่า AI สามารถค้นหาสินค้าในฐานข้อมูลได้เอง
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/modules/AIChat/Adapters/PharmacyAIAdapter.php';

use Modules\AIChat\Adapters\PharmacyAIAdapter;
use Modules\Core\Database;

echo "<h1>🧪 Test AI Function Calling</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; max-width: 1200px; margin: 0 auto; }
    .test { background: #f5f5f5; padding: 15px; margin: 10px 0; border-radius: 8px; }
    .success { background: #d4edda; border-left: 4px solid #28a745; }
    .error { background: #f8d7da; border-left: 4px solid #dc3545; }
    .info { background: #d1ecf1; border-left: 4px solid #17a2b8; }
    pre { background: #2d2d2d; color: #f8f8f2; padding: 15px; border-radius: 5px; overflow-x: auto; }
    .question { font-weight: bold; color: #007bff; }
    .answer { color: #28a745; margin-top: 10px; }
</style>";

try {
    $db = Database::getInstance()->getConnection();
    
    // ดึง line_account_id แรก
    $stmt = $db->query("SELECT id FROM line_accounts WHERE is_active = 1 LIMIT 1");
    $lineAccountId = $stmt->fetchColumn() ?: 1;
    
    $ai = new PharmacyAIAdapter($db, $lineAccountId);
    
    // ตรวจสอบว่า AI enabled
    if (!$ai->isEnabled()) {
        echo "<div class='test error'>❌ AI ไม่ได้เปิดใช้งาน - ไม่มี API Key</div>";
        exit;
    }
    
    echo "<div class='test success'>✅ AI Enabled - Model: " . $ai->getModel() . "</div>";
    
    // นับจำนวนสินค้า
    $totalProducts = $ai->getTotalProductCount();
    echo "<div class='test info'>📦 จำนวนสินค้าในร้าน: <strong>{$totalProducts}</strong> รายการ</div>";
    
    // ทดสอบคำถามต่างๆ
    $testQuestions = [
        "มียูเซอรินไหม",
        "ยาแก้ปวดหัวมีอะไรบ้าง",
        "หาวิตามินซี",
        "มีสินค้ากี่รายการ",
        "ปวดท้อง กินยาอะไรดี"
    ];
    
    echo "<h2>🔬 ทดสอบ Function Calling</h2>";
    echo "<p>AI จะค้นหาสินค้าในฐานข้อมูลเองโดยใช้ Function Calling</p>";
    
    foreach ($testQuestions as $index => $question) {
        echo "<div class='test'>";
        echo "<div class='question'>❓ คำถาม " . ($index + 1) . ": {$question}</div>";
        
        $startTime = microtime(true);
        $result = $ai->processMessage($question);
        $endTime = microtime(true);
        $duration = round(($endTime - $startTime) * 1000);
        
        if ($result['success']) {
            echo "<div class='answer'>💬 คำตอบ: " . htmlspecialchars($result['response']) . "</div>";
            
            // แสดงสินค้าที่พบ
            $products = $result['products'] ?? [];
            if (!empty($products)) {
                echo "<div style='margin-top: 10px; font-size: 12px; color: #666;'>";
                echo "📦 พบสินค้า " . count($products) . " รายการ: ";
                $names = array_slice(array_column($products, 'name'), 0, 3);
                echo implode(', ', $names);
                if (count($products) > 3) echo "...";
                echo "</div>";
            }
        } else {
            echo "<div class='answer' style='color: red;'>❌ Error: " . ($result['error'] ?? 'Unknown') . "</div>";
        }
        
        echo "<div style='font-size: 11px; color: #999; margin-top: 5px;'>⏱️ {$duration}ms</div>";
        echo "</div>";
        
        // หน่วงเวลาเล็กน้อยเพื่อไม่ให้ rate limit
        usleep(500000); // 0.5 วินาที
    }
    
    // แสดง Log
    echo "<h2>📋 Error Log (ล่าสุด)</h2>";
    echo "<pre>";
    $logFile = ini_get('error_log') ?: '/tmp/php_errors.log';
    if (file_exists($logFile)) {
        $logs = file($logFile);
        $recentLogs = array_slice($logs, -20);
        foreach ($recentLogs as $log) {
            if (strpos($log, 'PharmacyAI') !== false || strpos($log, 'PharmacyRAG') !== false) {
                echo htmlspecialchars($log);
            }
        }
    } else {
        echo "Log file not found";
    }
    echo "</pre>";
    
} catch (Exception $e) {
    echo "<div class='test error'>❌ Error: " . $e->getMessage() . "</div>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}
