<?php
/**
 * Test AI Order System
 * ทดสอบระบบสั่งซื้อผ่าน AI Chat
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'modules/AIChat/Adapters/PharmacyAIAdapter.php';

use Modules\AIChat\Adapters\PharmacyAIAdapter;

$db = Database::getInstance()->getConnection();

echo "<h1>🧪 Test AI Order System</h1>";
echo "<style>body{font-family:sans-serif;padding:20px;} pre{background:#f5f5f5;padding:15px;border-radius:8px;overflow-x:auto;} .success{color:green;} .error{color:red;} .info{color:blue;}</style>";

// Get line_account_id
$stmt = $db->query("SELECT id FROM line_accounts WHERE is_active = 1 LIMIT 1");
$lineAccountId = $stmt->fetchColumn() ?: 1;

// Get test user
$stmt = $db->query("SELECT id, display_name FROM users WHERE line_user_id IS NOT NULL LIMIT 1");
$testUser = $stmt->fetch(PDO::FETCH_ASSOC);
$userId = $testUser['id'] ?? 1;

echo "<p>Line Account ID: {$lineAccountId}</p>";
echo "<p>Test User: {$testUser['display_name']} (ID: {$userId})</p>";

// Initialize adapter
$adapter = new PharmacyAIAdapter($db, $lineAccountId);
$adapter->setUserId($userId);

echo "<p>API Key: " . ($adapter->isEnabled() ? '✅ Found' : '❌ Not found') . "</p>";

// Test cases
$testCases = [
    [
        'name' => '1️⃣ ถามเกี่ยวกับยา (ควรถามดูรูปสินค้า)',
        'message' => 'มียาแก้ปวดหัวไหม'
    ],
    [
        'name' => '2️⃣ ขอดูรูปสินค้า',
        'message' => 'ดูรูปสินค้า'
    ],
    [
        'name' => '3️⃣ สั่งซื้อสินค้า',
        'message' => 'สั่งซื้อ พาราเซตามอล'
    ],
    [
        'name' => '4️⃣ ดูตะกร้า / ยืนยันตะกร้า',
        'message' => 'ดูตะกร้า'
    ],
    [
        'name' => '5️⃣ ล้างตะกร้า',
        'message' => 'ล้างตะกร้า'
    ]
];

foreach ($testCases as $test) {
    echo "<h2>{$test['name']}</h2>";
    echo "<p><strong>Input:</strong> {$test['message']}</p>";
    
    try {
        $result = $adapter->processMessage($test['message']);
        
        if ($result['success']) {
            echo "<p class='success'>✅ Success</p>";
            echo "<p><strong>Response:</strong> " . htmlspecialchars($result['response'] ?? '') . "</p>";
            echo "<p><strong>State:</strong> " . ($result['state'] ?? 'N/A') . "</p>";
            
            // Check messages
            $messages = $result['messages'] ?? $result['message'] ?? [];
            if (!empty($messages)) {
                echo "<p><strong>Messages count:</strong> " . (isset($messages['type']) ? 1 : count($messages)) . "</p>";
                
                // Show message types
                if (isset($messages['type'])) {
                    echo "<p>- Message type: {$messages['type']}</p>";
                } else {
                    foreach ($messages as $i => $msg) {
                        echo "<p>- Message {$i}: type=" . ($msg['type'] ?? 'unknown') . "</p>";
                    }
                }
            }
            
            // Check products
            if (!empty($result['products'])) {
                echo "<p><strong>Products found:</strong> " . count($result['products']) . "</p>";
            }
            
            // Full result
            echo "<details><summary>📋 Full Result (JSON)</summary>";
            echo "<pre>" . json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
            echo "</details>";
        } else {
            echo "<p class='error'>❌ Failed: " . ($result['error'] ?? 'Unknown error') . "</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Exception: " . $e->getMessage() . "</p>";
    }
    
    echo "<hr>";
}

// Check cart_items table
echo "<h2>🛒 Cart Items Table Check</h2>";
try {
    $stmt = $db->query("SHOW COLUMNS FROM cart_items");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "<p>Columns: " . implode(', ', $columns) . "</p>";
    
    // Check if user_id exists
    if (in_array('user_id', $columns)) {
        echo "<p class='success'>✅ user_id column exists</p>";
    } else {
        echo "<p class='error'>❌ user_id column missing</p>";
    }
    
    // Count items
    $stmt = $db->query("SELECT COUNT(*) FROM cart_items");
    echo "<p>Total cart items: " . $stmt->fetchColumn() . "</p>";
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<h2>📋 Summary</h2>";
echo "<p>ระบบสั่งซื้อผ่าน AI Chat พร้อมใช้งาน:</p>";
echo "<ul>";
echo "<li>✅ ถามเกี่ยวกับยา → AI ตอบ + ถามดูรูปสินค้า</li>";
echo "<li>✅ พิมพ์ 'ดูรูปสินค้า' → แสดง Carousel รูปสินค้า</li>";
echo "<li>✅ พิมพ์ 'สั่งซื้อ [ชื่อยา]' → เพิ่มลงตะกร้า</li>";
echo "<li>✅ พิมพ์ 'ดูตะกร้า' หรือ 'ยืนยัน' → แสดงสรุปตะกร้า + ปุ่มยืนยันสั่งซื้อ</li>";
echo "<li>✅ พิมพ์ 'ล้างตะกร้า' → ลบสินค้าทั้งหมดในตะกร้า</li>";
echo "<li>✅ กดปุ่ม 'ยืนยันสั่งซื้อ' → ไป LIFF Checkout</li>";
echo "</ul>";
echo "<p><strong>วิธีทดสอบจริง:</strong> ส่งข้อความผ่าน LINE</p>";
