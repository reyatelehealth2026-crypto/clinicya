<?php
/**
 * Test Order Detail - ตรวจสอบปัญหารายละเอียดออเดอร์และรูปภาพ
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>🔍 ตรวจสอบระบบ Order Detail & Payment Slips</h2>";
echo "<style>body{font-family:sans-serif;padding:20px;} .ok{color:green;} .err{color:red;} .warn{color:orange;} table{border-collapse:collapse;margin:10px 0;} th,td{border:1px solid #ddd;padding:8px;}</style>";

// 1. Check tables
echo "<h3>1. ตรวจสอบตาราง</h3>";
$tables = ['orders', 'order_items', 'payment_slips', 'transactions', 'transaction_items'];
foreach ($tables as $table) {
    try {
        $stmt = $db->query("SELECT COUNT(*) FROM {$table}");
        $count = $stmt->fetchColumn();
        echo "<p class='ok'>✅ {$table} - มี {$count} records</p>";
    } catch (Exception $e) {
        echo "<p class='err'>❌ {$table} - ไม่มีตาราง</p>";
    }
}

// 2. Check payment_slips columns
echo "<h3>2. ตรวจสอบ columns ใน payment_slips</h3>";
try {
    $stmt = $db->query("DESCRIBE payment_slips");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<table><tr><th>Column</th><th>Type</th><th>Null</th><th>Default</th></tr>";
    foreach ($columns as $col) {
        echo "<tr><td>{$col['Field']}</td><td>{$col['Type']}</td><td>{$col['Null']}</td><td>{$col['Default']}</td></tr>";
    }
    echo "</table>";
    
    // Check required columns
    $colNames = array_column($columns, 'Field');
    $required = ['id', 'order_id', 'image_url', 'status', 'created_at'];
    foreach ($required as $req) {
        if (in_array($req, $colNames)) {
            echo "<p class='ok'>✅ Column {$req} มีอยู่</p>";
        } else {
            echo "<p class='err'>❌ Column {$req} ไม่มี!</p>";
        }
    }
} catch (Exception $e) {
    echo "<p class='err'>❌ Error: " . $e->getMessage() . "</p>";
}

// 3. Check recent orders
echo "<h3>3. Orders ล่าสุด</h3>";
try {
    $stmt = $db->query("SELECT o.id, o.order_number, o.status, o.payment_status, o.created_at, u.display_name 
                        FROM orders o 
                        LEFT JOIN users u ON o.user_id = u.id 
                        ORDER BY o.id DESC LIMIT 5");
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($orders)) {
        echo "<p class='warn'>⚠️ ยังไม่มี orders</p>";
    } else {
        echo "<table><tr><th>ID</th><th>Order#</th><th>Status</th><th>Payment</th><th>User</th><th>Date</th></tr>";
        foreach ($orders as $o) {
            echo "<tr><td>{$o['id']}</td><td>{$o['order_number']}</td><td>{$o['status']}</td><td>{$o['payment_status']}</td><td>{$o['display_name']}</td><td>{$o['created_at']}</td></tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p class='err'>❌ Error: " . $e->getMessage() . "</p>";
}

// 4. Check payment slips
echo "<h3>4. Payment Slips ล่าสุด</h3>";
try {
    $stmt = $db->query("SELECT ps.*, o.order_number 
                        FROM payment_slips ps 
                        LEFT JOIN orders o ON ps.order_id = o.id 
                        ORDER BY ps.id DESC LIMIT 5");
    $slips = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($slips)) {
        echo "<p class='warn'>⚠️ ยังไม่มี payment slips</p>";
    } else {
        echo "<table><tr><th>ID</th><th>Order#</th><th>Image URL</th><th>Status</th><th>Date</th></tr>";
        foreach ($slips as $s) {
            $imgPreview = substr($s['image_url'] ?? '', 0, 50) . '...';
            echo "<tr><td>{$s['id']}</td><td>{$s['order_number']}</td><td>{$imgPreview}</td><td>{$s['status']}</td><td>{$s['created_at']}</td></tr>";
        }
        echo "</table>";
        
        // Show images
        echo "<h4>รูปภาพ Slips:</h4>";
        foreach ($slips as $s) {
            if (!empty($s['image_url'])) {
                echo "<div style='margin:10px;display:inline-block;'>";
                echo "<img src='{$s['image_url']}' style='max-width:200px;max-height:200px;border:1px solid #ddd;' onerror=\"this.src='https://via.placeholder.com/200?text=Image+Not+Found'\">";
                echo "<p style='font-size:12px;'>Order: {$s['order_number']}</p>";
                echo "</div>";
            }
        }
    }
} catch (Exception $e) {
    echo "<p class='err'>❌ Error: " . $e->getMessage() . "</p>";
}

// 5. Check uploads folder
echo "<h3>5. ตรวจสอบ Uploads Folder</h3>";
$uploadDirs = ['uploads', 'uploads/slips', 'uploads/products'];
foreach ($uploadDirs as $dir) {
    if (is_dir($dir)) {
        $writable = is_writable($dir) ? '(writable)' : '(NOT writable!)';
        $files = count(glob($dir . '/*'));
        echo "<p class='ok'>✅ {$dir} - มีอยู่ {$writable} - {$files} files</p>";
    } else {
        echo "<p class='err'>❌ {$dir} - ไม่มี folder</p>";
    }
}

// 6. Check BASE_URL
echo "<h3>6. ตรวจสอบ Config</h3>";
echo "<p>BASE_URL: <code>" . (defined('BASE_URL') ? BASE_URL : 'NOT DEFINED') . "</code></p>";

// 7. Test order detail page
echo "<h3>7. ทดสอบเปิดหน้า Order Detail</h3>";
try {
    $stmt = $db->query("SELECT id FROM orders ORDER BY id DESC LIMIT 1");
    $lastOrder = $stmt->fetchColumn();
    if ($lastOrder) {
        echo "<p>Order ล่าสุด: #{$lastOrder}</p>";
        echo "<p><a href='shop/order-detail.php?id={$lastOrder}' target='_blank' class='ok'>🔗 เปิด shop/order-detail.php?id={$lastOrder}</a></p>";
        echo "<p><a href='user/order-detail.php?id={$lastOrder}' target='_blank' class='ok'>🔗 เปิด user/order-detail.php?id={$lastOrder}</a></p>";
    } else {
        echo "<p class='warn'>⚠️ ไม่มี orders ให้ทดสอบ</p>";
    }
} catch (Exception $e) {
    echo "<p class='err'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<hr><p><small>⚠️ ลบไฟล์นี้หลังใช้งานเสร็จ</small></p>";
