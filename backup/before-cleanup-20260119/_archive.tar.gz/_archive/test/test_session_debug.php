<?php
session_start();
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Debug Session & Messages</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .box { border: 1px solid #ccc; padding: 15px; margin: 10px 0; border-radius: 8px; }
        .success { background: #d4edda; }
        .error { background: #f8d7da; }
        pre { background: #f5f5f5; padding: 10px; overflow-x: auto; }
        button { padding: 10px 20px; margin: 5px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>🔍 Debug Session & Messages</h1>
    
    <div class="box">
        <h2>1. Current Session (PHP)</h2>
        <?php if (isset($_SESSION['admin_user'])): ?>
            <p class="success">✅ Logged in as: <strong><?= htmlspecialchars($_SESSION['admin_user']['username'] ?? 'N/A') ?></strong></p>
            <pre><?= htmlspecialchars(json_encode($_SESSION['admin_user'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?></pre>
        <?php else: ?>
            <p class="error">❌ Not logged in!</p>
        <?php endif; ?>
    </div>
    
    <div class="box">
        <h2>2. Test AJAX Session</h2>
        <button onclick="testAjax()">Test AJAX Request</button>
        <pre id="ajaxResult">Click button to test...</pre>
    </div>
    
    <div class="box">
        <h2>3. Recent Messages (sent_by)</h2>
        <?php
        $stmt = $db->query("SELECT id, content, sent_by, created_at FROM messages WHERE direction = 'outgoing' ORDER BY created_at DESC LIMIT 10");
        $msgs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%;">
            <tr><th>ID</th><th>Content</th><th>Sent By</th><th>Created</th></tr>
            <?php foreach ($msgs as $m): ?>
            <tr>
                <td><?= $m['id'] ?></td>
                <td><?= htmlspecialchars(mb_substr($m['content'], 0, 30)) ?>...</td>
                <td style="<?= $m['sent_by'] === 'admin:Admin' ? 'color:red;' : 'color:green;' ?>">
                    <strong><?= htmlspecialchars($m['sent_by'] ?? 'NULL') ?></strong>
                </td>
                <td><?= $m['created_at'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    
    <div class="box">
        <h2>4. Test Send Message (Simulation)</h2>
        <button onclick="testSendMessage()">Simulate Send Message</button>
        <pre id="sendResult">Click button to test...</pre>
    </div>

    <script>
    async function testAjax() {
        try {
            const res = await fetch('test_session_ajax.php', {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            const data = await res.json();
            document.getElementById('ajaxResult').textContent = JSON.stringify(data, null, 2);
        } catch (e) {
            document.getElementById('ajaxResult').textContent = 'Error: ' + e.message;
        }
    }
    
    async function testSendMessage() {
        try {
            const formData = new FormData();
            formData.append('action', 'test_session');
            
            const res = await fetch('inbox.php', {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: formData
            });
            const text = await res.text();
            document.getElementById('sendResult').textContent = text;
        } catch (e) {
            document.getElementById('sendResult').textContent = 'Error: ' + e.message;
        }
    }
    </script>
    
    <p><a href="inbox">← Back to Inbox</a></p>
</body>
</html>
