<?php
/**
 * Test Onboarding Assistant Page
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Test Onboarding Assistant</h2>";
echo "<pre>";

// Step 1: Check required files
echo "=== Step 1: Check Required Files ===\n";
$files = [
    'config/config.php',
    'includes/header.php',
    'modules/Core/Database.php',
    'modules/Onboarding/OnboardingAssistant.php',
    'modules/Onboarding/SetupStatusChecker.php',
    'modules/Onboarding/SystemKnowledgeBase.php',
    'modules/Onboarding/OnboardingPromptBuilder.php',
    'modules/Onboarding/QuickActionExecutor.php',
    'api/onboarding-assistant.php'
];

foreach ($files as $file) {
    $path = __DIR__ . '/' . $file;
    $exists = file_exists($path);
    echo ($exists ? "✅" : "❌") . " $file\n";
}

// Step 2: Test loading modules
echo "\n=== Step 2: Test Loading Modules ===\n";

try {
    require_once 'config/config.php';
    echo "✅ config.php loaded\n";
} catch (Exception $e) {
    echo "❌ config.php: " . $e->getMessage() . "\n";
}

try {
    require_once 'config/database.php';
    echo "✅ database.php loaded\n";
} catch (Exception $e) {
    echo "❌ database.php: " . $e->getMessage() . "\n";
}

try {
    require_once 'modules/Onboarding/OnboardingAssistant.php';
    echo "✅ OnboardingAssistant.php loaded\n";
} catch (Exception $e) {
    echo "❌ OnboardingAssistant.php: " . $e->getMessage() . "\n";
}

// Step 3: Test session
echo "\n=== Step 3: Test Session ===\n";
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

echo "Session ID: " . session_id() . "\n";
echo "admin_user_id: " . ($_SESSION['admin_user_id'] ?? 'NOT SET') . "\n";
echo "line_account_id: " . ($_SESSION['line_account_id'] ?? 'NOT SET') . "\n";
echo "admin_name: " . ($_SESSION['admin_name'] ?? 'NOT SET') . "\n";

// Step 4: Test API
echo "\n=== Step 4: Test API Endpoint ===\n";
if (isset($_SESSION['admin_user_id']) && isset($_SESSION['line_account_id'])) {
    try {
        $db = Database::getInstance()->getConnection();
        $assistant = new \Modules\Onboarding\OnboardingAssistant(
            $db, 
            $_SESSION['line_account_id'], 
            $_SESSION['admin_user_id']
        );
        
        echo "✅ OnboardingAssistant created\n";
        
        // Test welcome message
        $welcome = $assistant->getWelcomeMessage($_SESSION['admin_name'] ?? 'User');
        echo "✅ Welcome message: " . substr($welcome, 0, 100) . "...\n";
        
        // Test checklist
        $checklist = $assistant->getChecklist();
        echo "✅ Checklist loaded, completion: " . ($checklist['completion_percent'] ?? 0) . "%\n";
        
    } catch (Exception $e) {
        echo "❌ Error: " . $e->getMessage() . "\n";
        echo "Stack: " . $e->getTraceAsString() . "\n";
    }
} else {
    echo "⚠️ Not logged in - session variables missing\n";
}

echo "</pre>";

echo "<h3>Links</h3>";
echo "<ul>";
echo "<li><a href='/onboarding-assistant.php'>Onboarding Assistant Page</a></li>";
echo "<li><a href='/api/onboarding-assistant.php?action=welcome'>API Welcome</a></li>";
echo "<li><a href='/api/onboarding-assistant.php?action=checklist'>API Checklist</a></li>";
echo "</ul>";
