<?php
/**
 * ทดสอบ AI Chat Module ใหม่
 * ใช้ทดสอบว่า Module ทำงานได้ถูกต้องหรือไม่
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🧪 ทดสอบ AI Chat Module</h1>";
echo "<pre>";

// 1. ทดสอบ Autoloader
echo "\n=== 1. ทดสอบ Autoloader ===\n";
try {
    require_once __DIR__ . '/modules/AIChat/Autoloader.php';
    loadAIChatModule();
    echo "✅ Autoloader โหลดสำเร็จ\n";
} catch (Exception $e) {
    echo "❌ Autoloader Error: " . $e->getMessage() . "\n";
    exit;
}

// 2. ทดสอบ Core Database
echo "\n=== 2. ทดสอบ Core Database ===\n";
try {
    $db = \Modules\Core\Database::getInstance();
    echo "✅ Database เชื่อมต่อสำเร็จ\n";
    
    // ทดสอบ query
    $result = $db->fetchOne("SELECT 1 as test");
    echo "✅ Query ทำงานได้: " . json_encode($result) . "\n";
} catch (Exception $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
}

// 3. ทดสอบ Model AISettings
echo "\n=== 3. ทดสอบ Model AISettings ===\n";
try {
    // ดึง line_account_id แรกจาก database
    $account = $db->fetchOne("SELECT id FROM line_accounts LIMIT 1");
    $lineAccountId = $account ? $account['id'] : 1;
    
    $settings = new \Modules\AIChat\Models\AISettings($lineAccountId);
    echo "✅ Model AISettings สร้างสำเร็จ\n";
    echo "   - เปิดใช้งาน: " . ($settings->isEnabled() ? 'ใช่' : 'ไม่') . "\n";
    echo "   - Model: " . $settings->getModel() . "\n";
    echo "   - Temperature: " . $settings->getTemperature() . "\n";
    echo "   - Response Style: " . $settings->getResponseStyle() . "\n";
} catch (Exception $e) {
    echo "❌ Model Error: " . $e->getMessage() . "\n";
}

// 4. ทดสอบ Model ConversationHistory
echo "\n=== 4. ทดสอบ Model ConversationHistory ===\n";
try {
    $historyModel = new \Modules\AIChat\Models\ConversationHistory();
    echo "✅ Model ConversationHistory สร้างสำเร็จ\n";
    
    // ดึง user แรกจาก database
    $user = $db->fetchOne("SELECT id FROM users LIMIT 1");
    if ($user) {
        $history = $historyModel->getRecentHistory($user['id'], 5);
        echo "   - ประวัติสนทนา user #{$user['id']}: " . count($history) . " ข้อความ\n";
        
        if (!empty($history)) {
            echo "   - ตัวอย่างข้อความล่าสุด:\n";
            foreach (array_slice($history, -2) as $msg) {
                $preview = mb_substr($msg['content'], 0, 50);
                echo "     [{$msg['role']}]: {$preview}...\n";
            }
        }
    }
} catch (Exception $e) {
    echo "❌ Model Error: " . $e->getMessage() . "\n";
}

// 5. ทดสอบ Service ContextAnalyzer
echo "\n=== 5. ทดสอบ Service ContextAnalyzer ===\n";
try {
    $analyzer = new \Modules\AIChat\Services\ContextAnalyzer();
    echo "✅ Service ContextAnalyzer สร้างสำเร็จ\n";
    
    // ทดสอบวิเคราะห์ข้อความ
    $testHistory = [
        ['role' => 'user', 'content' => 'ปวดหัวมา 3 วันแล้วครับ'],
        ['role' => 'assistant', 'content' => 'มีอาการอื่นร่วมด้วยไหมคะ?'],
        ['role' => 'user', 'content' => 'ไม่มีครับ'],
        ['role' => 'assistant', 'content' => 'มีแพ้ยาอะไรไหมคะ?'],
        ['role' => 'user', 'content' => 'ไม่แพ้ครับ']
    ];
    
    $info = $analyzer->analyze($testHistory);
    echo "   - ข้อมูลที่วิเคราะห์ได้:\n";
    foreach ($info as $key => $value) {
        echo "     • {$key}: {$value}\n";
    }
    
    $missing = $analyzer->getMissingInfo($info);
    echo "   - ข้อมูลที่ยังขาด: " . (empty($missing) ? 'ไม่มี (ครบแล้ว)' : implode(', ', $missing)) . "\n";
} catch (Exception $e) {
    echo "❌ Service Error: " . $e->getMessage() . "\n";
}

// 6. ทดสอบ Adapter (Backward Compatible)
echo "\n=== 6. ทดสอบ Adapter (Backward Compatible) ===\n";
try {
    require_once __DIR__ . '/modules/AIChat/Adapters/GeminiChatAdapter.php';
    
    // ใช้ PDO connection จาก Core
    $pdo = $db->getConnection();
    
    $adapter = new \Modules\AIChat\Adapters\GeminiChatAdapter($pdo, $lineAccountId);
    echo "✅ Adapter สร้างสำเร็จ\n";
    echo "   - isEnabled(): " . ($adapter->isEnabled() ? 'true' : 'false') . "\n";
    
    if ($user) {
        $history = $adapter->getConversationHistory($user['id'], 3);
        echo "   - getConversationHistory(): " . count($history) . " ข้อความ\n";
    }
} catch (Exception $e) {
    echo "❌ Adapter Error: " . $e->getMessage() . "\n";
}

// 7. ทดสอบ API Key (ถ้าเปิดใช้งาน)
echo "\n=== 7. ทดสอบ Gemini API ===\n";
if (isset($settings) && $settings->isEnabled()) {
    try {
        $geminiAPI = new \Modules\AIChat\Services\GeminiAPI($settings);
        $testResult = $geminiAPI->testApiKey();
        
        if ($testResult['success']) {
            echo "✅ API Key ใช้งานได้\n";
            echo "   - Response: " . mb_substr($testResult['text'], 0, 50) . "\n";
        } else {
            echo "❌ API Key Error: " . $testResult['error'] . "\n";
        }
    } catch (Exception $e) {
        echo "❌ API Error: " . $e->getMessage() . "\n";
    }
} else {
    echo "⚠️ AI ไม่ได้เปิดใช้งาน - ข้ามการทดสอบ API\n";
}

echo "\n</pre>";
echo "<h2>✅ การทดสอบเสร็จสิ้น</h2>";
echo "<p><a href='ai-chat-settings.php'>กลับไปหน้าตั้งค่า AI Chat</a></p>";
