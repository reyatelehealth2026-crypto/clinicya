<?php
/**
 * Test Shop Settings - ตรวจสอบค่า is_open
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>ตรวจสอบค่า Shop Settings</h2>";

// Check business_settings
echo "<h3>1. business_settings table:</h3>";
try {
    $stmt = $db->query("SELECT id, line_account_id, is_open FROM business_settings");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($rows)) {
        echo "<p>ไม่มีข้อมูลในตาราง business_settings</p>";
    } else {
        echo "<table border='1'><tr><th>ID</th><th>line_account_id</th><th>is_open</th></tr>";
        foreach ($rows as $row) {
            echo "<tr><td>{$row['id']}</td><td>{$row['line_account_id']}</td><td>{$row['is_open']}</td></tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p style='color:orange'>ตาราง business_settings ไม่มี: " . $e->getMessage() . "</p>";
}

// Check shop_settings
echo "<h3>2. shop_settings table:</h3>";
try {
    $stmt = $db->query("SELECT id, line_account_id, shop_name, is_open FROM shop_settings");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($rows)) {
        echo "<p>ไม่มีข้อมูลในตาราง shop_settings</p>";
    } else {
        echo "<table border='1'><tr><th>ID</th><th>line_account_id</th><th>shop_name</th><th>is_open</th></tr>";
        foreach ($rows as $row) {
            $isOpen = $row['is_open'] ?? 'NULL';
            echo "<tr><td>{$row['id']}</td><td>{$row['line_account_id']}</td><td>{$row['shop_name']}</td><td style='background:" . ($isOpen ? 'green' : 'red') . ";color:white'>{$isOpen}</td></tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
}

// Test BusinessBot loading
echo "<h3>3. ทดสอบ BusinessBot loadSettings:</h3>";
require_once __DIR__ . '/classes/LineAPI.php';
require_once __DIR__ . '/classes/BusinessBot.php';
require_once __DIR__ . '/classes/FlexTemplates.php';

// Get all line accounts
$stmt = $db->query("SELECT id, name FROM line_accounts WHERE is_active = 1");
$accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($accounts as $acc) {
    echo "<h4>LINE Account: {$acc['name']} (ID: {$acc['id']})</h4>";
    
    $line = new LineAPI(); // dummy
    $bot = new BusinessBot($db, $line, $acc['id']);
    
    $isOpen = $bot->isShopOpen();
    echo "<p>isShopOpen(): <strong style='color:" . ($isOpen ? 'green' : 'red') . "'>" . ($isOpen ? 'เปิด (true)' : 'ปิด (false)') . "</strong></p>";
}

echo "<hr><p>ถ้าค่า is_open ในตาราง shop_settings เป็น 0 แต่ isShopOpen() ยังเป็น true แสดงว่ามีปัญหาในการโหลดค่า</p>";
