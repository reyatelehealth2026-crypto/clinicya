<?php
/**
 * Test Upload Directories
 */
require_once 'config/config.php';

echo "<h2>🔍 ตรวจสอบโฟลเดอร์อัพโหลด</h2>";

$dirs = [
    'uploads/',
    'uploads/slips/',
    'uploads/products/'
];

foreach ($dirs as $dir) {
    $fullPath = __DIR__ . '/' . $dir;
    echo "<h3>📁 {$dir}</h3>";
    
    if (!is_dir($fullPath)) {
        echo "<p style='color:red'>❌ โฟลเดอร์ไม่มีอยู่</p>";
        // Try to create
        if (mkdir($fullPath, 0755, true)) {
            echo "<p style='color:green'>✅ สร้างโฟลเดอร์สำเร็จ</p>";
        } else {
            echo "<p style='color:red'>❌ ไม่สามารถสร้างโฟลเดอร์ได้</p>";
        }
    } else {
        echo "<p style='color:green'>✅ โฟลเดอร์มีอยู่</p>";
    }
    
    if (is_writable($fullPath)) {
        echo "<p style='color:green'>✅ สามารถเขียนได้</p>";
        
        // Test write
        $testFile = $fullPath . 'test_' . time() . '.txt';
        if (file_put_contents($testFile, 'test')) {
            echo "<p style='color:green'>✅ ทดสอบเขียนไฟล์สำเร็จ</p>";
            unlink($testFile);
        } else {
            echo "<p style='color:red'>❌ ทดสอบเขียนไฟล์ล้มเหลว</p>";
        }
    } else {
        echo "<p style='color:red'>❌ ไม่สามารถเขียนได้ (permission denied)</p>";
    }
    
    echo "<hr>";
}

echo "<h2>🔗 BASE_URL</h2>";
echo "<p>BASE_URL = " . (defined('BASE_URL') ? BASE_URL : 'ไม่ได้กำหนด') . "</p>";

echo "<h2>📷 ตัวอย่าง URL สลิป</h2>";
$exampleUrl = (defined('BASE_URL') ? BASE_URL : 'http://localhost') . '/uploads/slips/slip_test.jpg';
echo "<p>{$exampleUrl}</p>";

// Check if any slips exist
$slipsDir = __DIR__ . '/uploads/slips/';
if (is_dir($slipsDir)) {
    $files = glob($slipsDir . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);
    echo "<h2>📋 ไฟล์สลิปที่มีอยู่ (" . count($files) . " ไฟล์)</h2>";
    if (count($files) > 0) {
        echo "<ul>";
        foreach (array_slice($files, 0, 10) as $file) {
            $filename = basename($file);
            $url = (defined('BASE_URL') ? BASE_URL : '') . '/uploads/slips/' . $filename;
            echo "<li><a href='{$url}' target='_blank'>{$filename}</a></li>";
        }
        echo "</ul>";
    } else {
        echo "<p>ยังไม่มีไฟล์สลิป</p>";
    }
}
?>
