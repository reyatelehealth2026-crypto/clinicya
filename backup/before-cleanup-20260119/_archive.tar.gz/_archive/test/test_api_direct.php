<?php
/**
 * Test API Direct - เรียก API โดยตรง
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Test API Direct</h2>";

// Test 1: Include files
echo "<h3>1. Include files</h3>";
try {
    require_once 'config/config.php';
    echo "<p>✅ config.php OK</p>";
    
    require_once 'config/database.php';
    echo "<p>✅ database.php OK</p>";
    
    require_once 'classes/LineAPI.php';
    echo "<p>✅ LineAPI.php OK</p>";
    
    require_once 'classes/LineAccountManager.php';
    echo "<p>✅ LineAccountManager.php OK</p>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test 2: Database connection
echo "<h3>2. Database</h3>";
try {
    $db = Database::getInstance()->getConnection();
    echo "<p>✅ Database connected</p>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test 3: LineAccountManager
echo "<h3>3. LineAccountManager</h3>";
try {
    $lineManager = new LineAccountManager($db);
    echo "<p>✅ LineAccountManager created</p>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test 4: get_user_tags query
echo "<h3>4. get_user_tags query</h3>";
$userId = 9;
try {
    $stmt = $db->prepare("SELECT t.* FROM user_tags t JOIN user_tag_assignments a ON t.id = a.tag_id WHERE a.user_id = ?");
    $stmt->execute([$userId]);
    $tags = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<p>✅ Query OK - Found " . count($tags) . " tags</p>";
    echo "<pre>" . json_encode(['success' => true, 'tags' => $tags], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test 5: Direct API call
echo "<h3>5. Direct API Response</h3>";
$url = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/api/ajax_handler.php?action=get_user_tags&user_id=9';
echo "<p>URL: <a href='{$url}' target='_blank'>{$url}</a></p>";

$response = @file_get_contents($url);
echo "<p>Response length: " . strlen($response) . " bytes</p>";
echo "<p>Response:</p>";
echo "<pre>" . htmlspecialchars($response) . "</pre>";
?>
