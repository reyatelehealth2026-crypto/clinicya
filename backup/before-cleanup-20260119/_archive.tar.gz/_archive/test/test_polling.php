<?php
/**
 * Test Polling API
 */
session_start();
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();
$currentBotId = $_SESSION['current_bot_id'] ?? 1;

// Get first user
$stmt = $db->prepare("SELECT id, display_name FROM users WHERE line_account_id = ? LIMIT 1");
$stmt->execute([$currentBotId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("No users found");
}

$userId = $user['id'];

// Get last message ID
$stmt = $db->prepare("SELECT MAX(id) as last_id FROM messages WHERE user_id = ?");
$stmt->execute([$userId]);
$lastId = $stmt->fetch(PDO::FETCH_ASSOC)['last_id'] ?? 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test Polling</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .log { background: #f5f5f5; padding: 10px; margin: 5px 0; border-radius: 5px; }
        .success { border-left: 4px solid green; }
        .error { border-left: 4px solid red; }
        #status { padding: 10px; margin: 10px 0; border-radius: 5px; }
        .polling { background: #FEF3C7; }
        .connected { background: #D1FAE5; }
        .disconnected { background: #FEE2E2; }
    </style>
</head>
<body>
    <h1>🔄 Test Polling</h1>
    
    <p>User: <strong><?= htmlspecialchars($user['display_name']) ?></strong> (ID: <?= $userId ?>)</p>
    <p>Last Message ID: <strong><?= $lastId ?></strong></p>
    
    <div id="status" class="disconnected">Status: Not started</div>
    
    <button onclick="startTest()">▶️ Start Polling</button>
    <button onclick="stopTest()">⏹️ Stop</button>
    <button onclick="clearLogs()">🗑️ Clear Logs</button>
    
    <h3>Logs:</h3>
    <div id="logs"></div>
    
    <script>
    const userId = <?= $userId ?>;
    let lastId = <?= $lastId ?>;
    let interval = null;
    let pollCount = 0;
    
    function log(msg, type = 'info') {
        const div = document.createElement('div');
        div.className = 'log ' + (type === 'error' ? 'error' : 'success');
        div.innerHTML = `<small>${new Date().toLocaleTimeString()}</small> - ${msg}`;
        document.getElementById('logs').prepend(div);
    }
    
    function setStatus(text, cls) {
        const el = document.getElementById('status');
        el.textContent = text;
        el.className = cls;
    }
    
    async function poll() {
        pollCount++;
        setStatus(`Polling... (#${pollCount})`, 'polling');
        
        try {
            const url = `api/messages.php?action=poll&user_id=${userId}&last_id=${lastId}&_t=${Date.now()}`;
            log(`Fetching: ${url}`);
            
            const res = await fetch(url);
            const text = await res.text();
            
            log(`Response: ${res.status} - ${text.substring(0, 200)}`);
            
            if (!res.ok) {
                throw new Error(`HTTP ${res.status}`);
            }
            
            const data = JSON.parse(text);
            
            if (data.success) {
                setStatus(`Connected - Poll #${pollCount}`, 'connected');
                
                if (data.messages && data.messages.length > 0) {
                    log(`📨 NEW MESSAGES: ${data.messages.length}`, 'success');
                    data.messages.forEach(m => {
                        log(`  - [${m.id}] ${m.direction}: ${m.content?.substring(0, 50)}...`);
                        if (parseInt(m.id) > lastId) {
                            lastId = parseInt(m.id);
                        }
                    });
                }
            } else {
                log(`Error: ${data.error}`, 'error');
            }
        } catch (err) {
            setStatus(`Error: ${err.message}`, 'disconnected');
            log(`Error: ${err.message}`, 'error');
        }
    }
    
    function startTest() {
        if (interval) return;
        log('Starting polling...');
        poll(); // immediate
        interval = setInterval(poll, 2000);
    }
    
    function stopTest() {
        if (interval) {
            clearInterval(interval);
            interval = null;
            setStatus('Stopped', 'disconnected');
            log('Polling stopped');
        }
    }
    
    function clearLogs() {
        document.getElementById('logs').innerHTML = '';
    }
    </script>
</body>
</html>
