<?php
/**
 * Test LIFF Orders - ทดสอบหน้าออเดอร์โดยตรง
 * เปิดผ่าน: test_liff_orders.php?account=3&user=Ub85be041ec79c72b08d3ff7143f8d691
 */
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/liff-helper.php';

$db = Database::getInstance()->getConnection();
$lineAccountId = $_GET['account'] ?? 3;
$testUserId = $_GET['user'] ?? '';

$liffData = getUnifiedLiffId($db, $lineAccountId);
$liffId = $liffData['liff_id'];
$baseUrl = rtrim(BASE_URL, '/');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test LIFF Orders</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://static.line-scdn.net/liff/edge/2/sdk.js"></script>
</head>
<body class="bg-gray-100 p-4">
    <div class="max-w-md mx-auto">
        <h1 class="text-xl font-bold mb-4">🧪 Test LIFF Orders</h1>
        
        <div class="bg-white rounded-lg p-4 mb-4">
            <h2 class="font-bold mb-2">Config:</h2>
            <p><strong>LIFF ID:</strong> <?= $liffId ?: '<span class="text-red-500">NOT SET</span>' ?></p>
            <p><strong>Account ID:</strong> <?= $lineAccountId ?></p>
            <p><strong>Test User ID:</strong> <?= $testUserId ?: 'Not provided' ?></p>
            <p><strong>Base URL:</strong> <?= $baseUrl ?></p>
        </div>
        
        <div id="status" class="bg-white rounded-lg p-4 mb-4">
            <h2 class="font-bold mb-2">LIFF Status:</h2>
            <p id="liffStatus">Initializing...</p>
        </div>
        
        <div id="orders" class="bg-white rounded-lg p-4">
            <h2 class="font-bold mb-2">Orders:</h2>
            <div id="ordersList">Loading...</div>
        </div>
        
        <div class="mt-4 space-y-2">
            <button onclick="loadOrdersManual()" class="w-full py-2 bg-blue-500 text-white rounded-lg">
                Load Orders (Manual)
            </button>
            <a href="liff-my-orders.php?account=<?= $lineAccountId ?>" class="block w-full py-2 bg-green-500 text-white rounded-lg text-center">
                Go to Real Orders Page
            </a>
        </div>
    </div>
    
    <script>
    const LIFF_ID = '<?= $liffId ?>';
    const ACCOUNT_ID = <?= (int)$lineAccountId ?>;
    const BASE_URL = '<?= $baseUrl ?>';
    const TEST_USER_ID = '<?= $testUserId ?>';
    
    let userId = TEST_USER_ID || null;
    
    document.addEventListener('DOMContentLoaded', init);
    
    async function init() {
        const statusEl = document.getElementById('liffStatus');
        
        if (!LIFF_ID) {
            statusEl.innerHTML = '<span class="text-red-500">❌ LIFF ID not configured</span>';
            if (TEST_USER_ID) {
                statusEl.innerHTML += '<br>Using test user ID: ' + TEST_USER_ID;
                await loadOrders();
            }
            return;
        }
        
        try {
            statusEl.textContent = 'Initializing LIFF...';
            await liff.init({ liffId: LIFF_ID });
            
            const isLoggedIn = liff.isLoggedIn();
            const isInClient = liff.isInClient();
            
            statusEl.innerHTML = `
                <p>✅ LIFF Initialized</p>
                <p>isLoggedIn: ${isLoggedIn}</p>
                <p>isInClient: ${isInClient}</p>
            `;
            
            if (isLoggedIn) {
                const profile = await liff.getProfile();
                userId = profile.userId;
                statusEl.innerHTML += `<p>userId: ${userId}</p>`;
                await loadOrders();
            } else if (TEST_USER_ID) {
                userId = TEST_USER_ID;
                statusEl.innerHTML += `<p>Using test userId: ${userId}</p>`;
                await loadOrders();
            } else {
                statusEl.innerHTML += '<p class="text-orange-500">⚠️ Not logged in</p>';
                document.getElementById('ordersList').innerHTML = 'Please login or provide ?user=xxx';
            }
        } catch (e) {
            statusEl.innerHTML = `<span class="text-red-500">❌ Error: ${e.message}</span>`;
            console.error(e);
            
            // Try with test user
            if (TEST_USER_ID) {
                userId = TEST_USER_ID;
                statusEl.innerHTML += `<br>Trying with test user: ${TEST_USER_ID}`;
                await loadOrders();
            }
        }
    }
    
    async function loadOrders() {
        const listEl = document.getElementById('ordersList');
        
        if (!userId) {
            listEl.innerHTML = '<span class="text-red-500">No user ID</span>';
            return;
        }
        
        const apiUrl = `${BASE_URL}/api/orders.php?action=my_orders&line_user_id=${userId}&line_account_id=${ACCOUNT_ID}`;
        listEl.innerHTML = `Loading from: <br><small>${apiUrl}</small>`;
        
        try {
            const response = await fetch(apiUrl);
            const data = await response.json();
            
            console.log('API Response:', data);
            
            if (data.success && data.orders?.length > 0) {
                let html = `<p class="text-green-600 mb-2">✅ Found ${data.orders.length} orders</p>`;
                data.orders.forEach(order => {
                    html += `
                        <div class="border rounded p-2 mb-2">
                            <p><strong>#${order.order_id}</strong></p>
                            <p>Status: ${order.status}</p>
                            <p>Total: ฿${order.total_amount}</p>
                            <p>Items: ${order.items?.length || 0}</p>
                        </div>
                    `;
                });
                listEl.innerHTML = html;
            } else {
                listEl.innerHTML = `<span class="text-orange-500">No orders found</span><br><small>${JSON.stringify(data)}</small>`;
            }
        } catch (e) {
            listEl.innerHTML = `<span class="text-red-500">Error: ${e.message}</span>`;
            console.error(e);
        }
    }
    
    function loadOrdersManual() {
        const testUser = prompt('Enter LINE User ID:', TEST_USER_ID || 'Ub85be041ec79c72b08d3ff7143f8d691');
        if (testUser) {
            userId = testUser;
            loadOrders();
        }
    }
    </script>
</body>
</html>
