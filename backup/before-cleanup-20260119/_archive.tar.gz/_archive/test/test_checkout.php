<?php
/**
 * Test Checkout Flow - Debug Script
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'classes/LineAPI.php';
require_once 'classes/BusinessBot.php';
require_once 'classes/FlexTemplates.php';

$db = Database::getInstance()->getConnection();

echo "<h1>🛒 Checkout Flow Debug</h1>";
echo "<style>body{font-family:sans-serif;padding:20px;} .ok{color:green;} .error{color:red;} .warn{color:orange;} pre{background:#f5f5f5;padding:10px;border-radius:5px;}</style>";

// 1. Check user_states table
echo "<h2>1. ตรวจสอบตาราง user_states</h2>";
try {
    $stmt = $db->query("SHOW TABLES LIKE 'user_states'");
    if ($stmt->rowCount() > 0) {
        echo "<p class='ok'>✅ ตาราง user_states มีอยู่</p>";
        
        // Show structure
        $stmt = $db->query("DESCRIBE user_states");
        echo "<pre>";
        print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
        echo "</pre>";
    } else {
        echo "<p class='error'>❌ ตาราง user_states ไม่มี - ต้องสร้างก่อน!</p>";
        echo "<pre>
CREATE TABLE IF NOT EXISTS user_states (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    state VARCHAR(50) NOT NULL,
    state_data JSON,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_state (user_id),
    INDEX idx_state (state),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</pre>";
        
        // Auto create
        echo "<h3>กำลังสร้างตาราง...</h3>";
        $db->exec("
            CREATE TABLE IF NOT EXISTS user_states (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                state VARCHAR(50) NOT NULL,
                state_data JSON,
                expires_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_state (user_id),
                INDEX idx_state (state),
                INDEX idx_expires (expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "<p class='ok'>✅ สร้างตาราง user_states สำเร็จ!</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// 2. Check cart_items table
echo "<h2>2. ตรวจสอบตาราง cart_items</h2>";
try {
    $stmt = $db->query("SHOW TABLES LIKE 'cart_items'");
    if ($stmt->rowCount() > 0) {
        echo "<p class='ok'>✅ ตาราง cart_items มีอยู่</p>";
        
        // Count items
        $stmt = $db->query("SELECT COUNT(*) as count FROM cart_items");
        $count = $stmt->fetch()['count'];
        echo "<p>📦 มี {$count} รายการในตะกร้าทั้งหมด</p>";
    } else {
        echo "<p class='error'>❌ ตาราง cart_items ไม่มี</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// 3. Check orders/transactions table
echo "<h2>3. ตรวจสอบตาราง orders/transactions</h2>";
try {
    $hasOrders = false;
    $hasTransactions = false;
    
    try {
        $db->query("SELECT 1 FROM orders LIMIT 1");
        $hasOrders = true;
        echo "<p class='ok'>✅ ตาราง orders มีอยู่</p>";
    } catch (Exception $e) {
        echo "<p class='warn'>⚠️ ตาราง orders ไม่มี</p>";
    }
    
    try {
        $db->query("SELECT 1 FROM transactions LIMIT 1");
        $hasTransactions = true;
        echo "<p class='ok'>✅ ตาราง transactions มีอยู่</p>";
    } catch (Exception $e) {
        echo "<p class='warn'>⚠️ ตาราง transactions ไม่มี</p>";
    }
    
    if (!$hasOrders && !$hasTransactions) {
        echo "<p class='error'>❌ ไม่มีตารางสำหรับเก็บคำสั่งซื้อ!</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// 4. Check order_items/transaction_items table
echo "<h2>4. ตรวจสอบตาราง order_items/transaction_items</h2>";
try {
    $hasOrderItems = false;
    $hasTransactionItems = false;
    
    try {
        $db->query("SELECT 1 FROM order_items LIMIT 1");
        $hasOrderItems = true;
        echo "<p class='ok'>✅ ตาราง order_items มีอยู่</p>";
    } catch (Exception $e) {
        echo "<p class='warn'>⚠️ ตาราง order_items ไม่มี</p>";
    }
    
    try {
        $db->query("SELECT 1 FROM transaction_items LIMIT 1");
        $hasTransactionItems = true;
        echo "<p class='ok'>✅ ตาราง transaction_items มีอยู่</p>";
    } catch (Exception $e) {
        echo "<p class='warn'>⚠️ ตาราง transaction_items ไม่มี</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// 5. Check products/business_items table
echo "<h2>5. ตรวจสอบตารางสินค้า</h2>";
try {
    $hasProducts = false;
    $hasBusinessItems = false;
    
    try {
        $db->query("SELECT 1 FROM products LIMIT 1");
        $hasProducts = true;
        $stmt = $db->query("SELECT COUNT(*) as count FROM products WHERE is_active = 1");
        $count = $stmt->fetch()['count'];
        echo "<p class='ok'>✅ ตาราง products มีอยู่ ({$count} สินค้า active)</p>";
    } catch (Exception $e) {
        echo "<p class='warn'>⚠️ ตาราง products ไม่มี</p>";
    }
    
    try {
        $db->query("SELECT 1 FROM business_items LIMIT 1");
        $hasBusinessItems = true;
        $stmt = $db->query("SELECT COUNT(*) as count FROM business_items WHERE is_active = 1");
        $count = $stmt->fetch()['count'];
        echo "<p class='ok'>✅ ตาราง business_items มีอยู่ ({$count} items active)</p>";
    } catch (Exception $e) {
        echo "<p class='warn'>⚠️ ตาราง business_items ไม่มี</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// 6. Test BusinessBot checkout flow
echo "<h2>6. ทดสอบ BusinessBot Checkout Flow</h2>";
try {
    // Get a test user
    $stmt = $db->query("SELECT id, line_user_id, display_name FROM users LIMIT 1");
    $testUser = $stmt->fetch();
    
    if ($testUser) {
        echo "<p>👤 Test User: {$testUser['display_name']} (ID: {$testUser['id']})</p>";
        
        // Check if user has items in cart
        $stmt = $db->prepare("SELECT c.*, p.name, p.price FROM cart_items c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?");
        $stmt->execute([$testUser['id']]);
        $cartItems = $stmt->fetchAll();
        
        if (!empty($cartItems)) {
            echo "<p class='ok'>✅ User มีสินค้าในตะกร้า:</p>";
            echo "<ul>";
            foreach ($cartItems as $item) {
                echo "<li>{$item['name']} x {$item['quantity']} = ฿" . number_format($item['price'] * $item['quantity']) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p class='warn'>⚠️ User ไม่มีสินค้าในตะกร้า - ต้องเพิ่มสินค้าก่อน checkout</p>";
        }
        
        // Check user state
        $stmt = $db->prepare("SELECT * FROM user_states WHERE user_id = ?");
        $stmt->execute([$testUser['id']]);
        $state = $stmt->fetch();
        
        if ($state) {
            echo "<p class='warn'>⚠️ User มี state อยู่: {$state['state']}</p>";
            echo "<pre>" . print_r($state, true) . "</pre>";
        } else {
            echo "<p class='ok'>✅ User ไม่มี state (พร้อม checkout)</p>";
        }
    } else {
        echo "<p class='error'>❌ ไม่มี user ในระบบ</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// 7. Check BusinessBot command mapping
echo "<h2>7. ตรวจสอบ Command Mapping</h2>";
echo "<p>Commands ที่ BusinessBot รองรับสำหรับ checkout:</p>";
echo "<ul>";
echo "<li><code>checkout</code> → startCheckout</li>";
echo "<li><code>สั่งซื้อ</code> → startCheckout</li>";
echo "<li><code>ชำระเงิน</code> → startCheckout</li>";
echo "<li><code>จ่ายเงิน</code> → startCheckout</li>";
echo "</ul>";

echo "<p class='warn'>⚠️ หมายเหตุ: ถ้าปุ่มในตะกร้าส่งข้อความอื่น (เช่น 'ยืนยันสั่งซื้อ') จะไม่ทำงาน!</p>";

// 8. Show current user states
echo "<h2>8. User States ปัจจุบัน</h2>";
try {
    // ตรวจสอบ structure ของตาราง user_states ก่อน
    $stmt = $db->query("DESCRIBE user_states");
    $columnsData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $columns = array_column($columnsData, 'Field');
    
    echo "<p>Columns ในตาราง user_states: " . implode(', ', $columns) . "</p>";
    
    $hasCreatedAt = in_array('created_at', $columns);
    $hasId = in_array('id', $columns);
    
    // เลือก ORDER BY ตาม column ที่มี
    $orderBy = 'us.user_id DESC';
    if ($hasCreatedAt) {
        $orderBy = 'us.created_at DESC';
    } elseif ($hasId) {
        $orderBy = 'us.id DESC';
    }
    
    $stmt = $db->query("SELECT us.*, u.display_name FROM user_states us LEFT JOIN users u ON us.user_id = u.id ORDER BY {$orderBy} LIMIT 10");
    $states = $stmt->fetchAll();
    
    if (!empty($states)) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>User</th><th>State</th><th>Data</th><th>Expires</th></tr>";
        foreach ($states as $s) {
            echo "<tr>";
            echo "<td>" . ($s['display_name'] ?? 'Unknown') . " (ID: {$s['user_id']})</td>";
            echo "<td>{$s['state']}</td>";
            echo "<td><pre>" . htmlspecialchars($s['state_data'] ?? '{}') . "</pre></td>";
            echo "<td>" . ($s['expires_at'] ?? 'N/A') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>ไม่มี user states</p>";
    }
    
    // แสดงคำแนะนำถ้าตารางไม่สมบูรณ์
    $missingCols = [];
    if (!$hasId) $missingCols[] = 'id';
    if (!$hasCreatedAt) $missingCols[] = 'created_at';
    if (!in_array('updated_at', $columns)) $missingCols[] = 'updated_at';
    
    if (!empty($missingCols)) {
        echo "<p class='warn'>⚠️ ตาราง user_states ไม่มี columns: " . implode(', ', $missingCols) . "</p>";
        echo "<p>แนะนำให้รัน migration เพื่อสร้างตารางใหม่:</p>";
        echo "<pre>
DROP TABLE IF EXISTS user_states;
CREATE TABLE user_states (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    state VARCHAR(50) NOT NULL,
    state_data JSON,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_state (user_id),
    INDEX idx_state (state),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</pre>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='test_shop.php'>← กลับไปหน้า Test Shop</a></p>";
