<?php
/**
 * Test LIFF Menu - ทดสอบ LIFF Menu สำหรับข้อความแรก
 */
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'classes/FlexTemplates.php';

$db = Database::getInstance()->getConnection();

echo "<h2>🧪 Test LIFF Menu</h2>";

// 1. Check LINE Account LIFF ID
echo "<h3>1. LINE Account Info</h3>";
$stmt = $db->query("SELECT id, name, liff_id, bot_mode FROM line_accounts WHERE id = 1");
$account = $stmt->fetch(PDO::FETCH_ASSOC);
echo "<pre>";
print_r($account);
echo "</pre>";

if (empty($account['liff_id'])) {
    echo "<p style='color:red'>⚠️ LINE Account ID 1 ยังไม่มี LIFF ID!</p>";
    echo "<p>กรุณาตั้งค่า LIFF ID ที่หน้า <a href='line-accounts.php'>LINE Accounts</a> หรือ <a href='liff-settings.php'>LIFF Settings</a></p>";
} else {
    echo "<p style='color:green'>✅ LIFF ID: {$account['liff_id']}</p>";
    echo "<p>LIFF URL: https://liff.line.me/{$account['liff_id']}</p>";
}

// 2. Test FlexTemplates::firstMessageMenu
echo "<h3>2. Test Flex Template</h3>";
$liffUrl = !empty($account['liff_id']) ? 'https://liff.line.me/' . $account['liff_id'] : 'https://liff.line.me/test-liff-id';
$shopName = $account['name'] ?? 'Test Shop';
$displayName = 'ทดสอบ';

$flexBubble = FlexTemplates::firstMessageMenu($shopName, $liffUrl, $displayName);
$flexMessage = FlexTemplates::toMessage($flexBubble, "ยินดีต้อนรับสู่ {$shopName}");

echo "<pre style='background:#f5f5f5; padding:10px; overflow:auto; max-height:400px;'>";
echo json_encode($flexMessage, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
echo "</pre>";

// 3. Check user message count
echo "<h3>3. Test User Message Count</h3>";
$testUserId = 13; // jame.ver
$stmt = $db->prepare("SELECT COUNT(*) FROM messages WHERE user_id = ? AND direction = 'incoming'");
$stmt->execute([$testUserId]);
$count = $stmt->fetchColumn();
echo "<p>User ID {$testUserId} มีข้อความ incoming: <strong>{$count}</strong> ข้อความ</p>";
echo "<p>isFirstMessage = " . ($count == 0 ? 'true' : 'false') . "</p>";

// 4. Preview Flex Message
echo "<h3>4. Flex Preview</h3>";
echo "<p>ดู preview ที่ <a href='https://developers.line.biz/flex-simulator/' target='_blank'>LINE Flex Simulator</a></p>";
echo "<p>Copy JSON ด้านบนไปวางใน Simulator</p>";

// 5. LIFF Main URL
echo "<h3>5. LIFF Main URL</h3>";
if (!empty($account['liff_id'])) {
    $liffMainUrl = BASE_URL . '/liff-main.php?account=1';
    echo "<p>LIFF Main URL: <a href='{$liffMainUrl}' target='_blank'>{$liffMainUrl}</a></p>";
    echo "<p>สำหรับ Rich Menu ให้ใช้ URL: <code>https://liff.line.me/{$account['liff_id']}</code></p>";
    echo "<p>แล้วตั้ง Endpoint URL ใน LINE Developers Console เป็น: <code>" . BASE_URL . "/liff-main.php</code></p>";
} else {
    echo "<p style='color:orange'>⚠️ ยังไม่มี LIFF ID - ทดสอบ LIFF Main โดยตรง: <a href='liff-main.php?account=1' target='_blank'>liff-main.php</a></p>";
}

echo "<hr><p>✅ Test completed!</p>";
