<?php
/**
 * Test LIFF Flow - ตรวจสอบการตั้งค่า LIFF ทั้งหมด
 */
require_once 'config/config.php';
require_once 'config/database.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h1>🔍 LIFF Flow Test</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
    .success { color: green; }
    .error { color: red; }
    .warning { color: orange; }
    table { border-collapse: collapse; width: 100%; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
    th { background: #f5f5f5; }
    .box { background: #f9f9f9; padding: 15px; border-radius: 8px; margin: 15px 0; }
    a { color: #06C755; }
</style>";

try {
    $db = Database::getInstance()->getConnection();
    
    // 1. Check LINE Accounts LIFF IDs
    echo "<h2>1. LINE Accounts LIFF IDs</h2>";
    $stmt = $db->query("SELECT id, name, liff_id, liff_shop_id, liff_checkout_id, liff_video_id, liff_share_id, is_default FROM line_accounts");
    $accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table>";
    echo "<tr><th>ID</th><th>Name</th><th>Main</th><th>Shop</th><th>Checkout</th><th>Video</th><th>Share</th><th>Default</th></tr>";
    foreach ($accounts as $acc) {
        echo "<tr>";
        echo "<td>{$acc['id']}</td>";
        echo "<td>{$acc['name']}</td>";
        echo "<td>" . ($acc['liff_id'] ?: '<span class="error">❌ ไม่มี</span>') . "</td>";
        echo "<td>" . ($acc['liff_shop_id'] ?: '<span class="warning">⚠️ ไม่มี</span>') . "</td>";
        echo "<td>" . ($acc['liff_checkout_id'] ?: '<span class="warning">⚠️ ไม่มี</span>') . "</td>";
        echo "<td>" . ($acc['liff_video_id'] ?: '<span class="warning">⚠️ ไม่มี</span>') . "</td>";
        echo "<td>" . ($acc['liff_share_id'] ?: '<span class="warning">⚠️ ไม่มี</span>') . "</td>";
        echo "<td>" . ($acc['is_default'] ? '✅' : '') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 2. LIFF URLs
    echo "<h2>2. LIFF URLs (ลิ้งค์ที่ใช้งาน)</h2>";
    $defaultAcc = null;
    foreach ($accounts as $acc) {
        if ($acc['is_default']) {
            $defaultAcc = $acc;
            break;
        }
    }
    if (!$defaultAcc && !empty($accounts)) {
        $defaultAcc = $accounts[0];
    }
    
    if ($defaultAcc) {
        echo "<div class='box'>";
        echo "<p><strong>Account:</strong> {$defaultAcc['name']} (ID: {$defaultAcc['id']})</p>";
        echo "<ul>";
        if ($defaultAcc['liff_id']) {
            echo "<li>🏠 <strong>Main:</strong> <a href='https://liff.line.me/{$defaultAcc['liff_id']}' target='_blank'>https://liff.line.me/{$defaultAcc['liff_id']}</a></li>";
        }
        if ($defaultAcc['liff_shop_id']) {
            echo "<li>🛒 <strong>Shop:</strong> <a href='https://liff.line.me/{$defaultAcc['liff_shop_id']}' target='_blank'>https://liff.line.me/{$defaultAcc['liff_shop_id']}</a></li>";
        }
        if ($defaultAcc['liff_checkout_id']) {
            echo "<li>💳 <strong>Checkout:</strong> <a href='https://liff.line.me/{$defaultAcc['liff_checkout_id']}' target='_blank'>https://liff.line.me/{$defaultAcc['liff_checkout_id']}</a></li>";
        }
        if ($defaultAcc['liff_video_id']) {
            echo "<li>📹 <strong>Video:</strong> <a href='https://liff.line.me/{$defaultAcc['liff_video_id']}' target='_blank'>https://liff.line.me/{$defaultAcc['liff_video_id']}</a></li>";
        }
        echo "</ul>";
        echo "</div>";
    }
    
    // 3. Check Flow: Shop → Checkout
    echo "<h2>3. Flow Test: Shop → Checkout</h2>";
    echo "<div class='box'>";
    
    if ($defaultAcc['liff_shop_id'] && $defaultAcc['liff_checkout_id']) {
        echo "<p class='success'>✅ ทั้ง Shop และ Checkout LIFF ID ถูกตั้งค่าแล้ว</p>";
        echo "<p><strong>Flow ที่ถูกต้อง:</strong></p>";
        echo "<ol>";
        echo "<li>ลูกค้าเปิด Shop: <code>https://liff.line.me/{$defaultAcc['liff_shop_id']}</code></li>";
        echo "<li>กดตะกร้า → กดสั่งซื้อ</li>";
        echo "<li>ระบบจะ redirect ไป Checkout: <code>https://liff.line.me/{$defaultAcc['liff_checkout_id']}?user=Uxxxx&action=address</code></li>";
        echo "<li>กรอกที่อยู่ → เลือกวิธีชำระเงิน → อัพโหลดสลิป</li>";
        echo "</ol>";
    } else {
        echo "<p class='error'>❌ ยังไม่ได้ตั้งค่า LIFF ID ครบ</p>";
        if (!$defaultAcc['liff_shop_id']) echo "<p class='error'>- ไม่มี liff_shop_id</p>";
        if (!$defaultAcc['liff_checkout_id']) echo "<p class='error'>- ไม่มี liff_checkout_id</p>";
    }
    echo "</div>";
    
    // 4. LINE Developers Endpoint URLs
    echo "<h2>4. LINE Developers Endpoint URLs (ต้องตั้งค่าให้ตรง)</h2>";
    echo "<div class='box'>";
    $baseUrl = rtrim(BASE_URL, '/');
    echo "<p><strong>BASE_URL:</strong> {$baseUrl}</p>";
    echo "<p><strong>Endpoint URLs ที่ต้องตั้งใน LINE Developers:</strong></p>";
    echo "<table>";
    echo "<tr><th>LIFF App</th><th>Endpoint URL</th></tr>";
    echo "<tr><td>Main (หน้าหลัก)</td><td><code>{$baseUrl}/liff-main.php</code></td></tr>";
    echo "<tr><td>Shop (ร้านค้า)</td><td><code>{$baseUrl}/liff-shop.php</code></td></tr>";
    echo "<tr><td>Checkout (สั่งซื้อ)</td><td><code>{$baseUrl}/liff-checkout.php</code></td></tr>";
    echo "<tr><td>Video (วิดีโอคอล)</td><td><code>{$baseUrl}/liff-video-call-pro.php</code></td></tr>";
    echo "</table>";
    echo "<p class='warning'>⚠️ <strong>สำคัญ:</strong> URL ต้องตรงเป๊ะ! ไม่มี www. ถ้า BASE_URL ไม่มี www.</p>";
    echo "</div>";
    
    // 5. Test Links
    echo "<h2>5. Test Links (Debug Mode)</h2>";
    echo "<div class='box'>";
    echo "<ul>";
    echo "<li><a href='liff-main.php?debug=1' target='_blank'>🔍 Debug Main</a></li>";
    echo "<li><a href='liff-shop.php?debug=1' target='_blank'>🔍 Debug Shop</a></li>";
    echo "<li><a href='liff-checkout.php?debug=1' target='_blank'>🔍 Debug Checkout</a></li>";
    echo "<li><a href='update_all_liff.php' target='_blank'>🔧 Update All LIFF IDs</a></li>";
    echo "</ul>";
    echo "</div>";
    
    // 6. Check uploads folder
    echo "<h2>6. Uploads Folder (สำหรับสลิป)</h2>";
    $slipDir = __DIR__ . '/uploads/slips/';
    echo "<div class='box'>";
    if (is_dir($slipDir)) {
        if (is_writable($slipDir)) {
            echo "<p class='success'>✅ โฟลเดอร์ uploads/slips/ พร้อมใช้งาน</p>";
        } else {
            echo "<p class='error'>❌ โฟลเดอร์ uploads/slips/ ไม่สามารถเขียนได้</p>";
        }
    } else {
        echo "<p class='warning'>⚠️ โฟลเดอร์ uploads/slips/ ยังไม่มี (จะสร้างอัตโนมัติเมื่ออัพโหลดสลิป)</p>";
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}
?>
