<?php
/**
 * Test Pharmacy RAG System
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/modules/AIChat/Services/PharmacyRAG.php';

use Modules\AIChat\Services\PharmacyRAG;

header('Content-Type: text/html; charset=utf-8');

$db = Database::getInstance()->getConnection();
$rag = new PharmacyRAG($db);

// Test queries
$testQueries = [
    'ปวดหัวมาก 2 วันแล้ว',
    'มียาแก้ท้องเสียไหม',
    'หาพาราเซตามอล',
    'SKU 0001',
    'ยาแก้แพ้',
    'เป็นหวัด มีไข้ ไอ',
    'วิตามินซี',
];

echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Test Pharmacy RAG</title>';
echo '<style>body{font-family:sans-serif;padding:20px;} .result{background:#f5f5f5;padding:15px;margin:10px 0;border-radius:8px;} pre{white-space:pre-wrap;}</style>';
echo '</head><body>';

echo '<h1>🔍 Test Pharmacy RAG System</h1>';

foreach ($testQueries as $query) {
    echo "<div class='result'>";
    echo "<h3>Query: \"{$query}\"</h3>";
    
    $results = $rag->search($query, 10);
    
    echo "<h4>Products Found: " . count($results['products']) . "</h4>";
    if (!empty($results['products'])) {
        echo "<ul>";
        foreach (array_slice($results['products'], 0, 5) as $p) {
            $sku = $p['sku'] ?? $p['barcode'] ?? '';
            echo "<li><strong>{$p['name']}</strong>";
            if ($sku) echo " [SKU:{$sku}]";
            echo " - ฿{$p['price']}";
            if (!empty($p['generic_name'])) echo " ({$p['generic_name']})";
            echo "</li>";
        }
        echo "</ul>";
    }
    
    if (!empty($results['knowledge'])) {
        echo "<h4>Knowledge:</h4>";
        foreach ($results['knowledge'] as $k) {
            if (!$k) continue;
            echo "<p><strong>{$k['symptom']}</strong>: {$k['first_aid']}</p>";
        }
    }
    
    echo "<h4>AI Context:</h4>";
    echo "<pre>" . htmlspecialchars(mb_substr($rag->formatForAI($results), 0, 1000)) . "...</pre>";
    
    echo "</div>";
}

echo '</body></html>';
