<?php
/**
 * ทดสอบ CNY API - ดึงข้อมูลสินค้าด้วย SKU
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/classes/CnyPharmacyAPI.php';

$db = Database::getInstance()->getConnection();
$cnyApi = new CnyPharmacyAPI($db);

$sku = $_GET['sku'] ?? '0001';

echo "<h2>🔍 ทดสอบ CNY API - SKU: {$sku}</h2>";

// Test API - ใช้ cache ก่อน ถ้าไม่เจอค่อยเรียก API โดยตรง
$result = $cnyApi->getProductFromCache($sku);

echo "<h3>Result (from Cache):</h3>";
echo "<pre>";
echo "Success: " . ($result['success'] ? 'Yes' : 'No') . "\n";
echo "From Cache: " . (($result['from_cache'] ?? false) ? 'Yes' : 'No') . "\n";

if (isset($result['error'])) {
    echo "Error: " . $result['error'] . "\n";
    
    // ถ้าไม่เจอใน cache ลองเรียก API โดยตรง
    echo "\n--- Trying direct API call ---\n";
    $directResult = $cnyApi->getProductBySku($sku);
    echo "Direct API Success: " . ($directResult['success'] ? 'Yes' : 'No') . "\n";
    if (isset($directResult['is_html'])) {
        echo "⚠️ API returned HTML - SKU ไม่มีในระบบ CNY\n";
    } elseif (isset($directResult['error'])) {
        echo "Error: " . $directResult['error'] . "\n";
    }
}

if (isset($result['data'])) {
    echo "\nData:\n";
    print_r($result['data']);
}

echo "</pre>";

// Test a few SKUs - ใช้ cache แทน API โดยตรง
echo "<h3>🧪 ทดสอบหลาย SKU (จาก Cache):</h3>";
$testSkus = ['0001', '0002', '0003', '0004', '0005', '0006', '0007', '0008', '0009', '0010'];

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>SKU</th><th>Status</th><th>Name</th><th>Price</th></tr>";

foreach ($testSkus as $testSku) {
    // ใช้ getProductFromCache แทน getProductBySku เพื่อหลีกเลี่ยง HTML response
    $r = $cnyApi->getProductFromCache($testSku);
    $status = $r['success'] ? '✓' : '✗';
    $name = '-';
    $price = '-';
    
    if ($r['success'] && !empty($r['data'])) {
        $name = $r['data']['name'] ?? $r['data']['name_en'] ?? '-';
        $prices = $r['data']['product_price'] ?? [];
        if (!empty($prices[0]['price'])) {
            $price = number_format($prices[0]['price'], 2);
        }
    } elseif (isset($r['error'])) {
        $status = '⏭ ' . substr($r['error'], 0, 20);
    }
    
    echo "<tr>";
    echo "<td><a href='?sku={$testSku}'>{$testSku}</a></td>";
    echo "<td>{$status}</td>";
    echo "<td>" . htmlspecialchars(mb_substr($name, 0, 50)) . "</td>";
    echo "<td>{$price}</td>";
    echo "</tr>";
}

echo "</table>";
echo "<p><small>💡 ใช้ข้อมูลจาก /get_product_all cache (1 ชม.) แทนการเรียก API ทีละ SKU</small></p>";

// Show SKU list
echo "<h3>📋 SKU List (first 50):</h3>";
$skuResult = $cnyApi->getSkuList();
if ($skuResult['success']) {
    $skus = array_slice($skuResult['data'], 0, 50);
    echo "<p>Total SKUs: " . count($skuResult['data']) . " (cached: " . ($skuResult['cached'] ? 'yes' : 'no') . ")</p>";
    echo "<pre>" . implode(', ', $skus) . "</pre>";
} else {
    echo "<p>Error: " . ($skuResult['error'] ?? 'Unknown') . "</p>";
}
