<?php
/**
 * Test Users Query - Debug ว่า query ใน users.php ทำงานถูกต้องหรือไม่
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>🔍 Test Users Query</h2>";

// Simulate users.php query
$whereConditions = ["1=1"];
$params = [];
$whereClause = implode(' AND ', $whereConditions);

// Get total count
echo "<h3>1. Count Query</h3>";
$countSql = "SELECT COUNT(*) FROM users u WHERE {$whereClause}";
echo "<p>SQL: <code>{$countSql}</code></p>";

try {
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $totalUsers = $stmt->fetchColumn();
    echo "<p style='color:green'>✅ Total Users: <strong>{$totalUsers}</strong></p>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}

// Get users
echo "<h3>2. Select Query</h3>";
$perPage = 20;
$offset = 0;

// Check if extra columns exist
$hasExtraCols = false;
try {
    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'real_name'");
    $hasExtraCols = $stmt->rowCount() > 0;
    echo "<p>Has extra columns (real_name): " . ($hasExtraCols ? 'Yes' : 'No') . "</p>";
} catch (Exception $e) {
    echo "<p>Error checking columns: " . $e->getMessage() . "</p>";
}

$extraCols = $hasExtraCols ? ", u.real_name, u.phone, u.email, u.birthday" : ", NULL as real_name, NULL as phone, NULL as email, NULL as birthday";

$sql = "SELECT u.*{$extraCols},
        (SELECT GROUP_CONCAT(t.name SEPARATOR ', ') FROM user_tags t 
         JOIN user_tag_assignments uta ON t.id = uta.tag_id 
         WHERE uta.user_id = u.id) as tags,
        (SELECT COUNT(*) FROM messages m WHERE m.user_id = u.id) as message_count,
        (SELECT MAX(created_at) FROM messages m WHERE m.user_id = u.id) as last_message_at
        FROM users u 
        WHERE {$whereClause}
        ORDER BY u.created_at DESC
        LIMIT {$perPage} OFFSET {$offset}";

echo "<p>SQL:</p><pre style='background:#f5f5f5;padding:10px;overflow:auto;font-size:12px'>" . htmlspecialchars($sql) . "</pre>";

try {
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p style='color:green'>✅ Found: <strong>" . count($users) . "</strong> users</p>";
    
    if (count($users) > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Display Name</th><th>LINE Account ID</th><th>Blocked</th><th>Tags</th><th>Messages</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>{$user['id']}</td>";
            echo "<td>" . htmlspecialchars($user['display_name'] ?? 'N/A') . "</td>";
            echo "<td>" . ($user['line_account_id'] ?? 'NULL') . "</td>";
            echo "<td>" . ($user['is_blocked'] ? '❌' : '✅') . "</td>";
            echo "<td>" . htmlspecialchars($user['tags'] ?? '-') . "</td>";
            echo "<td>" . ($user['message_count'] ?? 0) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
    
    // Try simple query
    echo "<h3>3. Fallback Simple Query</h3>";
    try {
        $stmt = $db->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 20");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<p style='color:green'>✅ Simple query found: " . count($users) . " users</p>";
        echo "<pre>" . print_r($users, true) . "</pre>";
    } catch (Exception $e2) {
        echo "<p style='color:red'>❌ Simple query also failed: " . $e2->getMessage() . "</p>";
    }
}

// Check user_tags table
echo "<h3>4. Check user_tags table</h3>";
try {
    $stmt = $db->query("SELECT * FROM user_tags LIMIT 5");
    $tags = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<p>Tags found: " . count($tags) . "</p>";
} catch (Exception $e) {
    echo "<p style='color:orange'>⚠️ user_tags table error: " . $e->getMessage() . "</p>";
}

// Check user_tag_assignments table
echo "<h3>5. Check user_tag_assignments table</h3>";
try {
    $stmt = $db->query("SELECT * FROM user_tag_assignments LIMIT 5");
    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<p>Assignments found: " . count($assignments) . "</p>";
} catch (Exception $e) {
    echo "<p style='color:orange'>⚠️ user_tag_assignments table error: " . $e->getMessage() . "</p>";
}

// Check messages table
echo "<h3>6. Check messages table</h3>";
try {
    $stmt = $db->query("SELECT COUNT(*) FROM messages");
    $msgCount = $stmt->fetchColumn();
    echo "<p>Messages count: {$msgCount}</p>";
} catch (Exception $e) {
    echo "<p style='color:orange'>⚠️ messages table error: " . $e->getMessage() . "</p>";
}
?>
