<?php
/**
 * Test User State - Debug Script
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'classes/LineAPI.php';
require_once 'classes/BusinessBot.php';
require_once 'classes/FlexTemplates.php';

$db = Database::getInstance()->getConnection();

echo "<h1>🔧 User State Debug</h1>";
echo "<style>body{font-family:sans-serif;padding:20px;} .ok{color:green;} .error{color:red;} .warn{color:orange;} pre{background:#f5f5f5;padding:10px;border-radius:5px;overflow-x:auto;}</style>";

// 1. ตรวจสอบ structure ของตาราง user_states
echo "<h2>1. Structure ของตาราง user_states</h2>";
try {
    $stmt = $db->query("DESCRIBE user_states");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>{$col['Field']}</td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Key']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "<p class='error'>❌ ตาราง user_states ไม่มี: " . $e->getMessage() . "</p>";
    
    // สร้างตาราง
    echo "<h3>กำลังสร้างตาราง...</h3>";
    try {
        $db->exec("
            CREATE TABLE IF NOT EXISTS user_states (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                state VARCHAR(50) NOT NULL,
                state_data JSON,
                expires_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_state (user_id),
                INDEX idx_state (state),
                INDEX idx_expires (expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "<p class='ok'>✅ สร้างตารางสำเร็จ!</p>";
    } catch (Exception $e2) {
        echo "<p class='error'>❌ สร้างตารางไม่ได้: " . $e2->getMessage() . "</p>";
    }
}

// 2. ทดสอบ set/get state
echo "<h2>2. ทดสอบ Set/Get State</h2>";
try {
    // Get test user - ใช้ user ที่มี state อยู่ก่อน ถ้าไม่มีก็ใช้ user แรก
    $stmt = $db->query("SELECT u.id, u.display_name FROM users u LEFT JOIN user_states us ON u.id = us.user_id ORDER BY us.user_id DESC LIMIT 1");
    $testUser = $stmt->fetch();
    
    if (!$testUser) {
        $stmt = $db->query("SELECT id, display_name FROM users LIMIT 1");
        $testUser = $stmt->fetch();
    }
    
    if ($testUser) {
        echo "<p>👤 Test User: {$testUser['display_name']} (ID: {$testUser['id']})</p>";
        
        // Create mock LINE API
        $line = new LineAPI();
        $bot = new BusinessBot($db, $line, null);
        
        // Test setUserState
        echo "<h3>2.1 Test setUserState</h3>";
        $result = $bot->setUserState($testUser['id'], 'test_state', ['foo' => 'bar', 'test' => true]);
        echo "<p>setUserState result: " . ($result ? '<span class="ok">✅ Success</span>' : '<span class="error">❌ Failed</span>') . "</p>";
        
        // Test getUserState
        echo "<h3>2.2 Test getUserState</h3>";
        $state = $bot->getUserState($testUser['id']);
        if ($state) {
            echo "<p class='ok'>✅ State found:</p>";
            echo "<pre>" . print_r($state, true) . "</pre>";
        } else {
            echo "<p class='error'>❌ State not found!</p>";
        }
        
        // Check directly in database
        echo "<h3>2.3 Direct Database Check</h3>";
        $stmt = $db->prepare("SELECT * FROM user_states WHERE user_id = ?");
        $stmt->execute([$testUser['id']]);
        $dbState = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($dbState) {
            echo "<p class='ok'>✅ State in database:</p>";
            echo "<pre>" . print_r($dbState, true) . "</pre>";
        } else {
            echo "<p class='error'>❌ State not in database!</p>";
        }
        
        // Test clearUserState
        echo "<h3>2.4 Test clearUserState</h3>";
        $bot->clearUserState($testUser['id']);
        $stateAfterClear = $bot->getUserState($testUser['id']);
        echo "<p>State after clear: " . ($stateAfterClear ? '<span class="error">❌ Still exists</span>' : '<span class="ok">✅ Cleared</span>') . "</p>";
        
    } else {
        echo "<p class='error'>❌ ไม่มี user ในระบบ</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

// 3. ดู dev_logs ล่าสุด
echo "<h2>3. Dev Logs ล่าสุด (BusinessBot)</h2>";
try {
    $stmt = $db->query("SELECT * FROM dev_logs WHERE source LIKE 'BusinessBot%' ORDER BY id DESC LIMIT 20");
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($logs)) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Type</th><th>Source</th><th>Message</th><th>Data</th><th>Time</th></tr>";
        foreach ($logs as $log) {
            echo "<tr>";
            echo "<td>{$log['id']}</td>";
            echo "<td>{$log['log_type']}</td>";
            echo "<td>{$log['source']}</td>";
            echo "<td>" . htmlspecialchars($log['message']) . "</td>";
            echo "<td><pre style='max-width:300px;overflow:auto;'>" . htmlspecialchars($log['data'] ?? '') . "</pre></td>";
            echo "<td>{$log['created_at']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>ไม่มี logs</p>";
    }
} catch (Exception $e) {
    echo "<p class='warn'>⚠️ ไม่สามารถอ่าน dev_logs: " . $e->getMessage() . "</p>";
}

// 4. ดู user_states ทั้งหมด
echo "<h2>4. User States ทั้งหมด</h2>";
try {
    $stmt = $db->query("SELECT us.*, u.display_name FROM user_states us LEFT JOIN users u ON us.user_id = u.id");
    $states = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($states)) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>User</th><th>State</th><th>Data</th><th>Expires</th></tr>";
        foreach ($states as $s) {
            $expired = $s['expires_at'] && strtotime($s['expires_at']) < time();
            echo "<tr style='" . ($expired ? 'opacity:0.5;' : '') . "'>";
            echo "<td>" . ($s['display_name'] ?? 'Unknown') . " (ID: {$s['user_id']})</td>";
            echo "<td>{$s['state']}</td>";
            echo "<td><pre style='max-width:200px;overflow:auto;'>" . htmlspecialchars($s['state_data'] ?? '{}') . "</pre></td>";
            echo "<td>" . ($s['expires_at'] ?? 'N/A') . ($expired ? ' <span class="error">(expired)</span>' : '') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>ไม่มี user states</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// 5. ค้นหา user จาก LINE User ID
echo "<h2>5. ค้นหา User จาก LINE User ID</h2>";
$searchLineUserId = $_GET['line_user_id'] ?? '';
if ($searchLineUserId) {
    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE line_user_id = ?");
        $stmt->execute([$searchLineUserId]);
        $foundUser = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($foundUser) {
            echo "<p class='ok'>✅ พบ User:</p>";
            echo "<pre>" . print_r($foundUser, true) . "</pre>";
            
            // Check state for this user
            $stmt = $db->prepare("SELECT * FROM user_states WHERE user_id = ?");
            $stmt->execute([$foundUser['id']]);
            $userState = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($userState) {
                echo "<p class='ok'>✅ User มี state:</p>";
                echo "<pre>" . print_r($userState, true) . "</pre>";
            } else {
                echo "<p class='warn'>⚠️ User ไม่มี state</p>";
            }
        } else {
            echo "<p class='error'>❌ ไม่พบ User</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
    }
}
echo "<form method='get'>";
echo "<input type='text' name='line_user_id' placeholder='LINE User ID (U...)' value='" . htmlspecialchars($searchLineUserId) . "' style='width:300px;padding:5px;'>";
echo "<button type='submit'>ค้นหา</button>";
echo "</form>";

echo "<hr>";
echo "<p><a href='test_checkout.php'>← กลับไปหน้า Test Checkout</a></p>";
