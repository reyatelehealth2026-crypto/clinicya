<?php
/**
 * Test CNY API Direct - ทดสอบ API โดยตรง (Stream to file)
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 300);
ini_set('memory_limit', '64M'); // ใช้น้อยเพราะ stream ไปไฟล์

header('Content-Type: text/html; charset=utf-8');
echo "<!DOCTYPE html><html><head><meta charset='utf-8'></head><body>";
echo "<h2>🔍 Test CNY API Direct (Stream)</h2><pre>";

$apiUrl = 'https://manager.cnypharmacy.com/api/get_product_all';
$token = '90xcKekelCqCAjmgkpI1saJF6N55eiNexcI4hdcYM2M';
$tempFile = sys_get_temp_dir() . '/cny_test_' . time() . '.json';

echo "API URL: {$apiUrl}\n";
echo "Token: " . substr($token, 0, 10) . "...\n";
echo "Temp File: {$tempFile}\n\n";

echo "=== Downloading to file (streaming) ===\n";
flush();

// Stream to file to avoid memory issues
$fp = fopen($tempFile, 'w');
if (!$fp) {
    die("Cannot create temp file");
}

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_FILE => $fp, // Stream to file
    CURLOPT_TIMEOUT => 300,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $token,
        'Accept: application/json'
    ]
]);

curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);
fclose($fp);

$fileSize = filesize($tempFile);
echo "HTTP Code: {$httpCode}\n";
echo "cURL Error: " . ($error ?: 'None') . "\n";
echo "File Size: " . number_format($fileSize) . " bytes (" . round($fileSize/1024/1024, 2) . " MB)\n\n";

if ($httpCode == 200 && $fileSize > 0) {
    // Read first 2000 bytes to check format
    $sample = file_get_contents($tempFile, false, null, 0, 2000);
    
    if (strpos($sample, '[{') === 0 || strpos($sample, '[') === 0) {
        echo "<strong style='color:green'>✅ API OK - Response is JSON array</strong>\n\n";
        
        // Count products using grep (memory efficient)
        $content = file_get_contents($tempFile);
        preg_match_all('/"sku"\s*:\s*"([^"]+)"/', $content, $matches);
        $productCount = count($matches[1]);
        unset($content);
        
        echo "Estimated products: ~{$productCount}\n\n";
        
        // Show first product sample
        echo "Sample (first 500 chars):\n";
        echo htmlspecialchars(substr($sample, 0, 500)) . "...\n";
        
        echo "\n<strong style='color:green'>✅ CNY API ทำงานปกติ!</strong>\n";
        echo "ปัญหาคือ memory limit ของ hosting (~128MB) ไม่พอสำหรับข้อมูล ~" . round($fileSize/1024/1024) . "MB\n\n";
        echo "<strong>วิธีแก้ไข:</strong>\n";
        echo "1. ใช้ import จาก CSV แทน: <a href='shop/import-products.php'>Import Products</a>\n";
        echo "2. หรือติดต่อ hosting เพิ่ม memory_limit\n";
    } else {
        echo "<strong style='color:orange'>⚠️ Response is not JSON</strong>\n";
        echo "First 1000 chars:\n";
        echo htmlspecialchars(substr($sample, 0, 1000));
    }
} else {
    echo "<strong style='color:red'>❌ API Error</strong>\n";
    $sample = file_get_contents($tempFile, false, null, 0, 1000);
    echo "Response:\n";
    echo htmlspecialchars($sample);
}

// Cleanup
@unlink($tempFile);

echo "</pre></body></html>";
?>
