<?php
/**
 * Test Login Flow
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Test Login Flow</h1>";
echo "<style>body{font-family:sans-serif;padding:20px;max-width:600px;margin:0 auto;} .ok{color:green;} .error{color:red;} .warning{color:orange;} pre{background:#f5f5f5;padding:15px;border-radius:5px;overflow:auto;}</style>";

// Step 1: Start session
echo "<h2>1. Start Session</h2>";
if (session_status() === PHP_SESSION_NONE) {
    session_start();
    echo "<p class='ok'>✅ Session started</p>";
} else {
    echo "<p class='ok'>✅ Session already active</p>";
}

// Step 2: Load config and database
echo "<h2>2. Load Config & Database</h2>";
try {
    require_once 'config/config.php';
    require_once 'config/database.php';
    $db = Database::getInstance()->getConnection();
    echo "<p class='ok'>✅ Database connected</p>";
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
    exit;
}

// Step 3: Load AdminAuth
echo "<h2>3. Load AdminAuth</h2>";
try {
    require_once 'classes/AdminAuth.php';
    $auth = new AdminAuth($db);
    echo "<p class='ok'>✅ AdminAuth loaded</p>";
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
    exit;
}

// Step 4: Get admin user
echo "<h2>4. Get Admin User</h2>";
$stmt = $db->query("SELECT id, username, password FROM admin_users WHERE username = 'jameyannakon' LIMIT 1");
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "<p class='error'>❌ User 'jameyannakon' not found</p>";
    exit;
}

echo "<p class='ok'>✅ User found: " . htmlspecialchars($user['username']) . "</p>";

// Step 5: Test password
echo "<h2>5. Test Password</h2>";
$testPassword = 'password';
if (password_verify($testPassword, $user['password'])) {
    echo "<p class='ok'>✅ Password 'password' is correct</p>";
} else {
    echo "<p class='error'>❌ Password 'password' is incorrect</p>";
    echo "<p>Trying to reset password...</p>";
    
    $newHash = password_hash('password', PASSWORD_DEFAULT);
    $stmt = $db->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
    $stmt->execute([$newHash, $user['id']]);
    echo "<p class='ok'>✅ Password reset to 'password'</p>";
}

// Step 6: Test login
echo "<h2>6. Test Login via AdminAuth</h2>";
$result = $auth->login('jameyannakon', 'password');

if ($result['success']) {
    echo "<p class='ok'>✅ Login successful</p>";
    echo "<p>User data:</p>";
    echo "<pre>";
    print_r($result['user']);
    echo "</pre>";
} else {
    echo "<p class='error'>❌ Login failed: " . $result['message'] . "</p>";
    exit;
}

// Step 7: Check session
echo "<h2>7. Check Session After Login</h2>";
echo "<p>Session data:</p>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

if (isset($_SESSION['admin_user'])) {
    echo "<p class='ok'>✅ admin_user in session</p>";
} else {
    echo "<p class='error'>❌ admin_user NOT in session</p>";
}

// Step 8: Test isLoggedIn
echo "<h2>8. Test isLoggedIn()</h2>";
if ($auth->isLoggedIn()) {
    echo "<p class='ok'>✅ isLoggedIn() returns true</p>";
} else {
    echo "<p class='error'>❌ isLoggedIn() returns false</p>";
}

echo "<hr>";
echo "<p><a href='index.php'>Go to Dashboard</a> | <a href='auth/login.php'>Go to Login</a></p>";
