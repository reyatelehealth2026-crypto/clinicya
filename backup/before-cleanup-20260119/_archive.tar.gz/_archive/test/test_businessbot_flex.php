<?php
/**
 * BusinessBot Flex Message Test
 * ตรวจสอบ Flex ที่ BusinessBot สร้าง
 */

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'classes/LineAPI.php';
require_once 'classes/FlexTemplates.php';
require_once 'classes/BusinessBot.php';

echo "=== BUSINESSBOT FLEX TEST ===\n\n";

$db = Database::getInstance()->getConnection();

// Mock LineAPI that captures messages
class MockLineAPI {
    public $lastReply = null;
    public $lastError = null;
    
    public function replyMessage($token, $messages) {
        $this->lastReply = $messages;
        
        // Validate each message
        foreach ((array)$messages as $i => $msg) {
            if (!is_array($msg)) {
                $this->lastError = "Message {$i} is not an array";
                return false;
            }
            
            if (!isset($msg['type'])) {
                $this->lastError = "Message {$i} missing 'type'";
                return false;
            }
            
            if ($msg['type'] === 'flex') {
                if (!isset($msg['contents'])) {
                    $this->lastError = "Flex message {$i} missing 'contents'";
                    return false;
                }
                if (!isset($msg['altText'])) {
                    $this->lastError = "Flex message {$i} missing 'altText'";
                    return false;
                }
                
                // Check for null values in contents
                $nullCheck = checkForNulls($msg['contents'], "contents");
                if ($nullCheck) {
                    $this->lastError = "Flex message {$i}: {$nullCheck}";
                    return false;
                }
            }
        }
        
        return true;
    }
    
    public function getProfile($userId) {
        return ['displayName' => 'Test User', 'pictureUrl' => null];
    }
}

function checkForNulls($data, $path) {
    if (!is_array($data)) return null;
    
    foreach ($data as $key => $value) {
        $currentPath = "{$path}.{$key}";
        
        if ($value === null && in_array($key, ['hero', 'header', 'footer'])) {
            return "{$currentPath} is null (should be removed)";
        }
        
        if (is_array($value)) {
            $result = checkForNulls($value, $currentPath);
            if ($result) return $result;
        }
    }
    
    return null;
}

$line = new MockLineAPI();
$bot = new BusinessBot($db, $line, null);

$passed = 0;
$failed = 0;

function testCommand($bot, $line, $command, $description) {
    global $passed, $failed;
    
    $line->lastReply = null;
    $line->lastError = null;
    
    try {
        $result = $bot->processMessage('test_user', 1, $command, 'test_token');
        
        if ($line->lastError) {
            echo "  ❌ {$description} ('{$command}')\n";
            echo "     Error: {$line->lastError}\n";
            $failed++;
            return false;
        }
        
        if ($result === true || $result === null) {
            echo "  ✅ {$description} ('{$command}')\n";
            $passed++;
            return true;
        }
        
        echo "  ⚠️ {$description} ('{$command}') - returned: " . var_export($result, true) . "\n";
        $passed++;
        return true;
        
    } catch (Exception $e) {
        echo "  ❌ {$description} ('{$command}')\n";
        echo "     Exception: " . $e->getMessage() . "\n";
        echo "     File: " . $e->getFile() . ":" . $e->getLine() . "\n";
        $failed++;
        return false;
    }
}

echo "📋 Testing BusinessBot commands:\n\n";

// Test basic commands
testCommand($bot, $line, 'menu', 'Main Menu');
testCommand($bot, $line, 'เมนู', 'Main Menu (Thai)');
testCommand($bot, $line, 'shop', 'Shop/Categories');
testCommand($bot, $line, 'สินค้า', 'Shop (Thai)');
testCommand($bot, $line, 'cart', 'Cart');
testCommand($bot, $line, 'ตะกร้า', 'Cart (Thai)');
testCommand($bot, $line, 'orders', 'Orders');
testCommand($bot, $line, 'คำสั่งซื้อ', 'Orders (Thai)');
testCommand($bot, $line, 'contact', 'Contact');
testCommand($bot, $line, 'ติดต่อ', 'Contact (Thai)');

// Test pattern commands
testCommand($bot, $line, 'add 1', 'Add to cart');
testCommand($bot, $line, 'เพิ่ม 1', 'Add to cart (Thai)');
testCommand($bot, $line, 'item 1', 'View item');
testCommand($bot, $line, 'หมวด 1', 'View category');
testCommand($bot, $line, 'ค้นหา test', 'Search');

// Test unknown command (should return null)
echo "\n📋 Testing unknown command:\n";
$line->lastReply = null;
$result = $bot->processMessage('test_user', 1, 'random message xyz', 'test_token');
if ($result === null) {
    echo "  ✅ Unknown command returns null (correct)\n";
    $passed++;
} else {
    echo "  ⚠️ Unknown command returned: " . var_export($result, true) . "\n";
}

// Summary
echo "\n" . str_repeat("=", 50) . "\n";
echo "📊 SUMMARY\n";
echo str_repeat("=", 50) . "\n";
echo "✅ Passed: {$passed}\n";
echo "❌ Failed: {$failed}\n";

if ($failed > 0) {
    echo "\n⚠️ Some commands failed - check the errors above!\n";
} else {
    echo "\n✅ All BusinessBot commands work correctly!\n";
}

echo "\n";
