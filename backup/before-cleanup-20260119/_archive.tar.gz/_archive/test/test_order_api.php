<?php
/**
 * Test Order API for dispense checkout
 */
header('Content-Type: text/html; charset=utf-8');
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>🔍 Test Order API</h2>";

// Get latest dispense transaction
$stmt = $db->query("SELECT * FROM transactions WHERE transaction_type = 'dispense' ORDER BY id DESC LIMIT 1");
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    echo "<p style='color:red'>❌ ไม่พบ transaction type=dispense</p>";
    
    // Show all transactions
    echo "<h3>All Transactions:</h3>";
    $stmt = $db->query("SELECT id, order_number, transaction_type, status, payment_status, grand_total FROM transactions ORDER BY id DESC LIMIT 10");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<pre>" . print_r($rows, true) . "</pre>";
    exit;
}

echo "<h3>✅ Found Dispense Order:</h3>";
echo "<pre>" . print_r($order, true) . "</pre>";

// Get transaction items
$stmt = $db->prepare("SELECT * FROM transaction_items WHERE transaction_id = ?");
$stmt->execute([$order['id']]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>📦 Transaction Items:</h3>";
echo "<pre>" . print_r($items, true) . "</pre>";

// Test API call
echo "<h3>🔗 Test API Call:</h3>";
$apiUrl = "api/checkout.php?action=order&order_id=" . $order['id'];
echo "<p>URL: <a href='$apiUrl' target='_blank'>$apiUrl</a></p>";

// Make internal call
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://localhost/v1/" . $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

echo "<h3>📋 API Response:</h3>";
echo "<pre>" . htmlspecialchars($response) . "</pre>";

// Test LIFF checkout URL
$userId = 'U1234567890'; // dummy
$checkoutUrl = "liff-checkout.php?order={$order['id']}&action=payment&user={$userId}";
echo "<h3>🔗 LIFF Checkout URL:</h3>";
echo "<p><a href='$checkoutUrl' target='_blank'>$checkoutUrl</a></p>";
