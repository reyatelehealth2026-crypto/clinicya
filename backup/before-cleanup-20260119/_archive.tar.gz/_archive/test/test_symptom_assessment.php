<?php
/**
 * Test Symptom Assessment API
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

use Modules\Core\Database;

echo "<h2>🩺 Test Symptom Assessment API</h2>";

// Test data
$testData = [
    'gender' => 'ชาย',
    'age' => 35,
    'weight' => 70,
    'symptoms' => ['ปวดหัว', 'ไข้'],
    'otherSymptoms' => 'รู้สึกอ่อนเพลีย',
    'severity' => 6,
    'duration' => '2-3 วัน',
    'conditions' => [],
    'allergies' => '',
    'medications' => '',
    'userId' => null,
    'lineUserId' => 'test_user_123'
];

echo "<h3>📋 Test Data:</h3>";
echo "<pre>" . json_encode($testData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";

// Call API
$apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/api/symptom-assessment.php';
echo "<p>API URL: {$apiUrl}</p>";

$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode($testData),
    CURLOPT_TIMEOUT => 60
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "<h3>📡 Response (HTTP {$httpCode}):</h3>";

if ($error) {
    echo "<p style='color:red'>cURL Error: {$error}</p>";
} else {
    $result = json_decode($response, true);
    echo "<pre>" . json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
    
    if (isset($result['success']) && $result['success']) {
        echo "<p style='color:green'>✅ API ทำงานปกติ!</p>";
        
        echo "<h4>ผลการวิเคราะห์:</h4>";
        echo "<p><strong>ระดับความเสี่ยง:</strong> " . ($result['riskLevel'] ?? '-') . "</p>";
        echo "<p><strong>การวิเคราะห์:</strong> " . ($result['analysis'] ?? '-') . "</p>";
        echo "<p><strong>คำแนะนำ:</strong> " . ($result['recommendation'] ?? '-') . "</p>";
        
        if (!empty($result['references'])) {
            echo "<h4>แหล่งอ้างอิง:</h4><ul>";
            foreach ($result['references'] as $ref) {
                echo "<li><strong>{$ref['title']}</strong> - {$ref['source']}</li>";
            }
            echo "</ul>";
        }
        
        if (!empty($result['medications'])) {
            echo "<h4>ยาที่แนะนำ:</h4><ul>";
            foreach ($result['medications'] as $med) {
                echo "<li>{$med['name']} - ฿{$med['price']}</li>";
            }
            echo "</ul>";
        }
    } else {
        echo "<p style='color:red'>❌ Error: " . ($result['error'] ?? 'Unknown') . "</p>";
    }
}

// Check database
echo "<h3>📊 ตรวจสอบฐานข้อมูล:</h3>";
try {
    $db = Database::getInstance()->getConnection();
    
    // Check table exists
    $stmt = $db->query("SHOW TABLES LIKE 'symptom_assessments'");
    if ($stmt->rowCount() > 0) {
        echo "<p style='color:green'>✅ ตาราง symptom_assessments มีอยู่</p>";
        
        // Count records
        $stmt = $db->query("SELECT COUNT(*) FROM symptom_assessments");
        $count = $stmt->fetchColumn();
        echo "<p>จำนวน records: {$count}</p>";
        
        // Show latest
        if ($count > 0) {
            $stmt = $db->query("SELECT * FROM symptom_assessments ORDER BY id DESC LIMIT 1");
            $latest = $stmt->fetch(PDO::FETCH_ASSOC);
            echo "<h4>Record ล่าสุด:</h4>";
            echo "<pre>" . json_encode($latest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
        }
    } else {
        echo "<p style='color:orange'>⚠️ ตาราง symptom_assessments ยังไม่มี - กรุณารัน migration</p>";
        echo "<p><a href='run_symptom_assessment_migration.php'>รัน Migration</a></p>";
    }
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Database Error: " . $e->getMessage() . "</p>";
}
