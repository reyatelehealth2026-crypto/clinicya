<?php
/**
 * Test Sync Products - ทดสอบดึงข้อมูลสินค้าล่าสุดจาก CNY API
 * แสดงข้อมูลที่ได้รับมาทั้งหมด
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'classes/CnyPharmacyAPI.php';

$db = Database::getInstance()->getConnection();
$api = new CnyPharmacyAPI($db);

// Action
$action = $_GET['action'] ?? 'info';
$sku = $_GET['sku'] ?? '';
$limit = (int)($_GET['limit'] ?? 5);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Sync Products - CNY API</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        pre { white-space: pre-wrap; word-wrap: break-word; }
        .json-key { color: #881391; }
        .json-string { color: #1a1aa6; }
        .json-number { color: #1c6b48; }
    </style>
</head>
<body class="bg-gray-100 min-h-screen p-4">
    <div class="max-w-6xl mx-auto">
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h1 class="text-2xl font-bold text-gray-800 mb-2">
                <i class="fas fa-sync text-blue-500 mr-2"></i>Test Sync Products - CNY API
            </h1>
            <p class="text-gray-500">ทดสอบดึงข้อมูลสินค้าจาก CNY Pharmacy API</p>
        </div>

        <!-- Actions -->
        <div class="bg-white rounded-xl shadow p-4 mb-6">
            <div class="flex flex-wrap gap-2">
                <a href="?action=info" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 <?= $action == 'info' ? 'ring-2 ring-blue-300' : '' ?>">
                    <i class="fas fa-info-circle mr-1"></i> API Info
                </a>
                <a href="?action=sku_list" class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 <?= $action == 'sku_list' ? 'ring-2 ring-green-300' : '' ?>">
                    <i class="fas fa-list mr-1"></i> SKU List
                </a>
                <a href="?action=sample" class="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 <?= $action == 'sample' ? 'ring-2 ring-purple-300' : '' ?>">
                    <i class="fas fa-box mr-1"></i> Sample Products
                </a>
                <a href="?action=all_fields" class="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 <?= $action == 'all_fields' ? 'ring-2 ring-orange-300' : '' ?>">
                    <i class="fas fa-database mr-1"></i> All Fields
                </a>
                <a href="?action=categories" class="px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 <?= $action == 'categories' ? 'ring-2 ring-pink-300' : '' ?>">
                    <i class="fas fa-folder mr-1"></i> Categories
                </a>
            </div>
            
            <!-- Search by SKU -->
            <form method="GET" class="mt-4 flex gap-2">
                <input type="hidden" name="action" value="search">
                <input type="text" name="sku" value="<?= htmlspecialchars($sku) ?>" 
                       placeholder="ค้นหาด้วย SKU..." 
                       class="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                <button type="submit" class="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-900">
                    <i class="fas fa-search mr-1"></i> ค้นหา
                </button>
            </form>
        </div>

        <!-- Results -->
        <div class="bg-white rounded-xl shadow p-6">
<?php
$startTime = microtime(true);

switch ($action) {
    case 'info':
        echo '<h2 class="text-xl font-bold mb-4"><i class="fas fa-info-circle text-blue-500 mr-2"></i>API Information</h2>';
        
        echo '<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">';
        echo '<div class="p-4 bg-blue-50 rounded-lg">';
        echo '<p class="text-sm text-gray-500">Base URL</p>';
        echo '<p class="font-mono text-blue-700">https://manager.cnypharmacy.com/api</p>';
        echo '</div>';
        echo '<div class="p-4 bg-green-50 rounded-lg">';
        echo '<p class="text-sm text-gray-500">Endpoints</p>';
        echo '<p class="font-mono text-green-700">/get_product_all, /get_product_sku/{sku}</p>';
        echo '</div>';
        echo '</div>';
        
        // Test connection
        echo '<h3 class="font-bold mb-2">🔗 ทดสอบการเชื่อมต่อ</h3>';
        $result = $api->getSkuList();
        if ($result['success']) {
            $count = count($result['data'] ?? []);
            echo '<div class="p-4 bg-green-100 text-green-700 rounded-lg">';
            echo '<i class="fas fa-check-circle mr-2"></i>เชื่อมต่อสำเร็จ! พบสินค้า ' . number_format($count) . ' รายการ';
            if ($result['cached'] ?? false) {
                echo ' <span class="text-xs bg-yellow-200 px-2 py-1 rounded">cached</span>';
            }
            echo '</div>';
        } else {
            echo '<div class="p-4 bg-red-100 text-red-700 rounded-lg">';
            echo '<i class="fas fa-times-circle mr-2"></i>เชื่อมต่อไม่สำเร็จ: ' . ($result['error'] ?? 'Unknown error');
            echo '</div>';
        }
        break;

    case 'sku_list':
        echo '<h2 class="text-xl font-bold mb-4"><i class="fas fa-list text-green-500 mr-2"></i>รายการ SKU ทั้งหมด</h2>';
        
        $result = $api->getSkuList();
        if ($result['success']) {
            $skus = $result['data'] ?? [];
            echo '<p class="mb-4 text-gray-600">พบ SKU ทั้งหมด <strong>' . number_format(count($skus)) . '</strong> รายการ</p>';
            
            // Show first 50
            echo '<div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-2 max-h-96 overflow-y-auto">';
            foreach (array_slice($skus, 0, 50) as $s) {
                echo '<a href="?action=search&sku=' . urlencode($s) . '" class="px-3 py-2 bg-gray-100 rounded hover:bg-blue-100 text-sm font-mono">' . htmlspecialchars($s) . '</a>';
            }
            echo '</div>';
            if (count($skus) > 50) {
                echo '<p class="mt-4 text-gray-500 text-sm">แสดง 50 รายการแรก จากทั้งหมด ' . count($skus) . ' รายการ</p>';
            }
        } else {
            echo '<div class="p-4 bg-red-100 text-red-700 rounded-lg">' . ($result['error'] ?? 'Error') . '</div>';
        }
        break;

    case 'sample':
        echo '<h2 class="text-xl font-bold mb-4"><i class="fas fa-box text-purple-500 mr-2"></i>ตัวอย่างสินค้า ' . $limit . ' รายการ</h2>';
        
        $result = $api->getAllProductsCached();
        if ($result['success']) {
            $products = array_slice($result['data'] ?? [], 0, $limit);
            
            foreach ($products as $i => $product) {
                echo '<div class="mb-6 p-4 border rounded-lg">';
                echo '<div class="flex gap-4">';
                
                // Image
                if (!empty($product['photo_path'])) {
                    echo '<img src="' . htmlspecialchars($product['photo_path']) . '" class="w-24 h-24 object-cover rounded-lg" onerror="this.src=\'https://via.placeholder.com/100\'">';
                }
                
                echo '<div class="flex-1">';
                echo '<h3 class="font-bold text-lg">' . htmlspecialchars($product['name'] ?? 'N/A') . '</h3>';
                echo '<p class="text-sm text-gray-500">' . htmlspecialchars($product['name_en'] ?? '') . '</p>';
                echo '<div class="mt-2 flex flex-wrap gap-2">';
                echo '<span class="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">SKU: ' . htmlspecialchars($product['sku'] ?? 'N/A') . '</span>';
                echo '<span class="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">ID: ' . ($product['id'] ?? 'N/A') . '</span>';
                echo '<span class="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs">Stock: ' . ($product['qty'] ?? 0) . '</span>';
                if (!empty($product['category'])) {
                    echo '<span class="px-2 py-1 bg-orange-100 text-orange-700 rounded text-xs">' . htmlspecialchars($product['category']) . '</span>';
                }
                echo '</div>';
                
                // Prices
                if (!empty($product['product_price'])) {
                    echo '<div class="mt-2">';
                    foreach (array_slice($product['product_price'], 0, 3) as $price) {
                        echo '<span class="mr-2 text-sm">' . htmlspecialchars($price['customer_group'] ?? '') . ': <strong class="text-green-600">฿' . number_format($price['price'] ?? 0, 2) . '</strong></span>';
                    }
                    echo '</div>';
                }
                echo '</div></div></div>';
            }
        } else {
            echo '<div class="p-4 bg-red-100 text-red-700 rounded-lg">' . ($result['error'] ?? 'Error') . '</div>';
        }
        break;

    case 'all_fields':
        echo '<h2 class="text-xl font-bold mb-4"><i class="fas fa-database text-orange-500 mr-2"></i>โครงสร้างข้อมูลทั้งหมด (Fields)</h2>';
        
        $result = $api->getAllProductsCached();
        if ($result['success'] && !empty($result['data'])) {
            $sample = $result['data'][0];
            
            echo '<p class="mb-4 text-gray-600">แสดง Fields ทั้งหมดจากสินค้าตัวอย่าง</p>';
            
            echo '<div class="overflow-x-auto">';
            echo '<table class="w-full text-sm">';
            echo '<thead class="bg-gray-100"><tr><th class="p-2 text-left">Field</th><th class="p-2 text-left">Type</th><th class="p-2 text-left">Value (Sample)</th></tr></thead>';
            echo '<tbody>';
            
            foreach ($sample as $key => $value) {
                $type = gettype($value);
                $displayValue = '';
                
                if (is_array($value)) {
                    $displayValue = '<pre class="text-xs bg-gray-50 p-2 rounded max-h-32 overflow-auto">' . htmlspecialchars(json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) . '</pre>';
                } elseif (is_string($value) && strlen($value) > 100) {
                    $displayValue = '<span class="text-gray-600">' . htmlspecialchars(substr($value, 0, 100)) . '...</span>';
                } else {
                    $displayValue = '<span class="font-mono">' . htmlspecialchars((string)$value) . '</span>';
                }
                
                echo '<tr class="border-b hover:bg-gray-50">';
                echo '<td class="p-2 font-mono text-blue-600">' . htmlspecialchars($key) . '</td>';
                echo '<td class="p-2"><span class="px-2 py-1 bg-gray-200 rounded text-xs">' . $type . '</span></td>';
                echo '<td class="p-2">' . $displayValue . '</td>';
                echo '</tr>';
            }
            
            echo '</tbody></table></div>';
        } else {
            echo '<div class="p-4 bg-red-100 text-red-700 rounded-lg">' . ($result['error'] ?? 'Error') . '</div>';
        }
        break;

    case 'categories':
        echo '<h2 class="text-xl font-bold mb-4"><i class="fas fa-folder text-pink-500 mr-2"></i>หมวดหมู่สินค้าจาก CNY</h2>';
        
        $result = $api->getAllProductsCached();
        if ($result['success']) {
            $categories = [];
            foreach ($result['data'] ?? [] as $product) {
                $cat = $product['category'] ?? 'ไม่ระบุ';
                if (!isset($categories[$cat])) {
                    $categories[$cat] = 0;
                }
                $categories[$cat]++;
            }
            arsort($categories);
            
            echo '<p class="mb-4 text-gray-600">พบหมวดหมู่ทั้งหมด <strong>' . count($categories) . '</strong> หมวดหมู่</p>';
            
            echo '<div class="grid grid-cols-1 md:grid-cols-2 gap-2">';
            foreach ($categories as $cat => $count) {
                echo '<div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">';
                echo '<span class="font-medium">' . htmlspecialchars($cat) . '</span>';
                echo '<span class="px-3 py-1 bg-pink-100 text-pink-700 rounded-full text-sm">' . $count . ' สินค้า</span>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo '<div class="p-4 bg-red-100 text-red-700 rounded-lg">' . ($result['error'] ?? 'Error') . '</div>';
        }
        break;

    case 'search':
        if (empty($sku)) {
            echo '<div class="p-4 bg-yellow-100 text-yellow-700 rounded-lg">กรุณาระบุ SKU</div>';
            break;
        }
        
        echo '<h2 class="text-xl font-bold mb-4"><i class="fas fa-search text-gray-500 mr-2"></i>ผลการค้นหา: ' . htmlspecialchars($sku) . '</h2>';
        
        // Try direct API first
        $result = $api->getProductBySku($sku);
        
        if ($result['success'] && !empty($result['data'])) {
            $product = $result['data'];
            
            echo '<div class="mb-4 p-4 bg-green-50 rounded-lg">';
            echo '<i class="fas fa-check-circle text-green-500 mr-2"></i>พบสินค้า!';
            echo '</div>';
            
            // Product Card
            echo '<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">';
            
            // Left: Image & Basic Info
            echo '<div class="p-4 border rounded-lg">';
            if (!empty($product['photo_path'])) {
                echo '<img src="' . htmlspecialchars($product['photo_path']) . '" class="w-full max-w-xs mx-auto rounded-lg mb-4" onerror="this.src=\'https://via.placeholder.com/300\'">';
            }
            echo '<h3 class="text-xl font-bold">' . htmlspecialchars($product['name'] ?? 'N/A') . '</h3>';
            echo '<p class="text-gray-500">' . htmlspecialchars($product['name_en'] ?? '') . '</p>';
            
            // Prices
            if (!empty($product['product_price'])) {
                echo '<div class="mt-4 p-3 bg-gray-50 rounded-lg">';
                echo '<h4 class="font-bold mb-2">💰 ราคา</h4>';
                foreach ($product['product_price'] as $price) {
                    echo '<div class="flex justify-between py-1 border-b last:border-0">';
                    echo '<span>' . htmlspecialchars($price['customer_group'] ?? '') . '</span>';
                    echo '<span class="font-bold text-green-600">฿' . number_format($price['price'] ?? 0, 2) . ' / ' . htmlspecialchars($price['unit'] ?? 'ชิ้น') . '</span>';
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</div>';
            
            // Right: Full JSON
            echo '<div class="p-4 border rounded-lg">';
            echo '<h4 class="font-bold mb-2">📋 ข้อมูลทั้งหมด (JSON)</h4>';
            echo '<pre class="text-xs bg-gray-900 text-green-400 p-4 rounded-lg overflow-auto max-h-96">';
            echo htmlspecialchars(json_encode($product, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            echo '</pre>';
            echo '</div>';
            
            echo '</div>';
        } else {
            echo '<div class="p-4 bg-red-100 text-red-700 rounded-lg">';
            echo '<i class="fas fa-times-circle mr-2"></i>ไม่พบสินค้า SKU: ' . htmlspecialchars($sku);
            if (!empty($result['error'])) {
                echo '<br><small>' . htmlspecialchars($result['error']) . '</small>';
            }
            echo '</div>';
        }
        break;

    default:
        echo '<div class="p-4 bg-gray-100 rounded-lg">เลือก Action ด้านบน</div>';
}

$endTime = microtime(true);
$duration = round(($endTime - $startTime) * 1000, 2);
?>
        </div>

        <!-- Footer -->
        <div class="mt-6 text-center text-gray-500 text-sm">
            <p>⏱️ ใช้เวลา: <?= $duration ?> ms</p>
            <p class="mt-2">
                <a href="sync-dashboard" class="text-blue-500 hover:underline">← กลับ Sync Dashboard</a>
            </p>
        </div>
    </div>
</body>
</html>
