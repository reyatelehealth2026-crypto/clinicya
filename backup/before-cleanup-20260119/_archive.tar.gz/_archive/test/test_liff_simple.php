<?php
/**
 * Simple LIFF Test - ทดสอบว่า PHP ดึง LIFF ID ได้หรือไม่
 */
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

// Same query as liff-checkout.php
$liffId = '';
$lineAccountId = 1;
try {
    $stmt = $db->query("SELECT id, liff_id FROM line_accounts WHERE liff_id IS NOT NULL AND liff_id != '' ORDER BY is_default DESC, id ASC LIMIT 1");
    $row = $stmt->fetch();
    if ($row) {
        $liffId = $row['liff_id'];
        $lineAccountId = $row['id'];
    }
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>LIFF Test</title>
    <script src="https://static.line-scdn.net/liff/edge/2/sdk.js"></script>
</head>
<body>
    <h2>LIFF Test</h2>
    
    <h3>PHP Side:</h3>
    <p>Account ID: <strong><?= $lineAccountId ?></strong></p>
    <p>LIFF ID: <strong style="color:<?= $liffId ? 'green' : 'red' ?>"><?= $liffId ?: 'EMPTY' ?></strong></p>
    
    <?php if (isset($error)): ?>
    <p style="color:red">Error: <?= $error ?></p>
    <?php endif; ?>
    
    <h3>JavaScript Side:</h3>
    <p>LIFF ID in JS: <strong id="jsLiffId">Loading...</strong></p>
    <p>LIFF Status: <strong id="liffStatus">Loading...</strong></p>
    
    <?php if ($liffId): ?>
    <h3>Test LIFF Init:</h3>
    <button onclick="testLiff()">Test LIFF Init</button>
    <p id="liffResult"></p>
    
    <h3>Open LIFF URL:</h3>
    <p><a href="https://liff.line.me/<?= $liffId ?>" target="_blank">https://liff.line.me/<?= $liffId ?></a></p>
    <?php endif; ?>
    
    <script>
    const liffId = '<?= $liffId ?>';
    document.getElementById('jsLiffId').textContent = liffId || 'EMPTY';
    document.getElementById('jsLiffId').style.color = liffId ? 'green' : 'red';
    
    if (liffId) {
        document.getElementById('liffStatus').textContent = 'Ready to init';
    } else {
        document.getElementById('liffStatus').textContent = 'No LIFF ID';
        document.getElementById('liffStatus').style.color = 'red';
    }
    
    async function testLiff() {
        const result = document.getElementById('liffResult');
        result.textContent = 'Initializing...';
        
        try {
            await liff.init({ liffId: liffId });
            result.innerHTML = '✅ LIFF Init Success!<br>';
            result.innerHTML += 'isLoggedIn: ' + liff.isLoggedIn() + '<br>';
            result.innerHTML += 'isInClient: ' + liff.isInClient() + '<br>';
            
            if (liff.isLoggedIn()) {
                const profile = await liff.getProfile();
                result.innerHTML += 'User: ' + profile.displayName + '<br>';
                result.innerHTML += 'User ID: ' + profile.userId;
            }
        } catch (e) {
            result.innerHTML = '❌ Error: ' + e.message;
            result.style.color = 'red';
        }
    }
    </script>
</body>
</html>
