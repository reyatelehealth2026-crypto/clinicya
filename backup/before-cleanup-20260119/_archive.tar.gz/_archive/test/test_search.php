<?php
/**
 * Test Product Search
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$db = Database::getInstance()->getConnection();

echo "<pre>";
echo "=== Test Product Search ===\n\n";

// Check which table exists
$table = 'products';
try {
    $db->query("SELECT 1 FROM business_items LIMIT 1");
    $table = 'business_items';
    echo "Using table: business_items\n";
} catch (Exception $e) {
    echo "Using table: products\n";
}

// Count products
$stmt = $db->query("SELECT COUNT(*) FROM {$table}");
echo "Total products: " . $stmt->fetchColumn() . "\n\n";

// Show sample products
echo "Sample products:\n";
$stmt = $db->query("SELECT id, name, sku, price, stock FROM {$table} LIMIT 10");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "  - [{$row['id']}] {$row['name']} (SKU: {$row['sku']}, Price: {$row['price']}, Stock: {$row['stock']})\n";
}

// Test search
$query = $_GET['q'] ?? 'พารา';
echo "\n\nSearch for: '{$query}'\n";
$search = '%' . $query . '%';
$stmt = $db->prepare("SELECT id, name, sku, price, stock FROM {$table} WHERE (name LIKE ? OR sku LIKE ?) AND is_active = 1 LIMIT 5");
$stmt->execute([$search, $search]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Results: " . count($results) . "\n";
foreach ($results as $row) {
    echo "  - [{$row['id']}] {$row['name']} (SKU: {$row['sku']})\n";
}

echo "\n=== Done ===\n";
echo "</pre>";

echo "<p><a href='test_search.php?q='>Try search: ?q=keyword</a></p>";
