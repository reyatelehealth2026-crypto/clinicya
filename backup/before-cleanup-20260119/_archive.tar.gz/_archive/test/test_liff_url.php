<?php
/**
 * Test LIFF URL Generation
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>Test LIFF URL Generation</h2>";

// 1. Check liff_id in database
echo "<h3>1. LIFF ID in Database</h3>";
try {
    $stmt = $db->query("SELECT id, name, liff_id FROM line_accounts");
    $accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Name</th><th>LIFF ID</th><th>LIFF URL</th></tr>";
    foreach ($accounts as $a) {
        $liffId = $a['liff_id'] ?? '';
        $liffUrl = $liffId ? "https://liff.line.me/{$liffId}?page=checkout&user=Utest123" : 'N/A';
        echo "<tr>";
        echo "<td>{$a['id']}</td>";
        echo "<td>{$a['name']}</td>";
        echo "<td>" . ($liffId ?: '<em style="color:red">EMPTY</em>') . "</td>";
        echo "<td>" . ($liffId ? "<a href='{$liffUrl}' target='_blank'>{$liffUrl}</a>" : 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

// 2. Test BusinessBot getLiffCheckoutUrl
echo "<h3>2. Test BusinessBot</h3>";
try {
    require_once 'classes/BusinessBot.php';
    
    // Get first account
    $stmt = $db->query("SELECT * FROM line_accounts WHERE id = 1");
    $account = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($account) {
        // Create mock LineAPI
        require_once 'classes/LineAPI.php';
        $lineApi = new LineAPI($account['channel_access_token'], $account['channel_secret']);
        
        // Create BusinessBot
        $bot = new BusinessBot($db, $lineApi, $account['id']);
        
        // Use reflection to call private method
        $reflection = new ReflectionClass($bot);
        $method = $reflection->getMethod('getLiffCheckoutUrl');
        $method->setAccessible(true);
        
        $result = $method->invoke($bot, 123, 'U1234567890abcdef');
        
        echo "<p><strong>getLiffCheckoutUrl(123, 'U1234567890abcdef'):</strong></p>";
        if ($result) {
            echo "<p style='color:green'>✅ URL: <a href='{$result}' target='_blank'>{$result}</a></p>";
        } else {
            echo "<p style='color:red'>❌ NULL (LIFF ID not set or error)</p>";
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

// 3. Direct test
echo "<h3>3. Direct LIFF Checkout Test</h3>";
$testUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/liff-checkout.php?user=Utest123';
echo "<p>Direct URL (without LIFF): <a href='{$testUrl}' target='_blank'>{$testUrl}</a></p>";

echo "<br><br>";
echo "<a href='debug_liff.php'>← Go to debug_liff.php to set LIFF ID</a>";
