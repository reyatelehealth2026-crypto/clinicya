<?php
/**
 * Test AJAX Handler
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>Test AJAX Handler</h2>";

// Test get_user_tags
$userId = 9; // feelgoods
echo "<h3>1. Test get_user_tags for user_id = {$userId}</h3>";

try {
    $stmt = $db->prepare("SELECT t.* FROM user_tags t JOIN user_tag_assignments a ON t.id = a.tag_id WHERE a.user_id = ?");
    $stmt->execute([$userId]);
    $tags = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p style='color:green'>✅ Query OK - Found " . count($tags) . " tags</p>";
    echo "<pre>" . print_r($tags, true) . "</pre>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}

// Check user_tags table structure
echo "<h3>2. user_tags table structure</h3>";
try {
    $stmt = $db->query("DESCRIBE user_tags");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th></tr>";
    foreach ($columns as $col) {
        echo "<tr><td>{$col['Field']}</td><td>{$col['Type']}</td><td>{$col['Null']}</td><td>{$col['Key']}</td></tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test API directly
echo "<h3>3. Test API directly</h3>";
$apiUrl = "api/ajax_handler.php?action=get_user_tags&user_id={$userId}";
echo "<p>URL: <a href='{$apiUrl}' target='_blank'>{$apiUrl}</a></p>";
?>
