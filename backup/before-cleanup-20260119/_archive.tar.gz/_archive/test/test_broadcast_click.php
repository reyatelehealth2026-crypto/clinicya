<?php
/**
 * Test Broadcast Click - ทดสอบระบบ broadcast click และ auto tag
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>🔍 ทดสอบระบบ Broadcast Click & Auto Tag</h2>";

// 1. Check tables exist
echo "<h3>1. ตรวจสอบตาราง</h3>";
$tables = ['broadcast_campaigns', 'broadcast_items', 'broadcast_clicks', 'user_tags', 'user_tag_assignments'];
foreach ($tables as $table) {
    try {
        $stmt = $db->query("SELECT 1 FROM {$table} LIMIT 1");
        echo "<p>✅ {$table} - OK</p>";
    } catch (Exception $e) {
        echo "<p>❌ {$table} - ไม่มีตาราง: " . $e->getMessage() . "</p>";
    }
}

// 2. Check broadcast_campaigns columns
echo "<h3>2. ตรวจสอบ columns ใน broadcast_campaigns</h3>";
try {
    $stmt = $db->query("DESCRIBE broadcast_campaigns");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $required = ['id', 'auto_tag_enabled', 'tag_prefix', 'click_count'];
    foreach ($required as $col) {
        if (in_array($col, $columns)) {
            echo "<p>✅ {$col}</p>";
        } else {
            echo "<p>❌ {$col} - ไม่มี column นี้</p>";
        }
    }
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

// 3. Check broadcast_items columns
echo "<h3>3. ตรวจสอบ columns ใน broadcast_items</h3>";
try {
    $stmt = $db->query("DESCRIBE broadcast_items");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $required = ['id', 'broadcast_id', 'product_id', 'postback_data', 'tag_id', 'click_count'];
    foreach ($required as $col) {
        if (in_array($col, $columns)) {
            echo "<p>✅ {$col}</p>";
        } else {
            echo "<p>❌ {$col} - ไม่มี column นี้</p>";
        }
    }
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

// 4. Check existing campaigns
echo "<h3>4. Campaigns ที่มีอยู่</h3>";
try {
    $stmt = $db->query("SELECT id, name, auto_tag_enabled, tag_prefix, click_count, status FROM broadcast_campaigns ORDER BY id DESC LIMIT 5");
    $campaigns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($campaigns)) {
        echo "<p>⚠️ ยังไม่มี campaign</p>";
    } else {
        echo "<table border='1' cellpadding='5'><tr><th>ID</th><th>Name</th><th>Auto Tag</th><th>Prefix</th><th>Clicks</th><th>Status</th></tr>";
        foreach ($campaigns as $c) {
            echo "<tr><td>{$c['id']}</td><td>{$c['name']}</td><td>" . ($c['auto_tag_enabled'] ? '✅' : '❌') . "</td><td>{$c['tag_prefix']}</td><td>{$c['click_count']}</td><td>{$c['status']}</td></tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

// 5. Check items with postback data
echo "<h3>5. Items และ Postback Data</h3>";
try {
    $stmt = $db->query("SELECT bi.id, bi.item_name, bi.postback_data, bi.tag_id, bi.click_count, bc.name as campaign_name 
                        FROM broadcast_items bi 
                        JOIN broadcast_campaigns bc ON bi.broadcast_id = bc.id 
                        ORDER BY bi.id DESC LIMIT 10");
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($items)) {
        echo "<p>⚠️ ยังไม่มี items</p>";
    } else {
        echo "<table border='1' cellpadding='5'><tr><th>ID</th><th>Campaign</th><th>Item</th><th>Postback Data</th><th>Tag ID</th><th>Clicks</th></tr>";
        foreach ($items as $item) {
            $postbackFormat = strpos($item['postback_data'], '{') === 0 ? '🔴 JSON' : '🟢 String';
            echo "<tr><td>{$item['id']}</td><td>{$item['campaign_name']}</td><td>{$item['item_name']}</td><td>{$postbackFormat}: " . htmlspecialchars(substr($item['postback_data'], 0, 50)) . "...</td><td>{$item['tag_id']}</td><td>{$item['click_count']}</td></tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

// 6. Check clicks
echo "<h3>6. Broadcast Clicks ล่าสุด</h3>";
try {
    $stmt = $db->query("SELECT bc.*, u.display_name, bi.item_name 
                        FROM broadcast_clicks bc 
                        LEFT JOIN users u ON bc.user_id = u.id 
                        LEFT JOIN broadcast_items bi ON bc.item_id = bi.id 
                        ORDER BY bc.clicked_at DESC LIMIT 10");
    $clicks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($clicks)) {
        echo "<p>⚠️ ยังไม่มี clicks</p>";
    } else {
        echo "<table border='1' cellpadding='5'><tr><th>ID</th><th>User</th><th>Item</th><th>Tag Assigned</th><th>Time</th></tr>";
        foreach ($clicks as $click) {
            echo "<tr><td>{$click['id']}</td><td>{$click['display_name']}</td><td>{$click['item_name']}</td><td>" . ($click['tag_assigned'] ? '✅' : '❌') . "</td><td>{$click['clicked_at']}</td></tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

// 7. Check user_tag_assignments from broadcast
echo "<h3>7. Tags ที่ติดจาก Broadcast</h3>";
try {
    $stmt = $db->query("SELECT uta.*, u.display_name, t.name as tag_name 
                        FROM user_tag_assignments uta 
                        JOIN users u ON uta.user_id = u.id 
                        JOIN user_tags t ON uta.tag_id = t.id 
                        WHERE uta.assigned_by = 'broadcast' 
                        ORDER BY uta.id DESC LIMIT 10");
    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($assignments)) {
        echo "<p>⚠️ ยังไม่มี tags ที่ติดจาก broadcast</p>";
    } else {
        echo "<table border='1' cellpadding='5'><tr><th>User</th><th>Tag</th><th>Assigned By</th></tr>";
        foreach ($assignments as $a) {
            echo "<tr><td>{$a['display_name']}</td><td>{$a['tag_name']}</td><td>{$a['assigned_by']}</td></tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h3>📝 สรุป</h3>";
echo "<p>ถ้า Postback Data เป็น <span style='color:red'>🔴 JSON</span> = รูปแบบเก่า (อาจไม่ทำงาน)</p>";
echo "<p>ถ้า Postback Data เป็น <span style='color:green'>🟢 String</span> = รูปแบบใหม่ (ทำงานได้)</p>";
echo "<p>Campaign ที่สร้างใหม่จะใช้รูปแบบ String โดยอัตโนมัติ</p>";
