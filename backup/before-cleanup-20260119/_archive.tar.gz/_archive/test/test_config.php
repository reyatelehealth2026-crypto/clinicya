<?php
// Test config file
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Test Config</h1>";

// Check if config exists
$configFile = __DIR__ . '/config/config.php';
echo "<p>Config path: $configFile</p>";
echo "<p>File exists: " . (file_exists($configFile) ? 'YES' : 'NO') . "</p>";

if (file_exists($configFile)) {
    echo "<h2>Config Content (first 500 chars):</h2>";
    $content = file_get_contents($configFile);
    echo "<pre>" . htmlspecialchars(substr($content, 0, 500)) . "</pre>";
    
    echo "<h2>Loading config...</h2>";
    require_once $configFile;
    
    echo "<p>DB_HOST: " . (defined('DB_HOST') ? DB_HOST : 'NOT DEFINED') . "</p>";
    echo "<p>DB_NAME: " . (defined('DB_NAME') ? DB_NAME : 'NOT DEFINED') . "</p>";
    echo "<p>DB_USER: " . (defined('DB_USER') ? DB_USER : 'NOT DEFINED') . "</p>";
    echo "<p>BASE_URL: " . (defined('BASE_URL') ? BASE_URL : 'NOT DEFINED') . "</p>";
}
