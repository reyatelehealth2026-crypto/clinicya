<?php
/**
 * Test Users Query
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

echo "<h2>🔍 ทดสอบ Query Users</h2>";

// Test 1: Basic query
echo "<h3>1. Basic Query</h3>";
try {
    $stmt = $db->query("SELECT COUNT(*) FROM users");
    $count = $stmt->fetchColumn();
    echo "<p style='color:green'>✅ มี users ทั้งหมด: {$count} คน</p>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test 2: Check columns
echo "<h3>2. ตรวจสอบ Columns</h3>";
try {
    $stmt = $db->query("DESCRIBE users");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "<p>Columns: " . implode(', ', $columns) . "</p>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test 3: Check user_tags table
echo "<h3>3. ตรวจสอบ user_tags</h3>";
try {
    $stmt = $db->query("SELECT COUNT(*) FROM user_tags");
    $count = $stmt->fetchColumn();
    echo "<p style='color:green'>✅ มี tags ทั้งหมด: {$count} รายการ</p>";
} catch (Exception $e) {
    echo "<p style='color:orange'>⚠️ ตาราง user_tags ไม่มี: " . $e->getMessage() . "</p>";
}

// Test 4: Check user_tag_assignments table
echo "<h3>4. ตรวจสอบ user_tag_assignments</h3>";
try {
    $stmt = $db->query("SELECT COUNT(*) FROM user_tag_assignments");
    $count = $stmt->fetchColumn();
    echo "<p style='color:green'>✅ มี assignments ทั้งหมด: {$count} รายการ</p>";
} catch (Exception $e) {
    echo "<p style='color:orange'>⚠️ ตาราง user_tag_assignments ไม่มี: " . $e->getMessage() . "</p>";
}

// Test 5: Full query
echo "<h3>5. Full Query</h3>";
$currentBotId = 1;
try {
    $sql = "SELECT u.*, 
            (SELECT GROUP_CONCAT(t.name SEPARATOR ', ') FROM user_tags t 
             JOIN user_tag_assignments uta ON t.id = uta.tag_id 
             WHERE uta.user_id = u.id) as tags,
            (SELECT COUNT(*) FROM messages m WHERE m.user_id = u.id) as message_count
            FROM users u 
            WHERE (u.line_account_id = ? OR u.line_account_id IS NULL)
            ORDER BY u.created_at DESC
            LIMIT 10";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([$currentBotId]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p style='color:green'>✅ Query สำเร็จ พบ " . count($users) . " users</p>";
    
    if (count($users) > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Display Name</th><th>LINE Account ID</th><th>Tags</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>{$user['id']}</td>";
            echo "<td>" . htmlspecialchars($user['display_name'] ?? 'N/A') . "</td>";
            echo "<td>{$user['line_account_id']}</td>";
            echo "<td>" . htmlspecialchars($user['tags'] ?? '-') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

// Test 6: Simple query without subqueries
echo "<h3>6. Simple Query (ไม่มี subquery)</h3>";
try {
    $sql = "SELECT * FROM users WHERE (line_account_id = ? OR line_account_id IS NULL) LIMIT 5";
    $stmt = $db->prepare($sql);
    $stmt->execute([$currentBotId]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p style='color:green'>✅ Query สำเร็จ พบ " . count($users) . " users</p>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}
?>
