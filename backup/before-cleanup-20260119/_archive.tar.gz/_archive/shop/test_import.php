<?php
/**
 * Test Import Page
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Test Import</h1>";

// Test config
require_once __DIR__ . '/../config/config.php';
echo "<p>✅ Config loaded</p>";

require_once __DIR__ . '/../config/database.php';
echo "<p>✅ Database loaded</p>";

$db = Database::getInstance()->getConnection();
echo "<p>✅ Database connected</p>";

// Check tables
$tables = ['business_items', 'product_categories'];
foreach ($tables as $table) {
    try {
        $stmt = $db->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "<p>✅ Table $table exists</p>";
            
            // Show columns
            $cols = $db->query("SHOW COLUMNS FROM $table")->fetchAll(PDO::FETCH_COLUMN);
            echo "<p style='font-size:12px; color:gray'>Columns: " . implode(', ', $cols) . "</p>";
        } else {
            echo "<p>❌ Table $table NOT exists</p>";
        }
    } catch (Exception $e) {
        echo "<p>❌ Error checking $table: " . $e->getMessage() . "</p>";
    }
}

// Check if header exists
if (file_exists(__DIR__ . '/../includes/header.php')) {
    echo "<p>✅ Header file exists</p>";
} else {
    echo "<p>❌ Header file NOT found</p>";
}

echo "<hr><a href='import-products.php'>Go to Import Page</a>";
